import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start OpenAI API Group Code

class OpenAIAPIGroup {
  static String getBaseUrl() => 'https://api.openai.com/v1';
  static Map<String, String> headers = {
    'Authorization':
        'Bearer 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',
  };
  static ListAssistantsCall listAssistantsCall = ListAssistantsCall();
  static CreateAssistantCall createAssistantCall = CreateAssistantCall();
  static DeleteAssistantCall deleteAssistantCall = DeleteAssistantCall();
  static GetAssistantCall getAssistantCall = GetAssistantCall();
  static ModifyAssistantCall modifyAssistantCall = ModifyAssistantCall();
  static CreateSpeechCall createSpeechCall = CreateSpeechCall();
  static CreateTranscriptionCall createTranscriptionCall =
      CreateTranscriptionCall();
  static CreateTranslationCall createTranslationCall = CreateTranslationCall();
  static ListBatchesCall listBatchesCall = ListBatchesCall();
  static CreateBatchCall createBatchCall = CreateBatchCall();
  static RetrieveBatchCall retrieveBatchCall = RetrieveBatchCall();
  static CancelBatchCall cancelBatchCall = CancelBatchCall();
  static ListChatCompletionsCall listChatCompletionsCall =
      ListChatCompletionsCall();
  static CreateChatCompletionCall createChatCompletionCall =
      CreateChatCompletionCall();
  static DeleteChatCompletionCall deleteChatCompletionCall =
      DeleteChatCompletionCall();
  static GetChatCompletionCall getChatCompletionCall = GetChatCompletionCall();
  static UpdateChatCompletionCall updateChatCompletionCall =
      UpdateChatCompletionCall();
  static GetChatCompletionMessagesCall getChatCompletionMessagesCall =
      GetChatCompletionMessagesCall();
  static CreateCompletionCall createCompletionCall = CreateCompletionCall();
  static CreateEmbeddingCall createEmbeddingCall = CreateEmbeddingCall();
  static ListEvalsCall listEvalsCall = ListEvalsCall();
  static CreateEvalCall createEvalCall = CreateEvalCall();
  static DeleteEvalCall deleteEvalCall = DeleteEvalCall();
  static GetEvalCall getEvalCall = GetEvalCall();
  static UpdateEvalCall updateEvalCall = UpdateEvalCall();
  static GetEvalRunsCall getEvalRunsCall = GetEvalRunsCall();
  static CreateEvalRunCall createEvalRunCall = CreateEvalRunCall();
  static DeleteEvalRunCall deleteEvalRunCall = DeleteEvalRunCall();
  static GetEvalRunCall getEvalRunCall = GetEvalRunCall();
  static CancelEvalRunCall cancelEvalRunCall = CancelEvalRunCall();
  static GetEvalRunOutputItemsCall getEvalRunOutputItemsCall =
      GetEvalRunOutputItemsCall();
  static GetEvalRunOutputItemCall getEvalRunOutputItemCall =
      GetEvalRunOutputItemCall();
  static ListFilesCall listFilesCall = ListFilesCall();
  static CreateFileCall createFileCall = CreateFileCall();
  static DeleteFileCall deleteFileCall = DeleteFileCall();
  static RetrieveFileCall retrieveFileCall = RetrieveFileCall();
  static DownloadFileCall downloadFileCall = DownloadFileCall();
  static ListFineTuningCheckpointPermissionsCall
      listFineTuningCheckpointPermissionsCall =
      ListFineTuningCheckpointPermissionsCall();
  static CreateFineTuningCheckpointPermissionCall
      createFineTuningCheckpointPermissionCall =
      CreateFineTuningCheckpointPermissionCall();
  static DeleteFineTuningCheckpointPermissionCall
      deleteFineTuningCheckpointPermissionCall =
      DeleteFineTuningCheckpointPermissionCall();
  static ListPaginatedFineTuningJobsCall listPaginatedFineTuningJobsCall =
      ListPaginatedFineTuningJobsCall();
  static CreateFineTuningJobCall createFineTuningJobCall =
      CreateFineTuningJobCall();
  static RetrieveFineTuningJobCall retrieveFineTuningJobCall =
      RetrieveFineTuningJobCall();
  static CancelFineTuningJobCall cancelFineTuningJobCall =
      CancelFineTuningJobCall();
  static ListFineTuningJobCheckpointsCall listFineTuningJobCheckpointsCall =
      ListFineTuningJobCheckpointsCall();
  static ListFineTuningEventsCall listFineTuningEventsCall =
      ListFineTuningEventsCall();
  static CreateImageEditCall createImageEditCall = CreateImageEditCall();
  static CreateImageCall createImageCall = CreateImageCall();
  static CreateImageVariationCall createImageVariationCall =
      CreateImageVariationCall();
  static ListModelsCall listModelsCall = ListModelsCall();
  static DeleteModelCall deleteModelCall = DeleteModelCall();
  static RetrieveModelCall retrieveModelCall = RetrieveModelCall();
  static CreateModerationCall createModerationCall = CreateModerationCall();
  static AdminApiKeysListCall adminApiKeysListCall = AdminApiKeysListCall();
  static AdminApiKeysCreateCall adminApiKeysCreateCall =
      AdminApiKeysCreateCall();
  static AdminApiKeysDeleteCall adminApiKeysDeleteCall =
      AdminApiKeysDeleteCall();
  static AdminApiKeysGetCall adminApiKeysGetCall = AdminApiKeysGetCall();
  static ListAuditLogsCall listAuditLogsCall = ListAuditLogsCall();
  static ListOrganizationCertificatesCall listOrganizationCertificatesCall =
      ListOrganizationCertificatesCall();
  static UploadCertificateCall uploadCertificateCall = UploadCertificateCall();
  static ActivateOrganizationCertificatesCall
      activateOrganizationCertificatesCall =
      ActivateOrganizationCertificatesCall();
  static DeactivateOrganizationCertificatesCall
      deactivateOrganizationCertificatesCall =
      DeactivateOrganizationCertificatesCall();
  static DeleteCertificateCall deleteCertificateCall = DeleteCertificateCall();
  static GetCertificateCall getCertificateCall = GetCertificateCall();
  static ModifyCertificateCall modifyCertificateCall = ModifyCertificateCall();
  static UsageCostsCall usageCostsCall = UsageCostsCall();
  static ListInvitesCall listInvitesCall = ListInvitesCall();
  static InviteUserCall inviteUserCall = InviteUserCall();
  static DeleteInviteCall deleteInviteCall = DeleteInviteCall();
  static RetrieveInviteCall retrieveInviteCall = RetrieveInviteCall();
  static ListProjectsCall listProjectsCall = ListProjectsCall();
  static CreateProjectCall createProjectCall = CreateProjectCall();
  static RetrieveProjectCall retrieveProjectCall = RetrieveProjectCall();
  static ModifyProjectCall modifyProjectCall = ModifyProjectCall();
  static ListProjectApiKeysCall listProjectApiKeysCall =
      ListProjectApiKeysCall();
  static DeleteProjectApiKeyCall deleteProjectApiKeyCall =
      DeleteProjectApiKeyCall();
  static RetrieveProjectApiKeyCall retrieveProjectApiKeyCall =
      RetrieveProjectApiKeyCall();
  static ArchiveProjectCall archiveProjectCall = ArchiveProjectCall();
  static ListProjectCertificatesCall listProjectCertificatesCall =
      ListProjectCertificatesCall();
  static ActivateProjectCertificatesCall activateProjectCertificatesCall =
      ActivateProjectCertificatesCall();
  static DeactivateProjectCertificatesCall deactivateProjectCertificatesCall =
      DeactivateProjectCertificatesCall();
  static ListProjectRateLimitsCall listProjectRateLimitsCall =
      ListProjectRateLimitsCall();
  static UpdateProjectRateLimitsCall updateProjectRateLimitsCall =
      UpdateProjectRateLimitsCall();
  static ListProjectServiceAccountsCall listProjectServiceAccountsCall =
      ListProjectServiceAccountsCall();
  static CreateProjectServiceAccountCall createProjectServiceAccountCall =
      CreateProjectServiceAccountCall();
  static DeleteProjectServiceAccountCall deleteProjectServiceAccountCall =
      DeleteProjectServiceAccountCall();
  static RetrieveProjectServiceAccountCall retrieveProjectServiceAccountCall =
      RetrieveProjectServiceAccountCall();
  static ListProjectUsersCall listProjectUsersCall = ListProjectUsersCall();
  static CreateProjectUserCall createProjectUserCall = CreateProjectUserCall();
  static DeleteProjectUserCall deleteProjectUserCall = DeleteProjectUserCall();
  static RetrieveProjectUserCall retrieveProjectUserCall =
      RetrieveProjectUserCall();
  static ModifyProjectUserCall modifyProjectUserCall = ModifyProjectUserCall();
  static UsageAudioSpeechesCall usageAudioSpeechesCall =
      UsageAudioSpeechesCall();
  static UsageAudioTranscriptionsCall usageAudioTranscriptionsCall =
      UsageAudioTranscriptionsCall();
  static UsageCodeInterpreterSessionsCall usageCodeInterpreterSessionsCall =
      UsageCodeInterpreterSessionsCall();
  static UsageCompletionsCall usageCompletionsCall = UsageCompletionsCall();
  static UsageEmbeddingsCall usageEmbeddingsCall = UsageEmbeddingsCall();
  static UsageImagesCall usageImagesCall = UsageImagesCall();
  static UsageModerationsCall usageModerationsCall = UsageModerationsCall();
  static UsageVectorStoresCall usageVectorStoresCall = UsageVectorStoresCall();
  static ListUsersCall listUsersCall = ListUsersCall();
  static DeleteUserCall deleteUserCall = DeleteUserCall();
  static RetrieveUserCall retrieveUserCall = RetrieveUserCall();
  static ModifyUserCall modifyUserCall = ModifyUserCall();
  static CreateRealtimeSessionCall createRealtimeSessionCall =
      CreateRealtimeSessionCall();
  static CreateRealtimeTranscriptionSessionCall
      createRealtimeTranscriptionSessionCall =
      CreateRealtimeTranscriptionSessionCall();
  static CreateResponseCall createResponseCall = CreateResponseCall();
  static DeleteResponseCall deleteResponseCall = DeleteResponseCall();
  static GetResponseCall getResponseCall = GetResponseCall();
  static ListInputItemsCall listInputItemsCall = ListInputItemsCall();
  static CreateThreadCall createThreadCall = CreateThreadCall();
  static CreateThreadAndRunCall createThreadAndRunCall =
      CreateThreadAndRunCall();
  static DeleteThreadCall deleteThreadCall = DeleteThreadCall();
  static GetThreadCall getThreadCall = GetThreadCall();
  static ModifyThreadCall modifyThreadCall = ModifyThreadCall();
  static ListMessagesCall listMessagesCall = ListMessagesCall();
  static CreateMessageCall createMessageCall = CreateMessageCall();
  static DeleteMessageCall deleteMessageCall = DeleteMessageCall();
  static GetMessageCall getMessageCall = GetMessageCall();
  static ModifyMessageCall modifyMessageCall = ModifyMessageCall();
  static ListRunsCall listRunsCall = ListRunsCall();
  static CreateRunCall createRunCall = CreateRunCall();
  static GetRunCall getRunCall = GetRunCall();
  static ModifyRunCall modifyRunCall = ModifyRunCall();
  static CancelRunCall cancelRunCall = CancelRunCall();
  static ListRunStepsCall listRunStepsCall = ListRunStepsCall();
  static GetRunStepCall getRunStepCall = GetRunStepCall();
  static SubmitToolOuputsToRunCall submitToolOuputsToRunCall =
      SubmitToolOuputsToRunCall();
  static CreateUploadCall createUploadCall = CreateUploadCall();
  static CancelUploadCall cancelUploadCall = CancelUploadCall();
  static CompleteUploadCall completeUploadCall = CompleteUploadCall();
  static AddUploadPartCall addUploadPartCall = AddUploadPartCall();
  static ListVectorStoresCall listVectorStoresCall = ListVectorStoresCall();
  static CreateVectorStoreCall createVectorStoreCall = CreateVectorStoreCall();
  static DeleteVectorStoreCall deleteVectorStoreCall = DeleteVectorStoreCall();
  static GetVectorStoreCall getVectorStoreCall = GetVectorStoreCall();
  static ModifyVectorStoreCall modifyVectorStoreCall = ModifyVectorStoreCall();
  static CreateVectorStoreFileBatchCall createVectorStoreFileBatchCall =
      CreateVectorStoreFileBatchCall();
  static GetVectorStoreFileBatchCall getVectorStoreFileBatchCall =
      GetVectorStoreFileBatchCall();
  static CancelVectorStoreFileBatchCall cancelVectorStoreFileBatchCall =
      CancelVectorStoreFileBatchCall();
  static ListFilesInVectorStoreBatchCall listFilesInVectorStoreBatchCall =
      ListFilesInVectorStoreBatchCall();
  static ListVectorStoreFilesCall listVectorStoreFilesCall =
      ListVectorStoreFilesCall();
  static CreateVectorStoreFileCall createVectorStoreFileCall =
      CreateVectorStoreFileCall();
  static DeleteVectorStoreFileCall deleteVectorStoreFileCall =
      DeleteVectorStoreFileCall();
  static GetVectorStoreFileCall getVectorStoreFileCall =
      GetVectorStoreFileCall();
  static UpdateVectorStoreFileAttributesCall
      updateVectorStoreFileAttributesCall =
      UpdateVectorStoreFileAttributesCall();
  static RetrieveVectorStoreFileContentCall retrieveVectorStoreFileContentCall =
      RetrieveVectorStoreFileContentCall();
  static SearchVectorStoreCall searchVectorStoreCall = SearchVectorStoreCall();
}

class ListAssistantsCall {
  Future<ApiCallResponse> call({
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listAssistants',
      apiUrl: '${baseUrl}/assistants',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateAssistantCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "description": "",
  "instructions": "",
  "metadata": {},
  "model": "gpt-4o",
  "name": "",
  "reasoning_effort": "low",
  "response_format": "",
  "temperature": 1,
  "tool_resources": {
    "code_interpreter": {
      "file_ids": [
        ""
      ]
    },
    "file_search": {
      "vector_store_ids": [
        ""
      ],
      "vector_stores": [
        {
          "chunking_strategy": {},
          "file_ids": [
            ""
          ],
          "metadata": {}
        }
      ]
    }
  },
  "tools": [
    ""
  ],
  "top_p": 1
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createAssistant',
      apiUrl: '${baseUrl}/assistants',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteAssistantCall {
  Future<ApiCallResponse> call({
    String? assistantId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteAssistant',
      apiUrl: '${baseUrl}/assistants/${assistantId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetAssistantCall {
  Future<ApiCallResponse> call({
    String? assistantId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getAssistant',
      apiUrl: '${baseUrl}/assistants/${assistantId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyAssistantCall {
  Future<ApiCallResponse> call({
    String? assistantId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "description": "",
  "instructions": "",
  "metadata": {},
  "model": "",
  "name": "",
  "reasoning_effort": "low",
  "response_format": "",
  "temperature": 1,
  "tool_resources": {
    "code_interpreter": {
      "file_ids": [
        ""
      ]
    },
    "file_search": {
      "vector_store_ids": [
        ""
      ]
    }
  },
  "tools": [
    ""
  ],
  "top_p": 1
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modifyAssistant',
      apiUrl: '${baseUrl}/assistants/${assistantId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateSpeechCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": "",
  "instructions": "",
  "model": "",
  "response_format": "mp3",
  "speed": 0,
  "voice": "ash"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createSpeech',
      apiUrl: '${baseUrl}/audio/speech',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateTranscriptionCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'createTranscription',
      apiUrl: '${baseUrl}/audio/transcriptions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateTranslationCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'createTranslation',
      apiUrl: '${baseUrl}/audio/translations',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListBatchesCall {
  Future<ApiCallResponse> call({
    String? after = '',
    int? limit,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listBatches',
      apiUrl: '${baseUrl}/batches',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateBatchCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "completion_window": "24h",
  "endpoint": "/v1/responses",
  "input_file_id": "",
  "metadata": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createBatch',
      apiUrl: '${baseUrl}/batches',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveBatchCall {
  Future<ApiCallResponse> call({
    String? batchId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieveBatch',
      apiUrl: '${baseUrl}/batches/${batchId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelBatchCall {
  Future<ApiCallResponse> call({
    String? batchId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'cancelBatch',
      apiUrl: '${baseUrl}/batches/${batchId}/cancel',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListChatCompletionsCall {
  Future<ApiCallResponse> call({
    String? model = '',
    String? metadata = '',
    String? after = '',
    int? limit,
    String? order = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listChatCompletions',
      apiUrl: '${baseUrl}/chat/completions',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'model': model,
        'metadata': metadata,
        'after': after,
        'limit': limit,
        'order': order,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateChatCompletionCall {
  Future<ApiCallResponse> call({
    dynamic? messagesJson,
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final messages = _serializeJson(messagesJson);
    final ffApiRequestBody = '''
{
  "messages": ${messages},
  "model": "gpt-3.5-turbo"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createChatCompletion',
      apiUrl: '${baseUrl}/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteChatCompletionCall {
  Future<ApiCallResponse> call({
    String? completionId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteChatCompletion',
      apiUrl: '${baseUrl}/chat/completions/${completionId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetChatCompletionCall {
  Future<ApiCallResponse> call({
    String? completionId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getChatCompletion',
      apiUrl: '${baseUrl}/chat/completions/${completionId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UpdateChatCompletionCall {
  Future<ApiCallResponse> call({
    String? completionId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "metadata": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'updateChatCompletion',
      apiUrl: '${baseUrl}/chat/completions/${completionId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetChatCompletionMessagesCall {
  Future<ApiCallResponse> call({
    String? completionId = '',
    String? after = '',
    int? limit,
    String? order = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getChatCompletionMessages',
      apiUrl: '${baseUrl}/chat/completions/${completionId}/messages',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
        'order': order,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateCompletionCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "best_of": 0,
  "echo": false,
  "frequency_penalty": 0,
  "logit_bias": {},
  "logprobs": 0,
  "max_tokens": 16,
  "model": "",
  "n": 1,
  "presence_penalty": 0,
  "prompt": "",
  "seed": 0,
  "stop": "",
  "stream": false,
  "stream_options": {
    "include_usage": false
  },
  "suffix": "test.",
  "temperature": 1,
  "top_p": 1,
  "user": "user-1234"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createCompletion',
      apiUrl: '${baseUrl}/completions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateEmbeddingCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "dimensions": 0,
  "encoding_format": "float",
  "input": "The quick brown fox jumped over the lazy dog",
  "model": "text-embedding-3-small",
  "user": "user-1234"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createEmbedding',
      apiUrl: '${baseUrl}/embeddings',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListEvalsCall {
  Future<ApiCallResponse> call({
    String? after = '',
    int? limit,
    String? order = '',
    String? orderBy = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listEvals',
      apiUrl: '${baseUrl}/evals',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
        'order': order,
        'order_by': orderBy,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateEvalCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "data_source_config": {},
  "metadata": {},
  "name": "",
  "testing_criteria": [
    ""
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createEval',
      apiUrl: '${baseUrl}/evals',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteEvalCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteEval',
      apiUrl: '${baseUrl}/evals/${evalId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetEvalCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getEval',
      apiUrl: '${baseUrl}/evals/${evalId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UpdateEvalCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "metadata": {},
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'updateEval',
      apiUrl: '${baseUrl}/evals/${evalId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetEvalRunsCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? after = '',
    int? limit,
    String? order = '',
    String? status = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getEvalRuns',
      apiUrl: '${baseUrl}/evals/${evalId}/runs',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
        'order': order,
        'status': status,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateEvalRunCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "data_source": {},
  "metadata": {},
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createEvalRun',
      apiUrl: '${baseUrl}/evals/${evalId}/runs',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteEvalRunCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteEvalRun',
      apiUrl: '${baseUrl}/evals/${evalId}/runs/${runId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetEvalRunCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getEvalRun',
      apiUrl: '${baseUrl}/evals/${evalId}/runs/${runId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelEvalRunCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'cancelEvalRun',
      apiUrl: '${baseUrl}/evals/${evalId}/runs/${runId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetEvalRunOutputItemsCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? runId = '',
    String? after = '',
    int? limit,
    String? status = '',
    String? order = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getEvalRunOutputItems',
      apiUrl: '${baseUrl}/evals/${evalId}/runs/${runId}/output_items',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
        'status': status,
        'order': order,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetEvalRunOutputItemCall {
  Future<ApiCallResponse> call({
    String? evalId = '',
    String? runId = '',
    String? outputItemId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getEvalRunOutputItem',
      apiUrl:
          '${baseUrl}/evals/${evalId}/runs/${runId}/output_items/${outputItemId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListFilesCall {
  Future<ApiCallResponse> call({
    String? purpose = '',
    int? limit,
    String? order = '',
    String? after = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listFiles',
      apiUrl: '${baseUrl}/files',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'purpose': purpose,
        'limit': limit,
        'order': order,
        'after': after,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateFileCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'createFile',
      apiUrl: '${baseUrl}/files',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteFileCall {
  Future<ApiCallResponse> call({
    String? fileId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteFile',
      apiUrl: '${baseUrl}/files/${fileId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveFileCall {
  Future<ApiCallResponse> call({
    String? fileId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieveFile',
      apiUrl: '${baseUrl}/files/${fileId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DownloadFileCall {
  Future<ApiCallResponse> call({
    String? fileId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'downloadFile',
      apiUrl: '${baseUrl}/files/${fileId}/content',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListFineTuningCheckpointPermissionsCall {
  Future<ApiCallResponse> call({
    String? fineTunedModelCheckpoint = '',
    String? projectId = '',
    String? after = '',
    int? limit,
    String? order = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listFineTuningCheckpointPermissions',
      apiUrl:
          '${baseUrl}/fine_tuning/checkpoints/${fineTunedModelCheckpoint}/permissions',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'project_id': projectId,
        'after': after,
        'limit': limit,
        'order': order,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateFineTuningCheckpointPermissionCall {
  Future<ApiCallResponse> call({
    String? fineTunedModelCheckpoint = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "project_ids": [
    ""
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createFineTuningCheckpointPermission',
      apiUrl:
          '${baseUrl}/fine_tuning/checkpoints/${fineTunedModelCheckpoint}/permissions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteFineTuningCheckpointPermissionCall {
  Future<ApiCallResponse> call({
    String? fineTunedModelCheckpoint = '',
    String? permissionId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteFineTuningCheckpointPermission',
      apiUrl:
          '${baseUrl}/fine_tuning/checkpoints/${fineTunedModelCheckpoint}/permissions/${permissionId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListPaginatedFineTuningJobsCall {
  Future<ApiCallResponse> call({
    String? after = '',
    int? limit,
    String? metadata = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listPaginatedFineTuningJobs',
      apiUrl: '${baseUrl}/fine_tuning/jobs',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
        'metadata': metadata,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateFineTuningJobCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "hyperparameters": {
    "batch_size": "",
    "learning_rate_multiplier": "",
    "n_epochs": ""
  },
  "integrations": [
    {
      "type": "",
      "wandb": {
        "entity": "",
        "name": "",
        "project": "my-wandb-project",
        "tags": [
          "custom-tag"
        ]
      }
    }
  ],
  "metadata": {},
  "method": {
    "dpo": {
      "hyperparameters": {
        "batch_size": "",
        "beta": "",
        "learning_rate_multiplier": "",
        "n_epochs": ""
      }
    },
    "supervised": {
      "hyperparameters": {
        "batch_size": "",
        "learning_rate_multiplier": "",
        "n_epochs": ""
      }
    },
    "type": "supervised"
  },
  "model": "gpt-4o-mini",
  "seed": 42,
  "suffix": "",
  "training_file": "file-abc123",
  "validation_file": "file-abc123"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createFineTuningJob',
      apiUrl: '${baseUrl}/fine_tuning/jobs',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveFineTuningJobCall {
  Future<ApiCallResponse> call({
    String? fineTuningJobId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieveFineTuningJob',
      apiUrl: '${baseUrl}/fine_tuning/jobs/${fineTuningJobId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelFineTuningJobCall {
  Future<ApiCallResponse> call({
    String? fineTuningJobId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'cancelFineTuningJob',
      apiUrl: '${baseUrl}/fine_tuning/jobs/${fineTuningJobId}/cancel',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListFineTuningJobCheckpointsCall {
  Future<ApiCallResponse> call({
    String? fineTuningJobId = '',
    String? after = '',
    int? limit,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listFineTuningJobCheckpoints',
      apiUrl: '${baseUrl}/fine_tuning/jobs/${fineTuningJobId}/checkpoints',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListFineTuningEventsCall {
  Future<ApiCallResponse> call({
    String? fineTuningJobId = '',
    String? after = '',
    int? limit,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listFineTuningEvents',
      apiUrl: '${baseUrl}/fine_tuning/jobs/${fineTuningJobId}/events',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'limit': limit,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateImageEditCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'createImageEdit',
      apiUrl: '${baseUrl}/images/edits',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateImageCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "background": "transparent",
  "model": "gpt-image-1",
  "moderation": "low",
  "n": 1,
  "output_compression": 100,
  "output_format": "png",
  "prompt": "A cute baby sea otter",
  "quality": "medium",
  "response_format": "url",
  "size": "1024x1024",
  "style": "vivid",
  "user": "user-1234"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createImage',
      apiUrl: '${baseUrl}/images/generations',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateImageVariationCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'createImageVariation',
      apiUrl: '${baseUrl}/images/variations',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListModelsCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listModels',
      apiUrl: '${baseUrl}/models',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteModelCall {
  Future<ApiCallResponse> call({
    String? model = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteModel',
      apiUrl: '${baseUrl}/models/${model}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveModelCall {
  Future<ApiCallResponse> call({
    String? model = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieveModel',
      apiUrl: '${baseUrl}/models/${model}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateModerationCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input": "",
  "model": "omni-moderation-2024-09-26"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createModeration',
      apiUrl: '${baseUrl}/moderations',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class AdminApiKeysListCall {
  Future<ApiCallResponse> call({
    String? after = '',
    String? order = '',
    int? limit,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'admin-api-keys-list',
      apiUrl: '${baseUrl}/organization/admin_api_keys',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'after': after,
        'order': order,
        'limit': limit,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class AdminApiKeysCreateCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "name": "New Admin Key"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'admin-api-keys-create',
      apiUrl: '${baseUrl}/organization/admin_api_keys',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class AdminApiKeysDeleteCall {
  Future<ApiCallResponse> call({
    String? keyId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'admin-api-keys-delete',
      apiUrl: '${baseUrl}/organization/admin_api_keys/${keyId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class AdminApiKeysGetCall {
  Future<ApiCallResponse> call({
    String? keyId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'admin-api-keys-get',
      apiUrl: '${baseUrl}/organization/admin_api_keys/${keyId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListAuditLogsCall {
  Future<ApiCallResponse> call({
    String? effectiveAt = '',
    List<String>? projectIdsList,
    List<String>? eventTypesList,
    List<String>? actorIdsList,
    List<String>? actorEmailsList,
    List<String>? resourceIdsList,
    int? limit,
    String? after = '',
    String? before = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final eventTypes = _serializeList(eventTypesList);
    final actorIds = _serializeList(actorIdsList);
    final actorEmails = _serializeList(actorEmailsList);
    final resourceIds = _serializeList(resourceIdsList);

    return ApiManager.instance.makeApiCall(
      callName: 'list-audit-logs',
      apiUrl: '${baseUrl}/organization/audit_logs',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'effective_at': effectiveAt,
        'project_ids': projectIds,
        'event_types': eventTypes,
        'actor_ids': actorIds,
        'actor_emails': actorEmails,
        'resource_ids': resourceIds,
        'limit': limit,
        'after': after,
        'before': before,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListOrganizationCertificatesCall {
  Future<ApiCallResponse> call({
    int? limit,
    String? after = '',
    String? order = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listOrganizationCertificates',
      apiUrl: '${baseUrl}/organization/certificates',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
        'order': order,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UploadCertificateCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "content": "",
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'uploadCertificate',
      apiUrl: '${baseUrl}/organization/certificates',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ActivateOrganizationCertificatesCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "certificate_ids": [
    "cert_abc"
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'activateOrganizationCertificates',
      apiUrl: '${baseUrl}/organization/certificates/activate',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeactivateOrganizationCertificatesCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "certificate_ids": [
    "cert_abc"
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'deactivateOrganizationCertificates',
      apiUrl: '${baseUrl}/organization/certificates/deactivate',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteCertificateCall {
  Future<ApiCallResponse> call({
    String? certificateId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteCertificate',
      apiUrl: '${baseUrl}/organization/certificates/${certificateId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetCertificateCall {
  Future<ApiCallResponse> call({
    String? certId = '',
    List<String>? includeList,
    String? certificateId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final include = _serializeList(includeList);

    return ApiManager.instance.makeApiCall(
      callName: 'getCertificate',
      apiUrl: '${baseUrl}/organization/certificates/${certificateId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'include': include,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyCertificateCall {
  Future<ApiCallResponse> call({
    String? certificateId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modifyCertificate',
      apiUrl: '${baseUrl}/organization/certificates/${certificateId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageCostsCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-costs',
      apiUrl: '${baseUrl}/organization/costs',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListInvitesCall {
  Future<ApiCallResponse> call({
    int? limit,
    String? after = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'list-invites',
      apiUrl: '${baseUrl}/organization/invites',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class InviteUserCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "email": "",
  "projects": [
    {
      "id": "",
      "role": "member"
    }
  ],
  "role": "reader"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'inviteUser',
      apiUrl: '${baseUrl}/organization/invites',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteInviteCall {
  Future<ApiCallResponse> call({
    String? inviteId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'delete-invite',
      apiUrl: '${baseUrl}/organization/invites/${inviteId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveInviteCall {
  Future<ApiCallResponse> call({
    String? inviteId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieve-invite',
      apiUrl: '${baseUrl}/organization/invites/${inviteId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListProjectsCall {
  Future<ApiCallResponse> call({
    int? limit,
    String? after = '',
    bool? includeArchived,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'list-projects',
      apiUrl: '${baseUrl}/organization/projects',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
        'include_archived': includeArchived,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateProjectCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'create-project',
      apiUrl: '${baseUrl}/organization/projects',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveProjectCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieve-project',
      apiUrl: '${baseUrl}/organization/projects/${projectId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyProjectCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modify-project',
      apiUrl: '${baseUrl}/organization/projects/${projectId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListProjectApiKeysCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    int? limit,
    String? after = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'list-project-api-keys',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/api_keys',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteProjectApiKeyCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? keyId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'delete-project-api-key',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/api_keys/${keyId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveProjectApiKeyCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? keyId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieve-project-api-key',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/api_keys/${keyId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ArchiveProjectCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'archive-project',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/archive',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListProjectCertificatesCall {
  Future<ApiCallResponse> call({
    int? limit,
    String? after = '',
    String? order = '',
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listProjectCertificates',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/certificates',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
        'order': order,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ActivateProjectCertificatesCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "certificate_ids": [
    "cert_abc"
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'activateProjectCertificates',
      apiUrl:
          '${baseUrl}/organization/projects/${projectId}/certificates/activate',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeactivateProjectCertificatesCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "certificate_ids": [
    "cert_abc"
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'deactivateProjectCertificates',
      apiUrl:
          '${baseUrl}/organization/projects/${projectId}/certificates/deactivate',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListProjectRateLimitsCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    int? limit,
    String? after = '',
    String? before = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'list-project-rate-limits',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/rate_limits',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
        'before': before,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UpdateProjectRateLimitsCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? rateLimitId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "batch_1_day_max_input_tokens": 0,
  "max_audio_megabytes_per_1_minute": 0,
  "max_images_per_1_minute": 0,
  "max_requests_per_1_day": 0,
  "max_requests_per_1_minute": 0,
  "max_tokens_per_1_minute": 0
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'update-project-rate-limits',
      apiUrl:
          '${baseUrl}/organization/projects/${projectId}/rate_limits/${rateLimitId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListProjectServiceAccountsCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    int? limit,
    String? after = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'list-project-service-accounts',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/service_accounts',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateProjectServiceAccountCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'create-project-service-account',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/service_accounts',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteProjectServiceAccountCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? serviceAccountId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'delete-project-service-account',
      apiUrl:
          '${baseUrl}/organization/projects/${projectId}/service_accounts/${serviceAccountId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveProjectServiceAccountCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? serviceAccountId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieve-project-service-account',
      apiUrl:
          '${baseUrl}/organization/projects/${projectId}/service_accounts/${serviceAccountId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListProjectUsersCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    int? limit,
    String? after = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'list-project-users',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/users',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateProjectUserCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "role": "owner",
  "user_id": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'create-project-user',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/users',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteProjectUserCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? userId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'delete-project-user',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/users/${userId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveProjectUserCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? userId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieve-project-user',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/users/${userId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyProjectUserCall {
  Future<ApiCallResponse> call({
    String? projectId = '',
    String? userId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "role": "owner"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modify-project-user',
      apiUrl: '${baseUrl}/organization/projects/${projectId}/users/${userId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageAudioSpeechesCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? userIdsList,
    List<String>? apiKeyIdsList,
    List<String>? modelsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final userIds = _serializeList(userIdsList);
    final apiKeyIds = _serializeList(apiKeyIdsList);
    final models = _serializeList(modelsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-audio-speeches',
      apiUrl: '${baseUrl}/organization/usage/audio_speeches',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'user_ids': userIds,
        'api_key_ids': apiKeyIds,
        'models': models,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageAudioTranscriptionsCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? userIdsList,
    List<String>? apiKeyIdsList,
    List<String>? modelsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final userIds = _serializeList(userIdsList);
    final apiKeyIds = _serializeList(apiKeyIdsList);
    final models = _serializeList(modelsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-audio-transcriptions',
      apiUrl: '${baseUrl}/organization/usage/audio_transcriptions',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'user_ids': userIds,
        'api_key_ids': apiKeyIds,
        'models': models,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageCodeInterpreterSessionsCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-code-interpreter-sessions',
      apiUrl: '${baseUrl}/organization/usage/code_interpreter_sessions',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageCompletionsCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? userIdsList,
    List<String>? apiKeyIdsList,
    List<String>? modelsList,
    bool? batch,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final userIds = _serializeList(userIdsList);
    final apiKeyIds = _serializeList(apiKeyIdsList);
    final models = _serializeList(modelsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-completions',
      apiUrl: '${baseUrl}/organization/usage/completions',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'user_ids': userIds,
        'api_key_ids': apiKeyIds,
        'models': models,
        'batch': batch,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageEmbeddingsCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? userIdsList,
    List<String>? apiKeyIdsList,
    List<String>? modelsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final userIds = _serializeList(userIdsList);
    final apiKeyIds = _serializeList(apiKeyIdsList);
    final models = _serializeList(modelsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-embeddings',
      apiUrl: '${baseUrl}/organization/usage/embeddings',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'user_ids': userIds,
        'api_key_ids': apiKeyIds,
        'models': models,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageImagesCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? sourcesList,
    List<String>? sizesList,
    List<String>? projectIdsList,
    List<String>? userIdsList,
    List<String>? apiKeyIdsList,
    List<String>? modelsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final sources = _serializeList(sourcesList);
    final sizes = _serializeList(sizesList);
    final projectIds = _serializeList(projectIdsList);
    final userIds = _serializeList(userIdsList);
    final apiKeyIds = _serializeList(apiKeyIdsList);
    final models = _serializeList(modelsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-images',
      apiUrl: '${baseUrl}/organization/usage/images',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'sources': sources,
        'sizes': sizes,
        'project_ids': projectIds,
        'user_ids': userIds,
        'api_key_ids': apiKeyIds,
        'models': models,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageModerationsCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? userIdsList,
    List<String>? apiKeyIdsList,
    List<String>? modelsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final userIds = _serializeList(userIdsList);
    final apiKeyIds = _serializeList(apiKeyIdsList);
    final models = _serializeList(modelsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-moderations',
      apiUrl: '${baseUrl}/organization/usage/moderations',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'user_ids': userIds,
        'api_key_ids': apiKeyIds,
        'models': models,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UsageVectorStoresCall {
  Future<ApiCallResponse> call({
    int? startTime,
    int? endTime,
    String? bucketWidth = '',
    List<String>? projectIdsList,
    List<String>? groupByList,
    int? limit,
    String? page = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final projectIds = _serializeList(projectIdsList);
    final groupBy = _serializeList(groupByList);

    return ApiManager.instance.makeApiCall(
      callName: 'usage-vector-stores',
      apiUrl: '${baseUrl}/organization/usage/vector_stores',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'start_time': startTime,
        'end_time': endTime,
        'bucket_width': bucketWidth,
        'project_ids': projectIds,
        'group_by': groupBy,
        'limit': limit,
        'page': page,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListUsersCall {
  Future<ApiCallResponse> call({
    int? limit,
    String? after = '',
    List<String>? emailsList,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final emails = _serializeList(emailsList);

    return ApiManager.instance.makeApiCall(
      callName: 'list-users',
      apiUrl: '${baseUrl}/organization/users',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'after': after,
        'emails': emails,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteUserCall {
  Future<ApiCallResponse> call({
    String? userId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'delete-user',
      apiUrl: '${baseUrl}/organization/users/${userId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveUserCall {
  Future<ApiCallResponse> call({
    String? userId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieve-user',
      apiUrl: '${baseUrl}/organization/users/${userId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyUserCall {
  Future<ApiCallResponse> call({
    String? userId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "role": "owner"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modify-user',
      apiUrl: '${baseUrl}/organization/users/${userId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateRealtimeSessionCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "input_audio_format": "pcm16",
  "input_audio_noise_reduction": {
    "type": "near_field"
  },
  "input_audio_transcription": {
    "language": "",
    "model": "",
    "prompt": ""
  },
  "instructions": "",
  "max_response_output_tokens": "",
  "modalities": "",
  "model": "gpt-4o-realtime-preview",
  "output_audio_format": "pcm16",
  "temperature": 0,
  "tool_choice": "",
  "tools": [
    {
      "description": "",
      "name": "",
      "parameters": {},
      "type": "function"
    }
  ],
  "turn_detection": {
    "create_response": false,
    "eagerness": "low",
    "interrupt_response": false,
    "prefix_padding_ms": 0,
    "silence_duration_ms": 0,
    "threshold": 0,
    "type": "server_vad"
  },
  "voice": "ash"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'create-realtime-session',
      apiUrl: '${baseUrl}/realtime/sessions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateRealtimeTranscriptionSessionCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "include": [
    ""
  ],
  "input_audio_format": "pcm16",
  "input_audio_noise_reduction": {
    "type": "near_field"
  },
  "input_audio_transcription": {
    "language": "",
    "model": "gpt-4o-transcribe",
    "prompt": ""
  },
  "modalities": "",
  "turn_detection": {
    "create_response": false,
    "eagerness": "low",
    "interrupt_response": false,
    "prefix_padding_ms": 0,
    "silence_duration_ms": 0,
    "threshold": 0,
    "type": "server_vad"
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'create-realtime-transcription-session',
      apiUrl: '${baseUrl}/realtime/transcription_sessions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateResponseCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
""''';
    return ApiManager.instance.makeApiCall(
      callName: 'createResponse',
      apiUrl: '${baseUrl}/responses',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteResponseCall {
  Future<ApiCallResponse> call({
    String? responseId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteResponse',
      apiUrl: '${baseUrl}/responses/${responseId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetResponseCall {
  Future<ApiCallResponse> call({
    String? responseId = '',
    List<String>? includeList,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final include = _serializeList(includeList);

    return ApiManager.instance.makeApiCall(
      callName: 'getResponse',
      apiUrl: '${baseUrl}/responses/${responseId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'include': include,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListInputItemsCall {
  Future<ApiCallResponse> call({
    String? responseId = '',
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    List<String>? includeList,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final include = _serializeList(includeList);

    return ApiManager.instance.makeApiCall(
      callName: 'listInputItems',
      apiUrl: '${baseUrl}/responses/${responseId}/input_items',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
        'include': include,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateThreadCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "messages": [
    {
      "attachments": [
        {
          "file_id": "",
          "tools": [
            ""
          ]
        }
      ],
      "content": "",
      "metadata": {},
      "role": "user"
    }
  ],
  "metadata": {},
  "tool_resources": {
    "code_interpreter": {
      "file_ids": [
        ""
      ]
    },
    "file_search": {
      "vector_store_ids": [
        ""
      ],
      "vector_stores": [
        {
          "chunking_strategy": {},
          "file_ids": [
            ""
          ],
          "metadata": {}
        }
      ]
    }
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createThread',
      apiUrl: '${baseUrl}/threads',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateThreadAndRunCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "assistant_id": "",
  "instructions": "",
  "max_completion_tokens": 0,
  "max_prompt_tokens": 0,
  "metadata": {},
  "model": "gpt-4o",
  "parallel_tool_calls": false,
  "response_format": "",
  "stream": false,
  "temperature": 1,
  "thread": {
    "messages": [
      {
        "attachments": [
          {
            "file_id": "",
            "tools": [
              ""
            ]
          }
        ],
        "content": "",
        "metadata": {},
        "role": "user"
      }
    ],
    "metadata": {},
    "tool_resources": {
      "code_interpreter": {
        "file_ids": [
          ""
        ]
      },
      "file_search": {
        "vector_store_ids": [
          ""
        ],
        "vector_stores": [
          {
            "chunking_strategy": {},
            "file_ids": [
              ""
            ],
            "metadata": {}
          }
        ]
      }
    }
  },
  "tool_choice": "",
  "tool_resources": {
    "code_interpreter": {
      "file_ids": [
        ""
      ]
    },
    "file_search": {
      "vector_store_ids": [
        ""
      ]
    }
  },
  "tools": [
    ""
  ],
  "top_p": 1,
  "truncation_strategy": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createThreadAndRun',
      apiUrl: '${baseUrl}/threads/runs',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteThreadCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteThread',
      apiUrl: '${baseUrl}/threads/${threadId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetThreadCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getThread',
      apiUrl: '${baseUrl}/threads/${threadId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyThreadCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "metadata": {},
  "tool_resources": {
    "code_interpreter": {
      "file_ids": [
        ""
      ]
    },
    "file_search": {
      "vector_store_ids": [
        ""
      ]
    }
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modifyThread',
      apiUrl: '${baseUrl}/threads/${threadId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListMessagesCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listMessages',
      apiUrl: '${baseUrl}/threads/${threadId}/messages',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
        'run_id': runId,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateMessageCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "attachments": [
    {
      "file_id": "",
      "tools": [
        ""
      ]
    }
  ],
  "content": "",
  "metadata": {},
  "role": "user"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createMessage',
      apiUrl: '${baseUrl}/threads/${threadId}/messages',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteMessageCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? messageId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteMessage',
      apiUrl: '${baseUrl}/threads/${threadId}/messages/${messageId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetMessageCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? messageId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getMessage',
      apiUrl: '${baseUrl}/threads/${threadId}/messages/${messageId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyMessageCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? messageId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "metadata": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modifyMessage',
      apiUrl: '${baseUrl}/threads/${threadId}/messages/${messageId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListRunsCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listRuns',
      apiUrl: '${baseUrl}/threads/${threadId}/runs',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateRunCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    List<String>? includeList,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final include = _serializeList(includeList);

    final ffApiRequestBody = '''
{
  "additional_instructions": "",
  "additional_messages": [
    {
      "attachments": [
        {
          "file_id": "",
          "tools": [
            ""
          ]
        }
      ],
      "content": "",
      "metadata": {},
      "role": "user"
    }
  ],
  "assistant_id": "",
  "instructions": "",
  "max_completion_tokens": 0,
  "max_prompt_tokens": 0,
  "metadata": {},
  "model": "gpt-4o",
  "parallel_tool_calls": false,
  "reasoning_effort": "low",
  "response_format": "",
  "stream": false,
  "temperature": 1,
  "tool_choice": "",
  "tools": [
    ""
  ],
  "top_p": 1,
  "truncation_strategy": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createRun',
      apiUrl: '${baseUrl}/threads/${threadId}/runs',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetRunCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getRun',
      apiUrl: '${baseUrl}/threads/${threadId}/runs/${runId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyRunCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "metadata": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modifyRun',
      apiUrl: '${baseUrl}/threads/${threadId}/runs/${runId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelRunCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'cancelRun',
      apiUrl: '${baseUrl}/threads/${threadId}/runs/${runId}/cancel',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListRunStepsCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? runId = '',
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    List<String>? includeList,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final include = _serializeList(includeList);

    return ApiManager.instance.makeApiCall(
      callName: 'listRunSteps',
      apiUrl: '${baseUrl}/threads/${threadId}/runs/${runId}/steps',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
        'include': include,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetRunStepCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? runId = '',
    String? stepId = '',
    List<String>? includeList,
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();
    final include = _serializeList(includeList);

    return ApiManager.instance.makeApiCall(
      callName: 'getRunStep',
      apiUrl: '${baseUrl}/threads/${threadId}/runs/${runId}/steps/${stepId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'include': include,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SubmitToolOuputsToRunCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? runId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "stream": false,
  "tool_outputs": [
    {
      "output": "",
      "tool_call_id": ""
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'submitToolOuputsToRun',
      apiUrl:
          '${baseUrl}/threads/${threadId}/runs/${runId}/submit_tool_outputs',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateUploadCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "bytes": 0,
  "filename": "",
  "mime_type": "",
  "purpose": "assistants"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createUpload',
      apiUrl: '${baseUrl}/uploads',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelUploadCall {
  Future<ApiCallResponse> call({
    String? uploadId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'cancelUpload',
      apiUrl: '${baseUrl}/uploads/${uploadId}/cancel',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CompleteUploadCall {
  Future<ApiCallResponse> call({
    String? uploadId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "md5": "",
  "part_ids": [
    ""
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'completeUpload',
      apiUrl: '${baseUrl}/uploads/${uploadId}/complete',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class AddUploadPartCall {
  Future<ApiCallResponse> call({
    String? uploadId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'addUploadPart',
      apiUrl: '${baseUrl}/uploads/${uploadId}/parts',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListVectorStoresCall {
  Future<ApiCallResponse> call({
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listVectorStores',
      apiUrl: '${baseUrl}/vector_stores',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateVectorStoreCall {
  Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "chunking_strategy": {},
  "expires_after": {
    "anchor": "last_active_at",
    "days": 0
  },
  "file_ids": [
    ""
  ],
  "metadata": {},
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createVectorStore',
      apiUrl: '${baseUrl}/vector_stores',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteVectorStoreCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteVectorStore',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetVectorStoreCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getVectorStore',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ModifyVectorStoreCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "expires_after": "",
  "metadata": {},
  "name": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'modifyVectorStore',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateVectorStoreFileBatchCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "attributes": {},
  "chunking_strategy": {},
  "file_ids": [
    ""
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createVectorStoreFileBatch',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}/file_batches',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetVectorStoreFileBatchCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? batchId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getVectorStoreFileBatch',
      apiUrl:
          '${baseUrl}/vector_stores/${vectorStoreId}/file_batches/${batchId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CancelVectorStoreFileBatchCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? batchId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'cancelVectorStoreFileBatch',
      apiUrl:
          '${baseUrl}/vector_stores/${vectorStoreId}/file_batches/${batchId}/cancel',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListFilesInVectorStoreBatchCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? batchId = '',
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    String? filter = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listFilesInVectorStoreBatch',
      apiUrl:
          '${baseUrl}/vector_stores/${vectorStoreId}/file_batches/${batchId}/files',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
        'filter': filter,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ListVectorStoreFilesCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    int? limit,
    String? order = '',
    String? after = '',
    String? before = '',
    String? filter = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'listVectorStoreFiles',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}/files',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before,
        'filter': filter,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateVectorStoreFileCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "attributes": {},
  "chunking_strategy": {},
  "file_id": ""
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'createVectorStoreFile',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}/files',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeleteVectorStoreFileCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? fileId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'deleteVectorStoreFile',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}/files/${fileId}',
      callType: ApiCallType.DELETE,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetVectorStoreFileCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? fileId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'getVectorStoreFile',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}/files/${fileId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UpdateVectorStoreFileAttributesCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? fileId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "attributes": {}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'updateVectorStoreFileAttributes',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}/files/${fileId}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RetrieveVectorStoreFileContentCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? fileId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrieveVectorStoreFileContent',
      apiUrl:
          '${baseUrl}/vector_stores/${vectorStoreId}/files/${fileId}/content',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SearchVectorStoreCall {
  Future<ApiCallResponse> call({
    String? vectorStoreId = '',
    String? apiKeyAuth = '',
  }) async {
    final baseUrl = OpenAIAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "filters": "",
  "max_num_results": 0,
  "query": "",
  "ranking_options": {
    "ranker": "auto",
    "score_threshold": 0
  },
  "rewrite_query": false
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'searchVectorStore',
      apiUrl: '${baseUrl}/vector_stores/${vectorStoreId}/search',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'Authorization': 'Bearer ${apiKeyAuth}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End OpenAI API Group Code

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
