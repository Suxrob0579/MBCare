import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDv6lvxf06EzvK7i1qPeS9eFGVlE_Qad30",
            authDomain: "mbcuz-f17d7.firebaseapp.com",
            projectId: "mbcuz-f17d7",
            storageBucket: "mbcuz-f17d7.firebasestorage.app",
            messagingSenderId: "1049337957163",
            appId: "1:1049337957163:web:b230fb0d79336b4e1d136e",
            measurementId: "G-SRMLYJMWJ2"));
  } else {
    await Firebase.initializeApp();
  }
}
