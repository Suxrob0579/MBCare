import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['uz', 'ru', 'en'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? uzText = '',
    String? ruText = '',
    String? enText = '',
  }) =>
      [uzText, ruText, enText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // Register
  {
    'orieq9op': {
      'uz': 'RO\'YXATDAN O\'TISH',
      'en': '',
      'ru': '',
    },
    '8g16x954': {
      'uz': 'Telefon raqam',
      'en': '',
      'ru': '',
    },
    '5tq45pim': {
      'uz': 'Parol',
      'en': '',
      'ru': '',
    },
    'iqdxeie1': {
      'uz': 'Parolni tasdiqlash',
      'en': '',
      'ru': '',
    },
    'v6gy0q2v': {
      'uz': 'Ro\'yxatdan o\'tish',
      'en': '',
      'ru': '',
    },
    '3llbyucd': {
      'uz': 'YOKI',
      'en': '',
      'ru': '',
    },
    'c0hvrdcg': {
      'uz': 'Orqali ro\'yxatdan o\'tish',
      'en': '',
      'ru': '',
    },
    'icds0qkb': {
      'uz': 'Profilingiz mavjud bo\'lsa',
      'en': '',
      'ru': '',
    },
    '6itpmm0z': {
      'uz': 'Tizimga kiring',
      'en': '',
      'ru': '',
    },
  },
  // Home
  {
    '7kcpsp3u': {
      'uz': 'Salom!',
      'en': '',
      'ru': '',
    },
    'pw9ov9mu': {
      'uz': 'Bugun Jasurning holati qanday?',
      'en': '',
      'ru': '',
    },
    'wqz5mqgy': {
      'uz': 'Jasur',
      'en': '',
      'ru': '',
    },
    'wolxwmit': {
      'uz': '8 oy',
      'en': '',
      'ru': '',
    },
    'i6cfjysr': {
      'uz': 'Vazni',
      'en': '',
      'ru': '',
    },
    'r5t1neel': {
      'uz': '7.2 kg',
      'en': '',
      'ru': '',
    },
    'rqkmr0i4': {
      'uz': 'Bo\'yi',
      'en': '',
      'ru': '',
    },
    'yqhyo12b': {
      'uz': '68 cm',
      'en': '',
      'ru': '',
    },
    'madprtsr': {
      'uz': 'Vazn va bo’y o’zgarishini kuzatish',
      'en': '',
      'ru': '',
    },
    'hyg14w97': {
      'uz': 'Muhim',
      'en': '',
      'ru': '',
    },
    'a94vbsm5': {
      'uz': 'Bugungi rejalar',
      'en': '',
      'ru': '',
    },
    'ewi1vi3m': {
      'uz': 'Soat 14:00 da chaqaloqni emlashga olib borish',
      'en': '',
      'ru': '',
    },
    'spe2mw8n': {
      'uz': 'Vaksinalar',
      'en': '',
      'ru': '',
    },
    'om64admu': {
      'uz': 'Chaqaloq qanday vaksinalar olishi kerak?',
      'en': '',
      'ru': '',
    },
    'suslop5y': {
      'uz': 'Resurslar',
      'en': '',
      'ru': '',
    },
    'x170irk6': {
      'uz': 'Maqolalar',
      'en': '',
      'ru': '',
    },
    '0igryyc2': {
      'uz': 'Bolaning rivojlanishi bo\'yicha mutaxassis maslahati',
      'en': '',
      'ru': '',
    },
    'szzg6a5a': {
      'uz': 'Video darslar',
      'en': '',
      'ru': '',
    },
    'iof7363d': {
      'uz':
          'Bolalarni parvarish qilish bo\'yicha qo\'llanmalarni tomosha qiling',
      'en': '',
      'ru': '',
    },
  },
  // HomeBMIcalculator
  {
    'h1zj2np2': {
      'uz': 'TANA VAZNI INDEKSI',
      'en': '',
      'ru': '',
    },
    'ujwb8ge5': {
      'uz': 'HISOBLASH',
      'en': '',
      'ru': '',
    },
    '72yrycks': {
      'uz': 'KO\'RISH',
      'en': '',
      'ru': '',
    },
    '58wcbe7f': {
      'uz': 'STATISTIKA',
      'en': '',
      'ru': '',
    },
    'w6yspjdt': {
      'uz': 'Jasur',
      'en': '',
      'ru': '',
    },
    '7lu70934': {
      'uz': 'Vazni (kg)',
      'en': '',
      'ru': '',
    },
    '6s57mpbp': {
      'uz': 'Vaznini kiriting',
      'en': '',
      'ru': '',
    },
    '6hn0fy41': {
      'uz': 'Bo\'yi (cm)',
      'en': '',
      'ru': '',
    },
    'nf523ibg': {
      'uz': 'Bo\'yini kiriting',
      'en': '',
      'ru': '',
    },
    'h44l4zda': {
      'uz':
          'BMI (Tana vazni indeksi) bo\'y va vazn asosida hisoblanadi. Bu sog\'liq uchun muhim ko\'rsatkich hisoblanadi.',
      'en': '',
      'ru': '',
    },
    '5rjd3xa4': {
      'uz': 'HISOBLASH',
      'en': '',
      'ru': '',
    },
  },
  // Farzandingizhaqidaamalumotbering
  {
    '6jz6yanp': {
      'uz': 'FARZANDINGIZ HAQIDA MA\'LUMOT BERING',
      'en': '',
      'ru': '',
    },
    'hlexw72z': {
      'uz': 'Ismi',
      'en': '',
      'ru': '',
    },
    'c30wrhz7': {
      'uz': 'Farzandingiz ismini kiriting',
      'en': '',
      'ru': '',
    },
    'xtdgu926': {
      'uz': 'Yoshi(yoki oyligi)',
      'en': '',
      'ru': '',
    },
    'vs9y9w23': {
      'uz': 'Farzandingiz yoshini kiriting',
      'en': '',
      'ru': '',
    },
    '9gli2stp': {
      'uz': 'Jinsi',
      'en': '',
      'ru': '',
    },
    '61dh6kkd': {
      'uz': 'Farzandingiz jinsini tanlang',
      'en': '',
      'ru': '',
    },
    'j3mfhji3': {
      'uz': 'Qidirish...',
      'en': '',
      'ru': '',
    },
    'vft8hco4': {
      'uz': 'O\'g\'il bola',
      'en': '',
      'ru': '',
    },
    'bdmyk1zl': {
      'uz': 'Qiz bola',
      'en': '',
      'ru': '',
    },
    '0s5p2fug': {
      'uz': 'Rasmi(ixtiyoriy)',
      'en': '',
      'ru': '',
    },
    'c14ckxat': {
      'uz': 'Rasm yuklash uchun bosing',
      'en': '',
      'ru': '',
    },
    'y93plmeu': {
      'uz': 'YAKUNLASH',
      'en': '',
      'ru': '',
    },
  },
  // Userinfo
  {
    'eeuz7ld2': {
      'uz': 'O\'ZINGIZ HAQINGIZDA MA\'LUMOT BERING',
      'en': '',
      'ru': '',
    },
    '1gb47plb': {
      'uz': 'Ismingiz',
      'en': '',
      'ru': '',
    },
    '9v86h6km': {
      'uz': ' Ismingizni kiriting',
      'en': '',
      'ru': '',
    },
    'j3ji9ep6': {
      'uz': 'Yoshingiz',
      'en': '',
      'ru': '',
    },
    'e5votzsr': {
      'uz': 'Yoshingizni kiriting',
      'en': '',
      'ru': '',
    },
    '0zy0ee8u': {
      'uz': 'Ro\'lingiz',
      'en': '',
      'ru': '',
    },
    'cn9suhhd': {
      'uz': 'Ro\'lingizni tanlang',
      'en': '',
      'ru': '',
    },
    'm5adk9fz': {
      'uz': 'Qidirish...',
      'en': '',
      'ru': '',
    },
    'qi4bplgx': {
      'uz': 'Ota',
      'en': '',
      'ru': '',
    },
    'kzir85wy': {
      'uz': 'Ona',
      'en': '',
      'ru': '',
    },
    'a436li2c': {
      'uz': 'Farzand soni',
      'en': '',
      'ru': '',
    },
    'e1aske25': {
      'uz': 'Farzand sonini kiriting',
      'en': '',
      'ru': '',
    },
    'p6ei3v08': {
      'uz': 'KEYINGI',
      'en': '',
      'ru': '',
    },
  },
  // Intro
  {
    'pw38l692': {
      'uz': 'XUSH KELIBSIZ!',
      'en': '',
      'ru': '',
    },
    '4ud4y74f': {
      'uz': 'Ilovadan foydalanish uchun ro\'yxatdan o\'ting.',
      'en': '',
      'ru': '',
    },
    '747t2w84': {
      'uz': 'RO\'YXATDAN O\'TISH',
      'en': '',
      'ru': '',
    },
    '77afo7k4': {
      'uz': 'Profilingiz mavjud bo\'lsa',
      'en': '',
      'ru': '',
    },
    'wvhupvnu': {
      'uz': 'Tizimga kiring',
      'en': '',
      'ru': '',
    },
  },
  // BMIshow
  {
    'ttdr5vwj': {
      'uz': 'TANA VAZNI INDEKSI',
      'en': '',
      'ru': '',
    },
    'zhg1baj9': {
      'uz': 'HISOBLASH',
      'en': '',
      'ru': '',
    },
    'mbrzsu1t': {
      'uz': 'KO\'RISH',
      'en': '',
      'ru': '',
    },
    'ufyr01ie': {
      'uz': 'STATISTIKA',
      'en': '',
      'ru': '',
    },
    'd0v5k2fi': {
      'uz': 'BMI Shkalasi',
      'en': '',
      'ru': '',
    },
    'yo4nnmy6': {
      'uz': 'Kam',
      'en': '',
      'ru': '',
    },
    '9qojv8a6': {
      'uz': 'Normal',
      'en': '',
      'ru': '',
    },
    'p3d5xoil': {
      'uz': 'Ortiqcha',
      'en': '',
      'ru': '',
    },
    'weog4mqn': {
      'uz': '15',
      'en': '',
      'ru': '',
    },
    'qo1bnzkt': {
      'uz': '20',
      'en': '',
      'ru': '',
    },
    '3jec2jy2': {
      'uz': '25',
      'en': '',
      'ru': '',
    },
    'caowniko': {
      'uz': '30',
      'en': '',
      'ru': '',
    },
    '7roy5dq2': {
      'uz': 'Chaqaloqning tana vazni indeksi:',
      'en': '',
      'ru': '',
    },
    '4qb2kq8t': {
      'uz': '20.4',
      'en': '',
      'ru': '',
    },
    'xt2w5fna': {
      'uz': 'YAXSHI',
      'en': '',
      'ru': '',
    },
    'wur6j2ny': {
      'uz': 'BMI Kategoriyalari',
      'en': '',
      'ru': '',
    },
    'ciizpwv6': {
      'uz': 'Kam vazn: < 18.5',
      'en': '',
      'ru': '',
    },
    '536q69jn': {
      'uz': 'Normal vazn: 18.5 - 24.9',
      'en': '',
      'ru': '',
    },
    'v74zeo38': {
      'uz': 'Ortiqcha vazn: 25 - 29.9',
      'en': '',
      'ru': '',
    },
    '8097h8r2': {
      'uz': 'Semizlik: ≥ 30',
      'en': '',
      'ru': '',
    },
    '0d3lx5n5': {
      'uz': 'Qayta hisoblash',
      'en': '',
      'ru': '',
    },
  },
  // Profile
  {
    'py3eie8b': {
      'uz': 'PROFIL',
      'en': '',
      'ru': '',
    },
    'bravnawd': {
      'uz': 'KAMOLA',
      'en': '',
      'ru': '',
    },
    'omluk538': {
      'uz': 'KUNDALIK',
      'en': '',
      'ru': '',
    },
    'k77mmtu7': {
      'uz': 'Kunlik rejalarni kiritib boring',
      'en': '',
      'ru': '',
    },
    '1w7vc3w5': {
      'uz': 'LAHZALAR',
      'en': '',
      'ru': '',
    },
    'tbtuc416': {
      'uz': 'Farzandingiz ilk qadamlari va boshqalarni joylang.',
      'en': '',
      'ru': '',
    },
    'oxrufb7r': {
      'uz': 'TAKLIFLARINGIZ BORMI?',
      'en': '',
      'ru': '',
    },
    'auovh2fy': {
      'uz': 'Biz bilan bo\'lishing',
      'en': '',
      'ru': '',
    },
  },
  // Kundalik
  {
    'gsh6s1ai': {
      'uz': 'KUNDALIK',
      'en': '',
      'ru': '',
    },
    'd6tixoli': {
      'uz': 'Oxirgi kiritmalar',
      'en': '',
      'ru': '',
    },
    'rl0oer21': {
      'uz': '4/13/2024',
      'en': '',
      'ru': '',
    },
    'k5cggnoh': {
      'uz': 'Chaqaloqni tibbiy ko\'rikka olib borish',
      'en': '',
      'ru': '',
    },
  },
  // Yangikiritma
  {
    'mgxzxjla': {
      'uz': 'YANGI KIRITMA',
      'en': '',
      'ru': '',
    },
    '6srjtgjd': {
      'uz': 'Mavzu',
      'en': '',
      'ru': '',
    },
    '12x0hfwp': {
      'uz': 'Kiritma uchun sarlavha yozing',
      'en': '',
      'ru': '',
    },
    'z9pozn7t': {
      'uz': 'Hikoya',
      'en': '',
      'ru': '',
    },
    'wkc4vjih': {
      'uz': 'Biron nima yozing',
      'en': '',
      'ru': '',
    },
    '9e92xjr0': {
      'uz': 'Saqlash',
      'en': '',
      'ru': '',
    },
  },
  // Medicaldrugs
  {
    'blikmlwa': {
      'uz': 'DORI\n VA VAKSINALAR',
      'en': '',
      'ru': '',
    },
    'hqyv4wg6': {
      'uz': 'MA\'LUMOT OLING',
      'en': '',
      'ru': '',
    },
    'ksmvzrk7': {
      'uz': 'DORI DARMONLAR',
      'en': '',
      'ru': '',
    },
    '4jiayu30': {
      'uz': 'VAKSINALAR',
      'en': '',
      'ru': '',
    },
    'do5woe14': {
      'uz': 'YAQIN ATROFDAGI DORIXONA VA EMLASH MARKAZLARI',
      'en': '',
      'ru': '',
    },
  },
  // Recommendations
  {
    '5twkhke6': {
      'uz': 'TAVSIYALAR',
      'en': '',
      'ru': '',
    },
    'qq6eg0lj': {
      'uz': 'ERTAKLAR',
      'en': '',
      'ru': '',
    },
    'k0kbmn6m': {
      'uz': 'OZIQLANISH',
      'en': '',
      'ru': '',
    },
    'c8udesku': {
      'uz': 'O\'YINLAR',
      'en': '',
      'ru': '',
    },
    '2tqv5d2y': {
      'uz': 'RUHIYAT',
      'en': '',
      'ru': '',
    },
    'hkd3bl38': {
      'uz': 'TA\'LIM',
      'en': '',
      'ru': '',
    },
    '60nqmft0': {
      'uz': 'SOG\'LIQ',
      'en': '',
      'ru': '',
    },
    'rwn976qn': {
      'uz': 'Eng so\'nggi tavsiyalar',
      'en': '',
      'ru': '',
    },
    '6lczpgp3': {
      'uz': 'Yangi ertaklar to\'plami',
      'en': '',
      'ru': '',
    },
    'ni7eiyop': {
      'uz': 'Bolalar uchun qiziqarli ertaklar',
      'en': '',
      'ru': '',
    },
    'eh13b04n': {
      'uz': 'Sog\'lom ovqatlanish',
      'en': '',
      'ru': '',
    },
    '6m03u5vg': {
      'uz': 'Bolalar uchun foydali taomlar',
      'en': '',
      'ru': '',
    },
  },
  // ComunicationChatAI
  {
    'mnoky4c8': {
      'uz': 'CHATBOT',
      'en': '',
      'ru': '',
    },
    'c472wsgc': {
      'uz': 'UMUMIY CHAT',
      'en': '',
      'ru': '',
    },
    '0h5l78og': {
      'uz': 'ALOQA',
      'en': '',
      'ru': '',
    },
    'd8qkjglp': {
      'uz': 'Sizga qanday yordam bera olaman?',
      'en': '',
      'ru': '',
    },
    'n0ixy4sc': {
      'uz': 'Qorin damlanishining sabablari',
      'en': '',
      'ru': '',
    },
    'yhi6nirb': {
      'uz': 'Vaksinalarning nojo\'ya ta\'sirlari',
      'en': '',
      'ru': '',
    },
    '4gno62j6': {
      'uz': 'Matn kiriting',
      'en': '',
      'ru': '',
    },
    'snnbhkix': {
      'uz': 'MULOQOT',
      'en': '',
      'ru': '',
    },
  },
  // Lahzalar
  {
    'p7k6df4q': {
      'uz': 'LAHZALAR',
      'en': '',
      'ru': '',
    },
    'n8f7bjwp': {
      'uz': 'Birinchi kulgu',
      'en': '',
      'ru': '',
    },
    '49tlxh7d': {
      'uz': 'Farzandingizning birinchi tabassum lahzalari',
      'en': '',
      'ru': '',
    },
    '8cyusbqb': {
      'uz': 'Birinchi qadamlar',
      'en': '',
      'ru': '',
    },
    'df40rdx5': {
      'uz': 'Farzandingizning birinchi qadamlari',
      'en': '',
      'ru': '',
    },
    'ute33flb': {
      'uz': 'Yangi kiritish',
      'en': '',
      'ru': '',
    },
  },
  // YangiLahza
  {
    'eqx1opgr': {
      'uz': 'YANGI LAHZA',
      'en': '',
      'ru': '',
    },
    'f4duh4ue': {
      'uz': 'Mavzu',
      'en': '',
      'ru': '',
    },
    'dh4i71nd': {
      'uz': 'Lahza uchun sarlavha yozing',
      'en': '',
      'ru': '',
    },
    'd8lceyqp': {
      'uz': 'Hikoya',
      'en': '',
      'ru': '',
    },
    '2be040ax': {
      'uz': 'Biron nima yozing',
      'en': '',
      'ru': '',
    },
    '3n704knk': {
      'uz': 'Saqlash',
      'en': '',
      'ru': '',
    },
  },
  // Yangitaklif
  {
    '9pkk3sid': {
      'uz': 'YANGI TAKLIF',
      'en': '',
      'ru': '',
    },
    'cudtka7l': {
      'uz': 'Mavzu',
      'en': '',
      'ru': '',
    },
    '99e13kee': {
      'uz': 'Taklif uchun sarlavha yozing',
      'en': '',
      'ru': '',
    },
    'c22kdaol': {
      'uz': 'Hikoya',
      'en': '',
      'ru': '',
    },
    'lb7n65gi': {
      'uz': 'Biron nima yozing',
      'en': '',
      'ru': '',
    },
    'r00yk6si': {
      'uz': 'Saqlash',
      'en': '',
      'ru': '',
    },
  },
  // Ertaklar
  {
    '651q3mf0': {
      'uz': 'HIKOYALAR',
      'en': '',
      'ru': '',
    },
    'bdr27mme': {
      'uz': 'Qanday hikoyani qidimoqchisiz?',
      'en': '',
      'ru': '',
    },
    'cxed9wbf': {
      'uz': 'Zumrad va Qimmat',
      'en': '',
      'ru': '',
    },
    'lhw5rute': {
      'uz': 'Ushbu hikoya yaxshilik va yomonlik haqida',
      'en': '',
      'ru': '',
    },
    'npqakqto': {
      'uz': 'Boy ila Kambag\'al',
      'en': '',
      'ru': '',
    },
    'ptg4sifd': {
      'uz': 'Boylik va kambag\'allik haqidagi ibratli hikoya',
      'en': '',
      'ru': '',
    },
    '8v2ar3vy': {
      'uz': 'Qarg\'a bilan Qo\'zi',
      'en': '',
      'ru': '',
    },
    'ja231k7f': {
      'uz':
          'Ochko‘zligi va aqlsizlik bilan harakat qilish oqibatlari haqida hikoya',
      'en': '',
      'ru': '',
    },
    'oq4byctr': {
      'uz': 'Uch Og\'a-ini Botirlar',
      'en': '',
      'ru': '',
    },
    '1ct9sw1w': {
      'uz': 'Jasorat va birodarlik haqidagi ajoyib hikoya',
      'en': '',
      'ru': '',
    },
    'ulmjxihb': {
      'uz': 'Ko\'proq hikoyalarni ko\'rish',
      'en': '',
      'ru': '',
    },
  },
  // chaqaloquchun
  {
    '9onog7ae': {
      'uz': 'OZIQLANISH',
      'en': '',
      'ru': '',
    },
    '8ar6jq71': {
      'uz': 'Chaqaloq uchun',
      'en': '',
      'ru': '',
    },
    '9336ae74': {
      'uz': 'Ona uchun',
      'en': '',
      'ru': '',
    },
    '27c3o7ne': {
      'uz': 'Bugungi tavsiyalar',
      'en': '',
      'ru': '',
    },
    'dsadc8w3': {
      'uz': 'Olma pyuresi',
      'en': '',
      'ru': '',
    },
    'he9dtput': {
      'uz': 'Vitaminlarga boy va oson hazm qilinadi',
      'en': '',
      'ru': '',
    },
    '4yl7h7jk': {
      'uz': '6+ oylik',
      'en': '',
      'ru': '',
    },
    'kc9psk1u': {
      'uz': 'Banana Mix',
      'en': '',
      'ru': '',
    },
    'zy7croza': {
      'uz': 'Tabiiy shirinlik bilan silliq tuzilish',
      'en': '',
      'ru': '',
    },
    'f6gjh73l': {
      'uz': '6+ oylik',
      'en': '',
      'ru': '',
    },
    '6im0ewr9': {
      'uz': 'Shirin kartoshka',
      'en': '',
      'ru': '',
    },
    '8smlaufa': {
      'uz': 'Ko\'p miqdorda tola va beta-karotin',
      'en': '',
      'ru': '',
    },
    'rfnj9j1i': {
      'uz': '7+ oylik',
      'en': '',
      'ru': '',
    },
    'vgb57yic': {
      'uz': 'Yosh uchun mos oziq-ovqatlar',
      'en': '',
      'ru': '',
    },
    'ubmgkk5c': {
      'uz': '4-6 Oylk',
      'en': '',
      'ru': '',
    },
    '81f30uou': {
      'uz': '6-8 Oylik',
      'en': '',
      'ru': '',
    },
    'yqwpnr85': {
      'uz': '8-10 Oylik',
      'en': '',
      'ru': '',
    },
    '463n2ul7': {
      'uz': '10-12 Oylik',
      'en': '',
      'ru': '',
    },
  },
  // onauchun
  {
    'moy0har0': {
      'uz': 'OZIQLANISH',
      'en': '',
      'ru': '',
    },
    'tz7q6jyz': {
      'uz': 'Chaqaloq uchun',
      'en': '',
      'ru': '',
    },
    'e5bxs6kj': {
      'uz': 'Ona uchun',
      'en': '',
      'ru': '',
    },
    '5ies91sx': {
      'uz': 'Bugungi tavsiyalar',
      'en': '',
      'ru': '',
    },
    '6d9nfn7y': {
      'uz': 'Asalli Grek Yogurt',
      'en': '',
      'ru': '',
    },
    '400cs68b': {
      'uz': 'Proteinlarga boy, immunitetni mustahkamlashga yordam beradi',
      'en': '',
      'ru': '',
    },
    'fmfna2ny': {
      'uz': 'Immunitet ',
      'en': '',
      'ru': '',
    },
    'sejjlhzr': {
      'uz': 'Laktasmuzi',
      'en': '',
      'ru': '',
    },
    'onhn1hyd': {
      'uz':
          'Sut ajralishini rag‘batlantiradi, tabiiy tarkibi bilan onaning quvvatini oshiradi\n\n\n',
      'en': '',
      'ru': '',
    },
    'vupxzu8y': {
      'uz': 'Sut ko‘paytiruvchi',
      'en': '',
      'ru': '',
    },
    'povt2mdc': {
      'uz': 'Blinchik',
      'en': '',
      'ru': '',
    },
    'xqkw67fe': {
      'uz':
          'Energiya beradi va to‘qlik hissini ta’minlaydi, emizikli onalar uchun mazali nonushta tanlovi',
      'en': '',
      'ru': '',
    },
    'ioo7lc5i': {
      'uz': 'Energiya',
      'en': '',
      'ru': '',
    },
    'thfjv84h': {
      'uz': 'Foydali ozuqalar',
      'en': '',
      'ru': '',
    },
    'dqn3gy20': {
      'uz': 'Sabzavotlar',
      'en': '',
      'ru': '',
    },
    'f1gsgrbk': {
      'uz': 'Mevalar',
      'en': '',
      'ru': '',
    },
    'dt3i55sc': {
      'uz': 'Oqsillar',
      'en': '',
      'ru': '',
    },
    '0rtw1iyr': {
      'uz': 'Kunlik suv balansi',
      'en': '',
      'ru': '',
    },
    'a7fm6v2m': {
      'uz': 'Tavsiya etilgan: 2.5 litr',
      'en': '',
      'ru': '',
    },
    'sdat8nep': {
      'uz': '65%',
      'en': '',
      'ru': '',
    },
    'svw1l9h2': {
      'uz': 'Ozuqa qo\'shimchalari',
      'en': '',
      'ru': '',
    },
    'ngz0xblo': {
      'uz': 'Vitaminlar',
      'en': '',
      'ru': '',
    },
    'lz42qpqm': {
      'uz': 'Kalsiy',
      'en': '',
      'ru': '',
    },
    '79df633t': {
      'uz': 'Temir',
      'en': '',
      'ru': '',
    },
  },
  // Oyinlar
  {
    'whwq4e0z': {
      'uz': 'O\'YINLAR',
      'en': '',
      'ru': '',
    },
    '2c87bz1u': {
      'uz': 'Yangi o\'yinlar',
      'en': '',
      'ru': '',
    },
    '44l8yo9o': {
      'uz': 'Farzandingiz uchun eng yaxshi o\'yinlar',
      'en': '',
      'ru': '',
    },
    '982u32a4': {
      'uz': 'Tavsiya etilgan o\'yinlar',
      'en': '',
      'ru': '',
    },
    'cb8xt21d': {
      'uz': 'Ranglar o\'rganish',
      'en': '',
      'ru': '',
    },
    '98q1w02e': {
      'uz': '2-4 yosh',
      'en': '',
      'ru': '',
    },
    'qqo0ar1p': {
      'uz': 'O\'ynash',
      'en': '',
      'ru': '',
    },
    '1wjw17n0': {
      'uz': 'Hayvonlar',
      'en': '',
      'ru': '',
    },
    'ppct3a07': {
      'uz': '1-3 yosh',
      'en': '',
      'ru': '',
    },
    'xye2s5ty': {
      'uz': 'O\'ynash',
      'en': '',
      'ru': '',
    },
    '6fgu6ee7': {
      'uz': 'Musiqa',
      'en': '',
      'ru': '',
    },
    'mzxdva8e': {
      'uz': '1-5 yosh',
      'en': '',
      'ru': '',
    },
    'ppflyin2': {
      'uz': 'O\'ynash',
      'en': '',
      'ru': '',
    },
    'a5a0b19t': {
      'uz': 'Boshqotirmalar',
      'en': '',
      'ru': '',
    },
    '2rx7gaj5': {
      'uz': '3-6 yosh',
      'en': '',
      'ru': '',
    },
    'zjh15m7i': {
      'uz': 'O\'ynash',
      'en': '',
      'ru': '',
    },
    'hltr9ncx': {
      'uz': 'Eng mashhur o\'yinlar',
      'en': '',
      'ru': '',
    },
    'tv2x2whb': {
      'uz': 'Alifbo o\'rganish',
      'en': '',
      'ru': '',
    },
    '14tfs5no': {
      'uz': 'Harflarni o\'rganish va so\'zlar tuzish uchun ajoyib o\'yin',
      'en': '',
      'ru': '',
    },
    'nhvsf2mc': {
      'uz': '4-7 yosh',
      'en': '',
      'ru': '',
    },
    'zliik48t': {
      'uz': 'O\'ynash',
      'en': '',
      'ru': '',
    },
    'pqjzouxy': {
      'uz': 'Raqamlar',
      'en': '',
      'ru': '',
    },
    'nz5y5psn': {
      'uz': 'Raqamlarni o\'rganish va sanashni o\'rgatadigan qiziqarli o\'yin',
      'en': '',
      'ru': '',
    },
    'sh1lsdww': {
      'uz': '2-5 yosh',
      'en': '',
      'ru': '',
    },
    '1z5pwkn5': {
      'uz': 'O\'ynash',
      'en': '',
      'ru': '',
    },
  },
  // Darslar
  {
    'rctnvw31': {
      'uz': 'VIDEO DARSLAR',
      'en': '',
      'ru': '',
    },
    '3ijy08lm': {
      'uz': '32 ta darslar',
      'en': '',
      'ru': '',
    },
    'pt9jmu38': {
      'uz': '01:09:23',
      'en': '',
      'ru': '',
    },
    '7sqdvah8': {
      'uz':
          'Bolani to\'g\'ri va xavfsiz parvarish qilish bo\'yicha video darslar',
      'en': '',
      'ru': '',
    },
    'okjvz18t': {
      'uz':
          'Yangi tug\'ilgan chaqaloqni parvarish qilish bo\'yicha mutaxassislardan maslahatlar',
      'en': '',
      'ru': '',
    },
    'zdlt8xzj': {
      'uz': 'Darslarni ko\'rish',
      'en': '',
      'ru': '',
    },
    '1vj1rq0x': {
      'uz': '20 ta darslar',
      'en': '',
      'ru': '',
    },
    'hbda4grf': {
      'uz': '55:30',
      'en': '',
      'ru': '',
    },
    'vkybgbnu': {
      'uz': 'Tug’riqdan keyin, sog’liqni tiklash bo‘yicha video darslar',
      'en': '',
      'ru': '',
    },
    'rlp5s545': {
      'uz': 'Sog\'liqni tiklash bo\'yicha mutaxassislardan maslahatlar',
      'en': '',
      'ru': '',
    },
    'rgqanfvp': {
      'uz': 'Darslarni ko\'rish',
      'en': '',
      'ru': '',
    },
    'mg40wtua': {
      'uz': 'Ko\'proq yuklash',
      'en': '',
      'ru': '',
    },
  },
  // Ruhiyat
  {
    'ck0qx07x': {
      'uz': 'RUHIYAT',
      'en': '',
      'ru': '',
    },
    's3g1plnc': {
      'uz': 'Bugungi ilhom',
      'en': '',
      'ru': '',
    },
    '7kg1kwrz': {
      'uz':
          '\"Har bir kun yangi imkoniyatlar bilan to\'la. O\'zingizga g\'amxo\'rlik qilish - oilangizga g\'amxo\'rlik qilishning bir qismidir.\"',
      'en': '',
      'ru': '',
    },
    '8xxc9spn': {
      'uz': 'Bugungi kayfiyatingiz',
      'en': '',
      'ru': '',
    },
    '58mdq03z': {
      'uz': '😊',
      'en': '',
      'ru': '',
    },
    'zn8wjhdv': {
      'uz': 'Xursand',
      'en': '',
      'ru': '',
    },
    '8918qwhw': {
      'uz': '😌',
      'en': '',
      'ru': '',
    },
    'pf4pt1wt': {
      'uz': 'Tinch',
      'en': '',
      'ru': '',
    },
    's36smtdn': {
      'uz': '😓',
      'en': '',
      'ru': '',
    },
    '9nmz4mrl': {
      'uz': 'Charchagan',
      'en': '',
      'ru': '',
    },
    'b901390l': {
      'uz': '😟',
      'en': '',
      'ru': '',
    },
    'j2gbrdbq': {
      'uz': 'Tashvishli',
      'en': '',
      'ru': '',
    },
    '4vgk130g': {
      'uz': '😴',
      'en': '',
      'ru': '',
    },
    't6cie432': {
      'uz': 'Uyqusiz',
      'en': '',
      'ru': '',
    },
    '0tlww0f3': {
      'uz': 'Bugungi tavsiyalar',
      'en': '',
      'ru': '',
    },
    '7qe1e8k7': {
      'uz': '5 daqiqa chuqur nafas olish mashqi',
      'en': '',
      'ru': '',
    },
    'zfa0qigm': {
      'uz': 'Kundalik yozish (10 daqiqa)',
      'en': '',
      'ru': '',
    },
    '9s0uq7mo': {
      'uz': 'Qisqa sayr (15 daqiqa)',
      'en': '',
      'ru': '',
    },
    'b12kw3fw': {
      'uz': 'Suv ichishni unutmang (2 litr)',
      'en': '',
      'ru': '',
    },
    'rm9egpuy': {
      'uz': 'Kundalik eslatma',
      'en': '',
      'ru': '',
    },
    'e686geav': {
      'uz':
          'Bugun o\'zingizga nisbatan mehribon bo\'ling. Bir daqiqa to\'xtang va o\'zingizga rahmat ayting.',
      'en': '',
      'ru': '',
    },
    '946td6yw': {
      'uz': 'Psixologdan maslahatlar',
      'en': '',
      'ru': '',
    },
    '0kfbs57l': {
      'uz':
          'Stressni kamaytirish uchun \\\"5-4-3-2-1\\\" usulini sinab ko\'ring: 5 ta ko\'rinadigan narsa, 4 ta his qilinadigan narsa, 3 ta eshitiladigan tovush, 2 ta hidlaydigan hid va 1 ta ta\'m toping.',
      'en': '',
      'ru': '',
    },
  },
  // Talim
  {
    'i9zanz74': {
      'uz': 'TA\'LIM',
      'en': '',
      'ru': '',
    },
    '2yedqp07': {
      'uz': 'Bugungi ta\'limiy mashg\'ulot',
      'en': '',
      'ru': '',
    },
    '92i72w0v': {
      'uz': 'Ranglarni o\'rganish uchun mevalardan foydalaning',
      'en': '',
      'ru': '',
    },
    'ft7x09cv': {
      'uz': 'Boshlash',
      'en': '',
      'ru': '',
    },
    '7hehv2c3': {
      'uz': 'Ta\'limiy mashg\'ulotlar',
      'en': '',
      'ru': '',
    },
    '2wssokk6': {
      'uz': 'Ranglar va tovushlar bilan tanishuv',
      'en': '',
      'ru': '',
    },
    'h4njpy9c': {
      'uz': '6 ta mashg\'ulot',
      'en': '',
      'ru': '',
    },
    'antlw84d': {
      'uz': 'Sensor o\'yinlar',
      'en': '',
      'ru': '',
    },
    '4dmo0c2i': {
      'uz': '8 ta mashg\'ulot',
      'en': '',
      'ru': '',
    },
    '9xa7s3vi': {
      'uz': 'Qo\'shiq va she\'rlar',
      'en': '',
      'ru': '',
    },
    '823lyt1n': {
      'uz': '5 ta mashg\'ulot',
      'en': '',
      'ru': '',
    },
    'y14aogh4': {
      'uz': 'Harakatli o\'yinlar',
      'en': '',
      'ru': '',
    },
    'l8buakv2': {
      'uz': '7 ta mashg\'ulot',
      'en': '',
      'ru': '',
    },
    'gusiowic': {
      'uz': 'O\'rganilgan mashg\'ulotlar',
      'en': '',
      'ru': '',
    },
    '5kb5i4xg': {
      'uz': 'Haftalik progress',
      'en': '',
      'ru': '',
    },
    '8vh9hurn': {
      'uz': '12/30',
      'en': '',
      'ru': '',
    },
  },
  // sogliq
  {
    'w22cdo4q': {
      'uz': 'SOG\'LIQ',
      'en': '',
      'ru': '',
    },
    'bjla4soc': {
      'uz': 'Bugungi sog\'lom odat',
      'en': '',
      'ru': '',
    },
    '38x973fp': {
      'uz': 'Har soatda bir stakan suv iching',
      'en': '',
      'ru': '',
    },
    'ztv410g2': {
      'uz': 'Uy sharoitida oddiy mashqlar',
      'en': '',
      'ru': '',
    },
    '4txsykc8': {
      'uz': 'Kunlik 15 daqiqalik mashqlar sizning energiyangizni oshiradi',
      'en': '',
      'ru': '',
    },
    'xxrmvb78': {
      'uz': 'Ko\'proq',
      'en': '',
      'ru': '',
    },
    '3nnualn2': {
      'uz': 'To\'g\'ri ovqatlanish bo\'yicha maslahatlar',
      'en': '',
      'ru': '',
    },
    '1kemupke': {
      'uz': 'Sog\'lom va muvozanatli ovqatlanish bo\'yicha foydali maslahatlar',
      'en': '',
      'ru': '',
    },
    't7xiz4bb': {
      'uz': 'Ko\'proq',
      'en': '',
      'ru': '',
    },
    'xev11ckg': {
      'uz': 'Uyqu va dam olish',
      'en': '',
      'ru': '',
    },
    '25nxjauj': {
      'uz': 'Yaxshi uyqu va dam olish bo\'yicha tavsiyalar',
      'en': '',
      'ru': '',
    },
    'dx9h685f': {
      'uz': 'Ko\'proq',
      'en': '',
      'ru': '',
    },
    '4yb72w1n': {
      'uz': 'Salomatlik bo\'yicha eslatmalar',
      'en': '',
      'ru': '',
    },
    'yrvh1uth': {
      'uz': 'Kundalik sog\'liq va farovonlik uchun muhim eslatmalar',
      'en': '',
      'ru': '',
    },
    'ohnfeio8': {
      'uz': 'Ko\'proq',
      'en': '',
      'ru': '',
    },
  },
  // Maqolalar
  {
    'wszw90ks': {
      'uz': 'MAQOLALAR',
      'en': '',
      'ru': '',
    },
    'bi6hf3ou': {
      'uz': 'Yangi tug‘ilgan chaqaloqni to‘g‘ri ovqatlantirish bo‘yicha maqola',
      'en': '',
      'ru': '',
    },
    'idczswiw': {
      'uz':
          'Chaqaloqni emizish tartibi, onaning ovqatlanishi va ilk kunlardagi muhim ovqatlantirish qoidalari haqida.',
      'en': '',
      'ru': '',
    },
    'i63uqvkh': {
      'uz': 'Maqolani o\'qish',
      'en': '',
      'ru': '',
    },
    'd0zt5p5r': {
      'uz': 'Chaqaloqning uyqu tartibini shakllantirish bo‘yicha maqola',
      'en': '',
      'ru': '',
    },
    'trgtoepp': {
      'uz':
          'Bolangizni tinch va sog‘lom uxlatish, uyqu muhitini tayyorlash va tungi uyg‘onishlarni kamaytirish bo‘yicha maslahatlar.',
      'en': '',
      'ru': '',
    },
    '9sn9fxen': {
      'uz': 'Maqolani o\'qish',
      'en': '',
      'ru': '',
    },
    'opxrw7rl': {
      'uz': 'Ko\'proq yuklash',
      'en': '',
      'ru': '',
    },
  },
  // calculator_section3
  {
    'mxnsvvrc': {
      'uz': 'TANA VAZNI INDEKSI',
      'en': '',
      'ru': '',
    },
    'vet4hjk1': {
      'uz': 'HISOBLASH',
      'en': '',
      'ru': '',
    },
    'jx1rskvq': {
      'uz': 'KO\'RISH',
      'en': '',
      'ru': '',
    },
    '8or6cwve': {
      'uz': 'STATISTIKA',
      'en': '',
      'ru': '',
    },
    'dhhxprjv': {
      'uz': 'Tana vazni indeksi (BMI)',
      'en': '',
      'ru': '',
    },
    'ceeuw58h': {
      'uz': 'Joriy: 24.5',
      'en': '',
      'ru': '',
    },
    'w2pqo3cy': {
      'uz': 'O\'rtacha: 23.8',
      'en': '',
      'ru': '',
    },
    'mqwfimzc': {
      'uz': 'Vazn (kg)',
      'en': '',
      'ru': '',
    },
    'yw9fpyst': {
      'uz': 'Joriy: 75.2 kg',
      'en': '',
      'ru': '',
    },
    'xad8zj0u': {
      'uz': 'O\'rtacha: 73.8 kg',
      'en': '',
      'ru': '',
    },
    'x5sd09yb': {
      'uz': 'Bo\'y uzunligi (cm)',
      'en': '',
      'ru': '',
    },
    '382ahli1': {
      'uz': 'Joriy: 175 cm',
      'en': '',
      'ru': '',
    },
    '7mwac6y2': {
      'uz': 'O\'rtacha: 175 cm',
      'en': '',
      'ru': '',
    },
    'frzqur5q': {
      'uz': 'Yangi ma\'lumot qo\'shish',
      'en': '',
      'ru': '',
    },
  },
  // drugsforbaby
  {
    '9zso9qhc': {
      'uz': 'DORI-DARMONLAR',
      'en': '',
      'ru': '',
    },
    'v5kg4thx': {
      'uz': 'Chaqaloq uchun',
      'en': '',
      'ru': '',
    },
    'vw0eriiv': {
      'uz': 'Ona uchun',
      'en': '',
      'ru': '',
    },
    'ukxr8tad': {
      'uz': 'Qanday dorini qidirmoqchisiz?',
      'en': '',
      'ru': '',
    },
    '3a8185il': {
      'uz': 'Infacol',
      'en': '',
      'ru': '',
    },
    'mldqbont': {
      'uz': 'Ichakdagi gazlar va kolikaga qarshi samarali tomchi',
      'en': '',
      'ru': '',
    },
    'xe55wprf': {
      'uz': 'Espumisan Baby',
      'en': '',
      'ru': '',
    },
    '1uh176dr': {
      'uz': 'Yangi tug‘ilganlar uchun gazga qarshi vosita',
      'en': '',
      'ru': '',
    },
    'wth4cp5t': {
      'uz': 'Aquamaris',
      'en': '',
      'ru': '',
    },
    'chqm3cku': {
      'uz': 'Burun tozalash uchun dengiz suviga asoslangan spreyi',
      'en': '',
      'ru': '',
    },
    'rrxuds4j': {
      'uz': 'D-Vitamin 3',
      'en': '',
      'ru': '',
    },
    '5q463up6': {
      'uz': 'Rahit profilaktikasi uchun yangi tug‘ilganlarga beriladi',
      'en': '',
      'ru': '',
    },
    'lfprtai3': {
      'uz': 'Ko\'proq yuklash',
      'en': '',
      'ru': '',
    },
    'ygaroojv': {
      'uz':
          'Har qanday dori-darmonni ishlatishdan oldin shifokor bilan maslahatlashing',
      'en': '',
      'ru': '',
    },
    '2s23crys': {
      'uz': 'Muhim ma\'lumotlar',
      'en': '',
      'ru': '',
    },
    'akbv23nb': {
      'uz': 'Dori qabul qilish vaqti',
      'en': '',
      'ru': '',
    },
    'sat58rew': {
      'uz': 'Kuniga 2-3 marta',
      'en': '',
      'ru': '',
    },
    '0b1n5o8b': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    'anvh34fa': {
      'uz': 'Allergik reaksiyalarga e\'tibor bering',
      'en': '',
      'ru': '',
    },
  },
  // drugsformom
  {
    '9j4wt00i': {
      'uz': 'DORI-DARMONLAR',
      'en': '',
      'ru': '',
    },
    'oki801m2': {
      'uz': 'Chaqaloq uchun',
      'en': '',
      'ru': '',
    },
    '2kp3ij30': {
      'uz': 'Ona uchun',
      'en': '',
      'ru': '',
    },
    'woxbl1lm': {
      'uz': 'Qanday dorini qidirmoqchisiz?',
      'en': '',
      'ru': '',
    },
    'nxj0il21': {
      'uz': 'Elevit Pronatal',
      'en': '',
      'ru': '',
    },
    '3oejeiil': {
      'uz': 'Vitamin-mineral kompleksi',
      'en': '',
      'ru': '',
    },
    'yi7idf2b': {
      'uz': 'Femibion 2',
      'en': '',
      'ru': '',
    },
    '4bavdm5o': {
      'uz': 'Vitaminlar va DHA bilan to‘yintirilgan kompleks',
      'en': '',
      'ru': '',
    },
    'h2ro56jt': {
      'uz': 'Yodamarin 200',
      'en': '',
      'ru': '',
    },
    'nfq7rstn': {
      'uz': 'Yod yetishmovchiligi profilaktikasi uchun',
      'en': '',
      'ru': '',
    },
    '7zgut2gr': {
      'uz': 'Magne B6',
      'en': '',
      'ru': '',
    },
    'w89nrfwj': {
      'uz': 'Asabiylik va mushak tortishishlariga qarshi',
      'en': '',
      'ru': '',
    },
    'uia40fih': {
      'uz': 'Ko\'proq yuklash',
      'en': '',
      'ru': '',
    },
    'bxv64yxc': {
      'uz':
          'Har qanday dori-darmonni ishlatishdan oldin shifokor bilan maslahatlashing',
      'en': '',
      'ru': '',
    },
    'jh6ypaw5': {
      'uz': 'Muhim ma\'lumotlar',
      'en': '',
      'ru': '',
    },
    'wiyp0by1': {
      'uz': 'Dori qabul qilish vaqti',
      'en': '',
      'ru': '',
    },
    'mkwhscw1': {
      'uz': 'Kuniga 2-3 marta',
      'en': '',
      'ru': '',
    },
    'paqnuss3': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    'nrfnk5r7': {
      'uz': 'Allergik reaksiyalarga e\'tibor bering',
      'en': '',
      'ru': '',
    },
    '62r3a3ml': {
      'uz': 'Qanday dorini qidirmoqchisiz?',
      'en': '',
      'ru': '',
    },
  },
  // Vaksinalar
  {
    'j2vtno59': {
      'uz': 'VAKSINALAR',
      'en': '',
      'ru': '',
    },
    'l310bidh': {
      'uz': 'BCG',
      'en': '',
      'ru': '',
    },
    'qxawa197': {
      'uz': 'Bacillus Calmette–Guérin',
      'en': '',
      'ru': '',
    },
    'm4d3rrnr': {
      'uz': 'Gepatit B',
      'en': '',
      'ru': '',
    },
    'xuoib5vn': {
      'uz': 'HBV',
      'en': '',
      'ru': '',
    },
    'xkswspu5': {
      'uz': 'Pentavalent Vaksina',
      'en': '',
      'ru': '',
    },
    'mk8upalc': {
      'uz': 'DTP-HEPB-HIB',
      'en': '',
      'ru': '',
    },
    'a5f0nymd': {
      'uz': 'OPV/IPV',
      'en': '',
      'ru': '',
    },
    'ctrnmubw': {
      'uz': 'Og\'zaki va Inyeksion Poliomiyelit',
      'en': '',
      'ru': '',
    },
    'lmpzlo3a': {
      'uz': 'Pnevmokokk Vaksinasi',
      'en': '',
      'ru': '',
    },
    'hfvu4bnt': {
      'uz': 'PCV',
      'en': '',
      'ru': '',
    },
  },
  // Closelocation
  {
    'lgczatf0': {
      'uz': 'MARKAZLAR',
      'en': '',
      'ru': '',
    },
    'pqzkbevx': {
      'uz': 'Sizga Yaqin Bo\'lishi Mumkin',
      'en': '',
      'ru': '',
    },
    'ypowzhwu': {
      'uz': 'Jizzax Perinatal markazi',
      'en': '',
      'ru': '',
    },
    'rhopd5if': {
      'uz': '1.2 km • Ochiq',
      'en': '',
      'ru': '',
    },
    'wtus6gxq': {
      'uz': 'Dorixona №5',
      'en': '',
      'ru': '',
    },
    'asje4xfj': {
      'uz': '2.5 km • Ochiq 24/7',
      'en': '',
      'ru': '',
    },
    '9f8h5aye': {
      'uz': 'Vaksina Markazi',
      'en': '',
      'ru': '',
    },
    'ubkvplci': {
      'uz': '3.7 km • Yopiq',
      'en': '',
      'ru': '',
    },
  },
  // Notifications
  {
    'vrn0bo4v': {
      'uz': 'BILDIRISHNOMALAR',
      'en': '',
      'ru': '',
    },
    'j25ydk62': {
      'uz': 'Hozircha habar yo\'q',
      'en': '',
      'ru': '',
    },
    'hmno92kx': {
      'uz': 'Yangi bildirishnomalar kelganda shu yerda ko\'rsatiladi',
      'en': '',
      'ru': '',
    },
  },
  // Sectionvideo1
  {
    '18lnhmv3': {
      'uz': '50:00',
      'en': '',
      'ru': '',
    },
    'j6xv4hg5': {
      'uz': '1-dars',
      'en': '',
      'ru': '',
    },
    'hzkjecxm': {
      'uz': '40:00',
      'en': '',
      'ru': '',
    },
    'shqalp5d': {
      'uz': '2-dars',
      'en': '',
      'ru': '',
    },
    '4h218akh': {
      'uz': '55:00',
      'en': '',
      'ru': '',
    },
    'gifs1frr': {
      'uz': '3-dars',
      'en': '',
      'ru': '',
    },
    '1o8v0qn9': {
      'uz': '40:50',
      'en': '',
      'ru': '',
    },
    'v9nbrfw0': {
      'uz': '4-dars',
      'en': '',
      'ru': '',
    },
    '3r0m7jgp': {
      'uz': 'Bu sahifa ishlab chiqilmoqda',
      'en': '',
      'ru': '',
    },
    'iwmls45m': {
      'uz': 'Tez orada yangi videolar bilan qaytamiz',
      'en': '',
      'ru': '',
    },
    '8oddq71j': {
      'uz': 'Bosh sahifaga qaytish',
      'en': '',
      'ru': '',
    },
    'd3x00ggt': {
      'uz': 'DARSLAR',
      'en': '',
      'ru': '',
    },
  },
  // Article1
  {
    '81k4898d': {
      'uz': 'Yangi tug‘ilgan chaqaloqni to‘g‘ri ovqatlantirish',
      'en': '',
      'ru': '',
    },
    'smutpzk4': {
      'uz': 'Aprel 15, 2025',
      'en': '',
      'ru': '',
    },
    '2vcueat6': {
      'uz': 'Dilnoza Karimova',
      'en': '',
      'ru': '',
    },
    '7dj1savk': {
      'uz':
          'Yangi tug‘ilgan chaqaloq uchun eng muhim omillardan biri bu to‘g‘ri ovqatlantirishdir. To‘g‘ri parvarish va ovqatlantirish chaqaloqning sog‘lom o‘sishi, rivojlanishi hamda immun tizimining mustahkamlanishida muhim rol o‘ynaydi.',
      'en': '',
      'ru': '',
    },
    's0vr89zd': {
      'uz':
          '1. Ona suti — eng yaxshi oziqa\nYangi tug‘ilgan chaqaloq uchun eng yaxshi oziqa bu ona sutidir. Unda chaqaloq uchun kerakli barcha oziq moddalar, vitaminlar va immunitetni mustahkamlovchi moddalarning mukammal muvozanati mavjud. Ona suti:\n\n•oson hazm bo‘ladi;\n•chaqaloqni infeksiyalardan himoya qiladi;\n•ruhiy bog‘lanishni kuchaytiradi;\n•allergiya xavfini kamaytiradi.\n\nShifokorlar chaqaloqni kamida 6 oy faqatgina ona suti bilan ovqatlantirishni tavsiya etadilar.',
      'en': '',
      'ru': '',
    },
    'qg44edxf': {
      'uz':
          '2. Emizishning to‘g‘ri usuli\nChaqaloqni to‘g‘ri emizish uchun quyidagilarga e’tibor qaratish lozim:\n\n•Emizish paytida ona qulay holatda o‘tirishi yoki yotishi kerak.\n•Chaqaloq og‘zi butunlay emchakni og‘ziga olgan bo‘lishi kerak.\n•Har bir emizish kamida 10-15 daqiqa davom etishi lozim.\n•Har ikki ko‘krakdan emizish tavsiya etiladi.',
      'en': '',
      'ru': '',
    },
    'jksdqvye': {
      'uz': 'Qo‘shimcha ovqatlantirish',
      'en': '',
      'ru': '',
    },
    'gycjte5i': {
      'uz':
          '6 oydan so‘ng chaqaloqqa bosqichma-bosqich qo‘shimcha ovqatlar berish boshlanadi. Bu ovqatlar:',
      'en': '',
      'ru': '',
    },
    '4lezwpyz': {
      'uz': 'silliq, pyure holida bo‘lishi',
      'en': '',
      'ru': '',
    },
    'y4c2778e': {
      'uz': 'allergik bo‘lmagan mahsulotlardan iborat bo‘lishi',
      'en': '',
      'ru': '',
    },
    'vc6ovvrp': {
      'uz': 'asta-sekinlik bilan joriy etilishi kerak',
      'en': '',
      'ru': '',
    },
    'fjbly6tw': {
      'uz':
          'Yangi tug‘ilgan chaqaloqni to‘g‘ri ovqatlantirish — bu uning sog‘lom hayotining poydevoridir. Har bir ota-ona emizishning ahamiyatini tushunib, chaqaloqning ehtiyojlariga e’tiborli bo‘lishi zarur. Agar qandaydir savollar yoki muammolar yuzaga kelsa, albatta, malakali shifokorga murojaat qilish kerak.',
      'en': '',
      'ru': '',
    },
    '3271tzgk': {
      'uz': 'MAQOLA',
      'en': '',
      'ru': '',
    },
  },
  // Article2
  {
    'pdii1yzb': {
      'uz': 'Chaqaloqning uyqu tartibini shakllantirish bo‘yicha maqola',
      'en': '',
      'ru': '',
    },
    'yyvufay5': {
      'uz': 'May 15, 2025',
      'en': '',
      'ru': '',
    },
    'eas1ra6v': {
      'uz': 'Dilnoza Karimova',
      'en': '',
      'ru': '',
    },
    '4583udu4': {
      'uz':
          'Yangi tug‘ilgan chaqaloqning hayotidagi eng muhim ehtiyojlardan biri bu — sifatli uyqudir. Uyqu nafaqat chaqaloqning jismoniy o‘sishi, balki asab tizimining rivojlanishi va ruhiy barqarorligi uchun ham juda muhim hisoblanadi. Ammo ko‘plab ota-onalar uchun chaqaloqning muntazam uyqu tartibini shakllantirish muammo tug‘dirishi mumkin.',
      'en': '',
      'ru': '',
    },
    'nzan22ih': {
      'uz':
          '1. Necha soat uyqu kerak?\nChaqaloqning yoshi o‘sib borgani sayin, u ehtiyoj sezadigan uyqu soati kamayadi. Quyidagicha umumiy tavsiyalar mavjud:\n\n•Yangi tug‘ilgan (0-3 oy): 14–17 soat kuniga\n•3–6 oy: 12–16 soat\n•6–12 oy: 12–15 soat, shu jumladan kunduzgi uyqu\n\nBu vaqtlar har bir bolada individual tarzda farqlanishi mumkin, lekin asosiy mezon — bola o‘zini xotirjam va tetik his qilishi kerak.',
      'en': '',
      'ru': '',
    },
    'pcqgsvpc': {
      'uz':
          '2. Uyqu tartibini shakllantirish uchun maslahatlar\n\na) Rejaga rioya qilish: Har kuni bir xil vaqtda uxlash va uyg‘onish chaqaloqning biologik soatini o‘rgatadi.\n\nb) Tinchlantiruvchi odatlar: Uxlatishdan avval yengil massaj, kitob o‘qib berish yoki asta musiqa eshittirish chaqaloqni tinchlantiradi.\n\nc) Uyquga qulay muhit yaratish: Xonada qorong‘ilik, osoyishtalik va qulay harorat (taxminan 20–22°C) bo‘lishi zarur.\n\nd) Kunduzi uxlash tartibini saqlash: Kunduzgi uyqu kechasi yaxshi uyquni buzmaydi, aksincha, uni mustahkamlaydi.\n\ne) Belgili signal berish: Har safar uxlatish oldidan bir xil harakatlar ketma-ketligini bajarish — masalan, cho‘milish → kiyinish → allani aytish — bu chaqaloqqa “uxlash vaqti keldi” degan signal bo‘ladi.',
      'en': '',
      'ru': '',
    },
    'm9j9kp64': {
      'uz': 'Uyqu muammolari va sabablari',
      'en': '',
      'ru': '',
    },
    'mywiuu3a': {
      'uz':
          'Ba’zida chaqaloqlar tungi uyquda tez-tez uyg‘onadi yoki uxlab qolishga qiynaladi. Bunga quyidagilar sabab bo‘lishi mumkin:',
      'en': '',
      'ru': '',
    },
    '5c0ukoow': {
      'uz': 'ortiqcha charchash yoki juda ko‘p rag‘batlantirish',
      'en': '',
      'ru': '',
    },
    'g21fzka8': {
      'uz': 'ochlik yoki ichakdagi gazlar',
      'en': '',
      'ru': '',
    },
    'ii3kwmv2': {
      'uz': 'chaqaloqning o‘z uyqu rejimiga hali ko‘nikmaganligi',
      'en': '',
      'ru': '',
    },
    'smhjgfd6': {
      'uz':
          'Chaqaloqning uyqu tartibini shakllantirish sabr va izchillikni talab qiladi. Har bir bola o‘ziga xos bo‘lgani uchun, ota-onalar uning individual ehtiyojlariga e’tiborli bo‘lishi zarur. To‘g‘ri tashkil etilgan uyqu tartibi nafaqat bolaning, balki butun oilaning osoyishtaligini ta’minlaydi.',
      'en': '',
      'ru': '',
    },
    '581piy7b': {
      'uz': 'MAQOLA',
      'en': '',
      'ru': '',
    },
  },
  // Drugbaby1
  {
    'rs4ip0n4': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    'cn0m3h4w': {
      'uz': 'Infakol',
      'en': '',
      'ru': '',
    },
    'pbtj03hj': {
      'uz': 'Gazga qarshi vosita',
      'en': '',
      'ru': '',
    },
    'cpmbku8d': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'q3stydfb': {
      'uz':
          'Infakol — simetikon moddasi asosidagi dori bo‘lib, chaqaloqlarda va kichik yoshdagi bolalarda oshqozon-ichakdagi ortiqcha gazlarni yo‘qotish uchun ishlatiladi. U qorinda og‘riq, dam bo‘lish (gaz yig‘ilishi) va kolikalarni kamaytirishga yordam beradi.',
      'en': '',
      'ru': '',
    },
    'zlj3pww7': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    '25bt6n58': {
      'uz': 'Qorin dam bo‘lishi (meteorizm)',
      'en': '',
      'ru': '',
    },
    'mxjwnmea': {
      'uz': 'Gaz to‘planishi bilan bog‘liq kolikalar',
      'en': '',
      'ru': '',
    },
    '57onxjed': {
      'uz': 'Chaqaloqlarda ichakdagi noqulayliklar',
      'en': '',
      'ru': '',
    },
    'cqde9gp9': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    'osg1rqb2': {
      'uz':
          'Chaqaloqlar (0+ oy): 0.5 ml (1 doza) har bir emizishdan oldin og‘iz orqali beriladi. Kuniga bir necha marta (har 6 soatda) qo‘llanishi mumkin.',
      'en': '',
      'ru': '',
    },
    '4tedgdgi': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    'ukpsia2g': {
      'uz': 'Allergik reaksiya (kam hollarda)',
      'en': '',
      'ru': '',
    },
    'lq6lj8g2': {
      'uz': 'Juda kamdan-kam hollarda ich ketishi yoki qabziyat',
      'en': '',
      'ru': '',
    },
    '3ueom1gj': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    'l0i23ju8': {
      'uz':
          'Agar chaqaloqda boshqa dori vositalariga yoki simetikonga allergiya bo‘lsa, shifokorga ayting',
      'en': '',
      'ru': '',
    },
    'xxoep5ze': {
      'uz': 'Tavsiya etilgan dozadan oshirmang',
      'en': '',
      'ru': '',
    },
    '9pnxhfeb': {
      'uz': 'Har bir qo‘llashdan oldin flakonni yaxshilab chayqatish kerak',
      'en': '',
      'ru': '',
    },
  },
  // Drugbaby2
  {
    'v1ucx0gi': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    '3hfm7zjy': {
      'uz': 'Espumisan Baby',
      'en': '',
      'ru': '',
    },
    '07i8qae6': {
      'uz': 'Gazga qarshi vosita',
      'en': '',
      'ru': '',
    },
    'ljben7y7': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'bqhnjlao': {
      'uz':
          'Espumisan Baby — simetikon moddasi asosidagi dori bo‘lib, oshqozon-ichak tizimidagi ortiqcha gaz pufakchalarini yo‘q qilishga yordam beradi. Bu dori ayniqsa chaqaloq va bolalarda qorin dam bo‘lishi, meteorizm va kolikalarni kamaytirish uchun qo‘llaniladi.',
      'en': '',
      'ru': '',
    },
    'tmjo4p7e': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    'ey1fc0hp': {
      'uz': 'Qorin dam bo‘lishi (meteorizm)',
      'en': '',
      'ru': '',
    },
    'okac3tvg': {
      'uz': 'Gaz to‘planishi bilan bog‘liq kolikalar',
      'en': '',
      'ru': '',
    },
    '7axh4sz3': {
      'uz':
          'Operatsiyadan oldin va keyingi diagnostika jarayonlarida ichakni gazlardan tozalash uchun',
      'en': '',
      'ru': '',
    },
    'z0329rjx': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    'e0ojs82v': {
      'uz':
          'Yangi tug‘ilgan chaqaloqlar va bolalar:\n5–10 tomchi (taxminan 20–40 mg simetikon) har bir ovqatdan oldin yoki ovqat vaqtida og‘iz orqali beriladi.\nKuniga bir necha marta (har ovqatlanish paytida) qo‘llanishi mumkin.',
      'en': '',
      'ru': '',
    },
    '39u0mx5e': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    'd5s5qfi7': {
      'uz': 'Juda kam hollarda allergik reaksiya (toshma, qichishish)',
      'en': '',
      'ru': '',
    },
    'df9cez0n': {
      'uz': 'Juda yaxshi ko‘tariladi, nojo‘ya ta’sirlar deyarli uchramaydi',
      'en': '',
      'ru': '',
    },
    'rcud786s': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    '9eyikxkc': {
      'uz':
          'Agar chaqaloqda boshqa dori vositalariga yoki simetikonga allergiya bo‘lsa, shifokorga ayting',
      'en': '',
      'ru': '',
    },
    '6mqk1cpq': {
      'uz': 'Tavsiya etilgan dozadan oshirmang',
      'en': '',
      'ru': '',
    },
    'iytlr74h': {
      'uz': 'Har bir qo‘llashdan oldin flakonni yaxshilab chayqatish kerak',
      'en': '',
      'ru': '',
    },
  },
  // Drugbaby3
  {
    'xzpo6lyg': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    'eatggm3o': {
      'uz': 'Aquamaris',
      'en': '',
      'ru': '',
    },
    'doi54lgg': {
      'uz': 'Burunni tozalovchi va namlovchi vosita',
      'en': '',
      'ru': '',
    },
    'cde9ks1j': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'lsd8yixp': {
      'uz':
          'Aqua Maris — dengiz suvi asosida tayyorlangan burun spreyi yoki tomchilari bo‘lib, burun bo‘shliqlarini tozalaydi, namlaydi va shilliq qavatni tiklaydi. U allergiya, shamollash va burun bitishi holatlarida foydali hisoblanadi. Ayniqsa chaqaloqlar va kichik bolalar uchun xavfsiz vositadir.',
      'en': '',
      'ru': '',
    },
    's52cihkj': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    'jek6oajw': {
      'uz': 'Burunni kundalik tozalash',
      'en': '',
      'ru': '',
    },
    'h4eet9h9': {
      'uz': 'Sovuq tegishi (rinit), allergik rinit va sinusit',
      'en': '',
      'ru': '',
    },
    '2fuatcp5': {
      'uz':
          'Quruq burun shilliq qavati (issiq, quruq havo yoki isitish tizimi sababli)',
      'en': '',
      'ru': '',
    },
    'ylupqhe0': {
      'uz': 'Burun gigiyenasi (ayniqsa chaqaloqlarda)',
      'en': '',
      'ru': '',
    },
    '7933d8e9': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    '07vuibwp': {
      'uz':
          'Chaqaloqlar (0+ oy):\n\nHar bir burun teshigiga 1–2 tomchi yoki püskürtma, kuniga 2–4 marta\nKundalik gigiyena uchun 1–2 marta ishlatiladi\n\nKattalar va bolalar:\n\nHar bir burun teshigiga 2–3 tomchi, kuniga 3–6 marta',
      'en': '',
      'ru': '',
    },
    'fmwvmcym': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    'joc5i3rd': {
      'uz':
          'Juda kam hollarda burun ichida yengil qichishish yoki yonish hissi',
      'en': '',
      'ru': '',
    },
    'nse27ykr': {
      'uz': 'Allergik reaksiya deyarli uchramaydi',
      'en': '',
      'ru': '',
    },
    '8sdoajmj': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    '4up3h1j9': {
      'uz': 'Faqat individual foydalanish uchun',
      'en': '',
      'ru': '',
    },
    '7cr4c20x': {
      'uz': 'Har foydalanishdan keyin uchini yuvib tozalang',
      'en': '',
      'ru': '',
    },
    'g11p6aat': {
      'uz': 'Preparat steril bo‘lishi uchun flakonni to‘g‘ri saqlang',
      'en': '',
      'ru': '',
    },
    'eqmnbwjq': {
      'uz':
          'Allergiya yoki maxsus burun holatlari bo‘lsa, shifokorga murojaat qiling',
      'en': '',
      'ru': '',
    },
  },
  // Drugbaby4
  {
    'i6r0q6b3': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    '4yj9p36c': {
      'uz': 'D-Vitamin 3',
      'en': '',
      'ru': '',
    },
    '3kyklj2d': {
      'uz': 'Vitamin preparati',
      'en': '',
      'ru': '',
    },
    'zptrnm64': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'oaswbkhy': {
      'uz':
          'D-Vitamin 3 — bu kolekalsiferol asosidagi vitamin bo‘lib, bola organizmida suyaklarning sog‘lom rivojlanishi, kaltsiy va fosfor almashinuvi uchun zarur. Ayniqsa, chaqaloq va yosh bolalarda raxitning oldini olishda muhim rol o‘ynaydi.',
      'en': '',
      'ru': '',
    },
    'rgt84y1g': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    'cqff4i2l': {
      'uz': 'Raxitning oldini olish (profilaktika)',
      'en': '',
      'ru': '',
    },
    'ixldmsro': {
      'uz': 'D3 vitamini yetishmovchiligi',
      'en': '',
      'ru': '',
    },
    'fvrvkci3': {
      'uz': 'Suyaklar va tishlarning normal rivojlanishini ta’minlash',
      'en': '',
      'ru': '',
    },
    'ikwdkutp': {
      'uz': 'Immunitetni qo‘llab-quvvatlash',
      'en': '',
      'ru': '',
    },
    'kgawnaxf': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    'p1y1qjmm': {
      'uz':
          'Chaqaloqlar (0–12 oy):\n400 IU (xalqaro birlik) — odatda 1 tomchi kuniga, ovqat vaqtida og‘iz orqali beriladi.\n\nBolalar (1 yoshdan oshgan):\n600 IU kuniga (doktor tavsiyasiga ko‘ra o‘zgartiriladi)',
      'en': '',
      'ru': '',
    },
    'ieizuvr3': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    'g05mnryz': {
      'uz':
          'Juda yuqori dozada uzoq muddat iste’mol qilinganda: bosh og‘rig‘i, ko‘ngil aynishi, qabziyat, siydikda kaltsiy ko‘payishi',
      'en': '',
      'ru': '',
    },
    '2joohyap': {
      'uz': 'Allergik toshma (kamdan-kam hollarda)',
      'en': '',
      'ru': '',
    },
    '1ta5xumx': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    'tm8pzgs9': {
      'uz': 'Dozani oshirmang — faqat shifokor belgilagan miqdorda foydalaning',
      'en': '',
      'ru': '',
    },
    'm9coel1f': {
      'uz':
          'Boshqa D vitamini saqlovchi dorilar bilan birga ehtiyotkorlik bilan qo‘llang',
      'en': '',
      'ru': '',
    },
    'hy05jq7j': {
      'uz': 'Bolalardan uzoqda saqlang',
      'en': '',
      'ru': '',
    },
    'xq91iuk4': {
      'uz':
          'Agar bolada buyrak kasalliklari yoki giperkalsemiya bo‘lsa, shifokorga xabar bering',
      'en': '',
      'ru': '',
    },
  },
  // Drugmom1
  {
    'djqcqolb': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    'g7877rl1': {
      'uz': 'Elevit Pronatal',
      'en': '',
      'ru': '',
    },
    'dcjmzexr': {
      'uz': 'Vitamin-mineral kompleksi',
      'en': '',
      'ru': '',
    },
    'rwq0iaow': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'tpj6o72p': {
      'uz':
          'Elevit Pronatal — bu homiladorlikdan oldin, homiladorlik vaqtida va emizish davrida ayollar uchun mo‘ljallangan vitamin va mineral kompleksi. U homilaning sog‘lom rivojlanishini ta’minlash, anemiyaning oldini olish va onaning umumiy salomatligini qo‘llab-quvvatlash uchun ishlatiladi.',
      'en': '',
      'ru': '',
    },
    '7jxsnaju': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    '86v2bm72': {
      'uz': 'Homiladorlikni rejalashtirish davrida',
      'en': '',
      'ru': '',
    },
    'abf36eod': {
      'uz': 'Homiladorlik davomida',
      'en': '',
      'ru': '',
    },
    '6daq0hvc': {
      'uz': 'Tug‘ruqdan keyin va emizish davrida',
      'en': '',
      'ru': '',
    },
    'scipvtu5': {
      'uz': 'Vitamin va mineral yetishmovchiligining oldini olish',
      'en': '',
      'ru': '',
    },
    'dgu70mga': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    'jtolxfti': {
      'uz':
          'Kattalar ayollar (homiladorlikdan oldin, davomida va so‘ng):\nKuniga 1 dona tabletka, ovqat vaqtida yoki undan keyin suv bilan ichiladi.',
      'en': '',
      'ru': '',
    },
    'wnezo6jq': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    'xtnmjvf6': {
      'uz': 'Ko‘ngil aynishi, qabziyat yoki diareya (ba’zida)',
      'en': '',
      'ru': '',
    },
    '1a9ry2za': {
      'uz': 'Allergik reaksiyalar (to‘shmalar, qichishish)',
      'en': '',
      'ru': '',
    },
    't28j66c4': {
      'uz':
          'Siydik rangining to‘q sariq bo‘lishi (normal holat, B2 vitamini sabab)',
      'en': '',
      'ru': '',
    },
    'blfw7cer': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    '46dsbkt9': {
      'uz':
          'Tarkibida temir va foliy kislotasi mavjud, boshqa vitamin komplekslari bilan birga qabul qilishda ehtiyot bo‘ling',
      'en': '',
      'ru': '',
    },
    'k798mkt3': {
      'uz': 'Tavsiya etilgan dozadan oshirmang',
      'en': '',
      'ru': '',
    },
    'htr5cl9g': {
      'uz':
          'Agar sizda gipervitaminoz, buyrak muammolari yoki boshqa surunkali kasalliklar bo‘lsa, shifokorga murojaat qiling',
      'en': '',
      'ru': '',
    },
    'w8mjv07d': {
      'uz': 'Bolalardan uzoqda saqlang',
      'en': '',
      'ru': '',
    },
  },
  // Drugmom2
  {
    'ow7m41c5': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    's92memzr': {
      'uz': 'Femibion 2',
      'en': '',
      'ru': '',
    },
    '33g46gnd': {
      'uz': 'Vitamin-mineral kompleksi',
      'en': '',
      'ru': '',
    },
    'z0gz4vak': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'ic59y1ad': {
      'uz':
          'Femibion 2 — homiladorlikning 13-haftasidan boshlab va emizish davrida ayollar uchun mo‘ljallangan vitamin va mineral qo‘shimchasi. U homila va onaning sog‘lig‘ini qo‘llab-quvvatlash uchun zarur bo‘lgan folat (metafolin shaklida), DHA (omega-3), vitaminlar va minerallarni o‘z ichiga oladi.',
      'en': '',
      'ru': '',
    },
    'g1le6vbt': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    'g9c9re4w': {
      'uz': 'Homiladorlikning ikkinchi va uchinchi trimestrlari',
      'en': '',
      'ru': '',
    },
    'px1blqvx': {
      'uz': 'Emizish davrida ona va bola salomatligini qo‘llab-quvvatlash',
      'en': '',
      'ru': '',
    },
    'fd8hdzvq': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    '3ynb8jtz': {
      'uz':
          'Kuniga 1 tabletka + 1 kapsula (ovqat bilan birga, suv bilan qabul qilinadi)',
      'en': '',
      'ru': '',
    },
    '258stnh6': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    'kr83pxqn': {
      'uz': 'Engil oshqozon buzilishi',
      'en': '',
      'ru': '',
    },
    '5ihmu8fg': {
      'uz': 'Allergik reaksiyalar (kam hollarda)',
      'en': '',
      'ru': '',
    },
    't9annnhu': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    'fvd9ngbc': {
      'uz': 'Har qanday allergiyangiz bo‘lsa, shifokorga xabar bering',
      'en': '',
      'ru': '',
    },
    'vbooq1tq': {
      'uz': 'Tavsiya etilgan dozadan oshirmang',
      'en': '',
      'ru': '',
    },
    'aafz6vhs': {
      'uz': 'Bolalardan uzoqda saqlang',
      'en': '',
      'ru': '',
    },
  },
  // Drugmom3
  {
    'b5auk6ic': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    'z9c6gxsn': {
      'uz': 'Yodamarin 200',
      'en': '',
      'ru': '',
    },
    'n4e2w591': {
      'uz': 'Mineral qo‘shimcha',
      'en': '',
      'ru': '',
    },
    '8twvc9ca': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'xqd8ur1u': {
      'uz':
          'Yodamarin 200 — tanadagi yod yetishmovchiligini oldini olish va davolash uchun mo‘ljallangan dori. Yod qalqonsimon bezning normal faoliyati va gormonlar ishlab chiqarilishi uchun zarur. Ayniqsa homiladorlik, emizish, o‘sish davrida organizmga ko‘proq yod kerak bo‘ladi.',
      'en': '',
      'ru': '',
    },
    'tlv6tfs8': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    'dkm8ev9x': {
      'uz': 'Yod yetishmovchiligini oldini olish',
      'en': '',
      'ru': '',
    },
    'mqh238jg': {
      'uz': 'Qalqonsimon bez kasalliklarining oldini olish',
      'en': '',
      'ru': '',
    },
    '0uq5fblj': {
      'uz': 'Homiladorlik va emizish davrida yod qo‘shimchasi sifatida',
      'en': '',
      'ru': '',
    },
    'lrveqiq6': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    '3jpb2sf3': {
      'uz': 'Homiladorlar va emizikli ayollar: kuniga 1 tabletka',
      'en': '',
      'ru': '',
    },
    '07a1umsg': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    'xrnzcc2k': {
      'uz': 'Allergik reaktsiyalar (kam hollarda)',
      'en': '',
      'ru': '',
    },
    'fgfas9t8': {
      'uz':
          'Yodga sezuvchanlik bo‘lsa, qalqonsimon bez faoliyatining buzilishi',
      'en': '',
      'ru': '',
    },
    '0lv1om5j': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    'cqjo94uc': {
      'uz':
          'Agar sizda qalqonsimon bez bilan bog‘liq muammolar bo‘lsa, shifokorga murojaat qiling',
      'en': '',
      'ru': '',
    },
    'kln8cbos': {
      'uz': 'Tavsiya etilgan dozadan oshirmang',
      'en': '',
      'ru': '',
    },
    'wg9dp5mb': {
      'uz': 'Bolalardan uzoqda saqlang',
      'en': '',
      'ru': '',
    },
  },
  // Drugmom4
  {
    'xfmwanzv': {
      'uz': 'DORI-DARMON',
      'en': '',
      'ru': '',
    },
    'vqwqycj1': {
      'uz': 'Magne B6',
      'en': '',
      'ru': '',
    },
    'luz9e21r': {
      'uz': 'Vitamin-mineral kompleksi',
      'en': '',
      'ru': '',
    },
    'tpq7003h': {
      'uz': 'Tavsif',
      'en': '',
      'ru': '',
    },
    'm3adm8l0': {
      'uz':
          'Magne B6 – tarkibida magniy va B6 vitamini (piridoksin) mavjud bo‘lgan kompleks. U asab tizimi, yurak, mushaklar faoliyatini qo‘llab-quvvatlaydi. Stress, bezovtalik, mushaklarning tortilishi yoki spazmlari, hamda magniy yetishmovchiligi belgilari bo‘lsa, tavsiya etiladi.',
      'en': '',
      'ru': '',
    },
    'agv1bctl': {
      'uz': 'Qo‘llanilishi',
      'en': '',
      'ru': '',
    },
    'tfiebwzy': {
      'uz': 'Magniy yetishmovchiligi',
      'en': '',
      'ru': '',
    },
    'ihd6cfrk': {
      'uz': 'Asabiylik, bezovtalik, charchoq',
      'en': '',
      'ru': '',
    },
    'kpu79drb': {
      'uz': 'Mushaklarda spazm yoki tikrilish (tiki)',
      'en': '',
      'ru': '',
    },
    'xgio751x': {
      'uz': 'Homiladorlik davrida magniyga bo‘lgan ehtiyojni qoplash',
      'en': '',
      'ru': '',
    },
    'tbg6rsce': {
      'uz': 'Dozalash',
      'en': '',
      'ru': '',
    },
    'hvj5l6ha': {
      'uz': 'Homilador ayollar: shifokor nazorati ostida',
      'en': '',
      'ru': '',
    },
    '98pi5osl': {
      'uz': 'Nojo‘ya ta’sirlari',
      'en': '',
      'ru': '',
    },
    '5z7c4rvc': {
      'uz': 'Diareya',
      'en': '',
      'ru': '',
    },
    'hkrxfha1': {
      'uz': 'Qorinda og‘riq yoki noqulaylik',
      'en': '',
      'ru': '',
    },
    'f4wb04yg': {
      'uz': 'Juda kam hollarda allergik reaksiyalar',
      'en': '',
      'ru': '',
    },
    'y5x9htjn': {
      'uz': 'Ehtiyot choralari',
      'en': '',
      'ru': '',
    },
    '6edl2syl': {
      'uz': 'Buyrak yetishmovchiligi bo‘lsa, ehtiyotkorlik bilan qabul qiling',
      'en': '',
      'ru': '',
    },
    'gdxdtvnp': {
      'uz': 'Tavsiya etilgan dozadan oshirmang',
      'en': '',
      'ru': '',
    },
    'jxg80nan': {
      'uz': 'Boshqa B6 vitaminli dorilar bilan birgalikda ehtiyot bo‘ling',
      'en': '',
      'ru': '',
    },
  },
  // story1
  {
    '4fgeqcll': {
      'uz': 'Hikoya',
      'en': '',
      'ru': '',
    },
    '81xc5juh': {
      'uz': 'Zumrad va Qimmat',
      'en': '',
      'ru': '',
    },
    'gbok14pa': {
      'uz': 'Ziyouz.uz',
      'en': '',
      'ru': '',
    },
    'dfnbq2oe': {
      'uz': '20.12.2015 · 15 daqiqa o\'qish',
      'en': '',
      'ru': '',
    },
    'kelhvno3': {
      'uz':
          'Bir zamonda katta bir soy bo‘yida kichkina bir uy bo‘lar ekan. Bu uyda chol, uning Zumrad degan qizi, o‘gay ona va uning Qimmat degan arzanda qizi turar ekanlar. Kampirning Zumradni ko‘rgani ko‘zi, otgani o‘qi yo‘q ekan. U hadeb qizni urib, qarg‘ab, ertadan kechgacha ishlatarkan, bechoraga birpas ham tinchlik bermas ekan.\nZumrad chiroyli, odobli, muloyim, aqlli qiz ekan. Uni bir ko‘rgan kishi yana ko‘rsam deb orzu qilar ekan. Xullas, u juda ajoyib qiz ekan. Qimmat esa ishyoqmas, injiq va dimog‘dor ekan. Uning butun kuni urish-janjal va to‘polon bilan o‘tar ekan.\nZumrad erta bilan barvaqt ko‘zasini ko‘tarib, soy yoqalab buloq boshiga borarkan, yo‘lda uchragan lola gullar boshlarini egib, unga salom berarkanlar. Zumrad maysalar ustida o‘tirib dam olganida gullar uni olqishlar, bulbullar quvonib unga hikoyalar aytib berarkanlar.\nAmmo xuddi shu gullar kampirning arzandasini sevmas, uni erkalamas ekanlar, chunki bu qiz ularni yulib tashlar, xushbo‘y gullarni hidsiz deb tepkilar ekan. Shuning uchun ham ular Qimmat kelar bo‘lsa, qovoqlarini solib, yumilib qolarkanlar.\nBularning hammasi yovuz kampirning g‘azabini keltirar ekan. Kampir esa, buni Zumraddan ko‘rarkan.\nBir kun kampir Zumradni yomonlab, cholga do‘q uribdi:\n— Qizing beodob, ishyoqmas, uni haydab yubor! Bo‘lmasa sen bilan bir nafas ham birga turmayman!\nChol nima qilarini bilmay qolibdi. Axiri kampir:\n— Qizingni o‘rmonga oborib adashtirib kel! U bilan birga turmayman! — debdi.\nChol qizini adashtirib kelish uchun tog‘-toshlarni kezib, bir o‘rmonga boribdi. Ota-bola o‘rmon ichida uzoq yurishibdi. Axiri quyuq soyali bir joyga borib to‘xtashibdi. Keyin chol o‘tin kesgani ketibdi. Zumrad yolg‘iz qolibdi.\nShu paytda birdan shamol turibdi. Chol esa o‘rmondagi bir katta daraxtga boltasini osibdi-da, unga og‘irroq tosh bog‘lab, qattiq itarib yuboribdi. Bolta u yoqdan bu yoqqa urilib to‘qillayveribdi.\nShamol juda kuchayibdi. Bolta shamol kuchi bilan uzoq vaqt daraxtga urilib “to‘q-to‘q” qilib tovush chiqaribdi.\nZumrad “Otam o‘tin kesayotibdi”, deb o‘ylab, otasini anchagacha kutibdi. Kech bo‘libdi, otasidan darak bo‘lmabdi. Shamol to‘xtabdi. Qiz o‘rmondagi chuchmomalarni terib yurib, bexosdan bolta osilgan daraxt tagiga borib qolibdi. Qarasa, otasi yo‘q emish.\n— Voy sho‘rim qursin! Voy, otajon?! — deb uvvos solib yig‘lab, to‘rt tomonga yuguribdi. Hech kimdan darak bo‘lmabdi, qiz adashib qolibdi. O‘rmon unga yana ham vahimali bo‘lib ko‘rinibdi. Qiz qayoqqa borishini bilmay, axiri kichik bir so‘qmoqdan chopib ketaveribdi.\nZumrad uzoq yo‘l bosibdi. Qorong‘ida gullar uning yo‘lini yoritibdi. Ketaturib bir vaqt qarasa, uzoqda miltillagan chiroq ko‘rinibdi, itning hurigani eshitilibdi. Qiz o‘sha tomonga qarab yuraveribdi. Tezda kichik bir uyga yetibdi. Uyning derazasidan qarasa, bir kampir o‘tirgan emish. Qiz sevinib, kampir oldiga kiribdi, boshidan kechirgan voqealarni kampirga birma-bir aytib beribdi.\nUyga shunday chiroyli qizchaning kelganini ko‘rgan kampir juda quvonibdi. Bu kampir o‘rmonda yashaydigan sehrgar kampir ekan. Kampir qizning yig‘laganini ko‘rib:\n— Ko‘p xafa bo‘lma, qizim, senga yordam beraman, — deb qizni ovutibdi. Qiz ham unga:\n— Rahmat! Men sizni onamdek ko‘raman. Buyurgan ishingizni jonim bilan qilaman, — deb javob beribdi.\nShu choq kampirning uyi tepasiga juda ko‘p qushlar yig‘ilibdi, ular qizchani maqtab, sayrashibdi. Qushlar tilini bilgan sehrgar kampir yana ham quvonibdi. Xosiyatli qizga dunyoda topilmaydigan rasmli kitob va qo‘g‘irchoqlar berib:\n— Oppoq qizim, shirin qizim! Do‘mbog‘im, munchog‘im! — deb qizning boshini silab erkalabdi.\nUlar uzoq vaqt birga turishibdi. Kampir qizchani yaxshilab parvarish qilibdi. Zumrad ozoda qiz bo‘lgani uchun uyni supurib-sidirib, oynalarni artib-surtib, hamma yoqni chinniday qilib qo‘yar ekan. Buni ko‘rib kampir yana ham quvonar ekan.\nBir kun kampir qizga osh qilib bermoqchi bo‘lib:\n— Tomdan o‘tin olib tush, qizim, — debdi. Qiz dik etib o‘rnidan turib:\n— Xo‘p bo‘ladi, onajon, — deb darrov tomga chiqibdi.\nTom baland ekan, undan hamma yoq ko‘rinar ekan. Qiz atrofga qarab turib, birdan o‘z uyining tomini ko‘rib qolibdi. Yuragi orziqib yig‘lab yuboribdi. Buni eshitgan kampir:\n— Nega yig‘laysan, jon qizim? — deb so‘ragan ekan. Qiz:\n— Ko‘zimga uyimiz ko‘rindi, otamni sog‘indim, — debdi.\nKampir uni aldab-suldab yupatibdi, ikkovlari ovqat pishirib yeyishibdi.\nErta bilan kampir qizga:\n— Narsalaringni yig‘ishtir, qizim! — debdi.\nQiz qo‘g‘irchoqlarini yig‘ishtiribdi. Kampir qizga:\n— Tomda qizil va oq sandiq bor, oq sandiqni qoldirib, qizil sandiqni olib tush! — debdi-yu o‘rmonga kirib ketibdi. Bir vaqtdan keyin o‘rmondan saman ot qo‘shilgan bir arava yetaklab chiqib, qizni aravaga o‘tqazibdi.\n— Qizil sandiqni uyga borgandan keyin och! — deb kampir qizga bir kalit beribdi.\nQiz kampir bilan qayta-qayta xayrlashib yo‘lga chiqibdi. Bir zumda arava qizning uyi oldida hozir bo‘libdi. Shu paytda uy eshigi oldida chol o‘z qizini sog‘inib, uning dardida yig‘lab o‘tirgan ekan. Qiz mehribon otasini ko‘rishi bilan:\n— Salom, otajon! — deb otasining bag‘riga tashlanibdi.\nChol benihoyat xursand bo‘lganidan anchagacha ko‘z yoshlarini to‘xtatolmabdi. Axiri yig‘idan to‘xtab, qiziga:\n— Oppog‘im, meni kechir, — debdi.\nUlar uyga kirishibdi. Qizning kelgani hammaga ma’lum bo‘libdi. Qo‘ni-qo‘shnilar yig‘ilishibdi. Qiz qizil sandiqni ochishi bilan hamma hayron qolibdi: qizil sandiq asl mollar bilan liq to‘la ekan. Mol shuncha ko‘p, shu qadar ajoyib emishki, Zumradning butun umriga yetib ortar emish.\nBu narsa o‘gay onani og‘ir tashvishga solibdi.\nU cholga qizi Qimmatni ham tezda o‘rmonga olib borib adashtirib kelishni buyuribdi. Chol “Xo‘p” deb, Qimmatni darrov o‘rmonga adashtirib kelibdi.\nKech kirganda Qimmat, xuddi Zumradga o‘xshab, bolta osilgan daraxt tagiga borib qolibdi. Adashganini sezibdi. Ho‘ng-ho‘ng yig‘lasa ham, lekin uni ovutadigan odam topilmabdi. Faqat uning ro‘parasida boyqushlar o‘tirib olib, qorong‘i, vahimali o‘rmonlar haqida sayrarmish. Bu kuylar Qimmatni vahimaga solibdi. U qo‘rqib o‘rmondan qocha boshlabdi. Qorong‘i tushgan paytda sehrgar kampirning uyiga kirib boribdi. Kampir uni yaxshi kutib olibdi, ovutibdi, mehmon qilibdi. So‘ngra qizga qarab:\n— Xafa bo‘lma, qizim, o‘zim yordam beraman, — debdi.\nAmmo Qimmat kampirga yaxshi so‘zlar topib aytolmabdi, chunki onasi unga yaxshi so‘zlar o‘rgatmagan ekan. Kampir uni sevmabdi, yaxshi ertaklar ham aytib bermabdi, dunyoda topilmaydigan suratli kitoblar va qo‘g‘irchoqlar ham bermabdi.\nQimmat ertadan qora kechgacha yalqovlanib o‘tiraverar ekan. Uyni yig‘ishtirib, supurmas ekan.\nBir kun kampir o‘rmondan qaytib kelib, unga:\n— Tomdan o‘tin olib tush, qizim! — degan ekan, qiz:\n— O‘zingiz olib tushing, malayingiz yo‘q! — debdi.\nKampir judayam xafa bo‘libdi, shunga qaramay qizni aldab-suldab tomga chiqaribdi. Lekin qiz o‘tin olib tushish o‘rniga tom boshida chinqirib yig‘layveribdi. Kampir buni eshitib:\n— Nega yig‘laysan, qizim? —deb so‘ragan ekan, Qimmat yer tepinib:\n— Uyimni ko‘rdim, ketaman, — deb yana ho‘ngrabdi.\nSehrgar kampir qizga:\n— Juda yaxshi, tomdagi sandiqni olib tush, — debdi.\nQimmat sandiqni olib tushibdi. Keyin kampir qizga bir kalit uzata turib:\n— Mana kalit, sandiqni uyingga borganingda ochasan, — debdi.\nQiz o‘sha onda yig‘isini ham unutib, oq sandiqni orqalab jo‘nabdi. Sehrgar kampir unga arava ham bermabdi, qiz og‘ir sandiqni ko‘targanicha uyiga piyoda kelibdi.\nQizning kelishini dastavval olapar it sezibdi. U Qimmatning onasi oldiga borib:\n— Vov, vov, vov, — degan ekan, kampir quloq solmabdi, it yana vovullab:\n— Opam kelayotirlar, orqalaganlari oq sandiq, ilon bilan liq to‘liq, — debdi.\nKampir g‘azablanib, o‘qlog‘i bilan itni urib, oyog‘ini sindiribdi.\n— Mening aqlli qizim qimmatli mollar keltiradi, — debdi u.\nQizining kelganini ko‘rib kampir o‘zida yo‘q sevinibdi. Qo‘ni-qo‘shnilar yig‘ilibdi, sandiqni ochmoqchi bo‘lishibdi.\nShunda kampir bilan qizi ikkisi: “Yo‘q, ochmanglar!” deb o‘zlarini sandiq ustiga tashlabdilar. Keyin ikki qulog‘idan ko‘tarib uyga olib kiribdilar.\nYarim kecha payti ekan, kampir bilan qiz eshik-elikni yopib, sandiqni ochishibdi-yu birdaniga “Voydod, qutqaringlar!”, “Ajdar!”, “Voydod!” deb baqirishibdi…\nSandiqda kattakon ikkita ajdar yotgan ekan. Qoqvosh kampir bilan uning urishqoq qizi dodlashib, uyni gir-gir aylanishibdi, qo‘rqqanlaridan qulflangan eshikni ochisholmabdi.\nIkki ajdar kampir bilan qizni yutib, darchadan chiqib ketibdi.\n“Dod, voy!” degan ovozni eshitgan qo‘ni-qo‘shnilar eshikni buzib ichkari kiribdilar. Qarasalar, hech kim yo‘q emish. Uyda yovuz kampirni ham, uning urishqoq qizini ham topolmabdilar.\nShundan so‘ng oq ko‘ngil Zumrad bilan ota ikkisi tinchgina yashab, murod-maqsadlariga yetibdilar.',
      'en': '',
      'ru': '',
    },
    'tuletqop': {
      'uz': '1.2K o\'qishlar',
      'en': '',
      'ru': '',
    },
  },
  // story2
  {
    'xvi2iz17': {
      'uz': 'Hikoya',
      'en': '',
      'ru': '',
    },
    '6c6y7ys5': {
      'uz': 'Boy ila Kambag\'al',
      'en': '',
      'ru': '',
    },
    'au2kkcvd': {
      'uz': 'Abiturtest.uz',
      'en': '',
      'ru': '',
    },
    'xqjgcohz': {
      'uz': '20.12.2015 · 5 daqiqa o\'qish',
      'en': '',
      'ru': '',
    },
    'vcy1ulub': {
      'uz':
          'Bir bor ekan, bir yo‘q ekan, qadim zamonda bir boy va bir kambag‘al bo‘lgan ekan. Boy juda boy bo‘lib, ko‘plab mol-mulkka ega ekan, lekin juda ochko‘z va baxil ekan. Kambag‘al esa juda kambag‘al bo‘lsa-da, halol, mehnatkash va saxiy ekan.\n\nBir kuni kambag‘al boyning oldiga borib, yordam so‘ragan ekan.\n\n— Ey boy, biror ish bersangiz, mehnat qilib, rizqimni topaman, — debdi kambag‘al.\n\nBoy unga bir ish beribdi, lekin ish haqi to‘lamayman, deb shart qo‘yibdi. Kambag‘al rozi bo‘lib, halol mehnat qilibdi.\n\nIsh tugagach, kambag‘al boydan haqini so‘rabdi.\n\n— Men senga ish haqi to‘lamayman, — debdi boy.\n\nKambag‘al bu adolatsizlikdan norozi bo‘lib, qozining oldiga boribdi. Qoziga bo‘lgan voqeani aytib, adolat so‘rabdi.\n\nQozining oldiga boy ham kelibdi. U qoziga pora berib, kambag‘alning haqini bermaslikka ko‘ndirmoqchi bo‘libdi.\n\nAmmo qozining o‘zi ham ochko‘z bo‘lib, boydan katta pora talab qilibdi. Boy esa qozini aldab, unga katta mukofot va\'da qilib, oxir-oqibat hech narsa bermabdi.\n\nQozining bu ishidan kambag‘al norozi bo‘lib, xalq orasida bu voqeani tarqatibdi. Odamlar boyning ochko‘zligi va qozining adolatsizligidan xabar topib, ularni qoralabdi.\n\nOxir-oqibat, boy va qozining obro‘si tushib, xalq orasida yomon nom qozonibdi. Kambag‘al esa halol mehnati va sabr-toqati bilan xalqning hurmatiga sazovor bo‘libdi.',
      'en': '',
      'ru': '',
    },
    'e5bqfc5o': {
      'uz': '1K o\'qishlar',
      'en': '',
      'ru': '',
    },
  },
  // story3
  {
    'yxoif0y0': {
      'uz': 'Hikoya',
      'en': '',
      'ru': '',
    },
    'j0s1ra3q': {
      'uz': 'Qarg\'a bilan Qo\'zi',
      'en': '',
      'ru': '',
    },
    'nka66u2m': {
      'uz': 'Ziyo.uz',
      'en': '',
      'ru': '',
    },
    '9rcsq6s1': {
      'uz': '24.10.2013 · 5 daqiqa o\'qish',
      'en': '',
      'ru': '',
    },
    'joenybl5': {
      'uz':
          'Bor ekan, yo‘q ekan, bo‘ri bakovul ekan, tulki yasovul ekan, qarg‘a qaqimchi ekan, chumchuq chaqimchi ekan, o‘rdak surnaychi ekan, g‘oz karnaychi ekan, tovuq taq etdi, bilmadim qaqqa ketdi.\nBir qarg‘a bilan qo‘zi bor ekan. Qarg‘a qo‘zi yoniga borib:\n— Seni yeyman, — debdi.\n— Meni yeyishga yeysanu, tumshug‘ing harom, daryoga borib chayqab kelib, undan keyin yegin, — debdi qo‘zi.\nQarg‘a tumshug‘ini chayqagani daryoga boribdi. Daryo suvini pastga tortib olib:\n— Mendan odamlar suv ichadi, sening tumshug‘ing harom, Ustaboy kuloldan bitta ko‘za olib kelgin, suvni men beray, sen suvni olib u yoqda chayqagin, — debdi.\nShunda qarg‘a Ustaboy kulolning oldiga borib:\n— Ey Ustaboy kulol, bering ko‘za, olay suv, chayqay tumshuq, yeyman semiz, a’lo qo‘zi, — debdi.\nUstaboy kulol:\n— Tuprog‘im ado bo‘lib qoldi. Tuproq olur degan yerdan tuproq olib kelib bergin, men yangi ko‘za qilib beraman, — debdi. Sho‘rlik qarg‘a tuproq olurga uchib boribdi:\n— Bering tuproq, qilsin ko‘za, olay suv, chayqay tumshuq, yeyman semiz, a’lo qo‘zi, — debdi. Tuproq olur:\n— Tog‘ning boshida bir kiyik bor. Shu kiyikning shoxidan olib kel. O’sha kiyik shoxi bilan qazib olasan, — debdi.\nQarg‘a bu yerdan ham uchib tog‘ tepasidagi kiyik oldiga boribdi:\n— Hoy kiyik aka, bering shox, qaziy tuproq, qilsin ko‘za, olay suv, chayqay tumshuq, yeyman semiz, a’lo qo‘zi, — debdi. Kiyik bechora aytibdi:\n— Rahmim kelib beray dedimu, shoxim qattiq o‘rnagan, jonim og‘riydi. Bir Po‘latvoy aka degan kishining tozisi bor. Shu tozisini sizga bersin. Tozi kelib meni quvsin, men qochib ketib daraxtlarga shoximni urib tushirib baray, — debdi.\nShundan keyin qarg‘a uchib Po‘latvoy akaning oldiga borib: «Po‘latvoy aka», — deb chaqiribdi.\n— Bering tozi, quvlasin kiyik, tashlasin shox, qaziy tuproq, qilsin ko‘za, olay suv, chayqay tumshuq, yeyman semiz, a’lo qo‘zi, — debdi. Po‘latvoy aytibdi:\n— Tozimning qorni och, bedarmon bo‘lib yotibdi. Tosh akamning sigiri bor, o‘sha sigirning sutidan bersin, olib keling ichiramiz, tozi ovqatlanib olib kiyingizni quva bersin, — debdi. Qarg‘a uchib borib:\n— Toshvoy aka! — deb chaqiribdi.\n— Labbay, — debdi Toshvoy aka.\n— Bering sut, ichsin tozi, quvsin kiyik, tashlasin shox, qaziy tuproq, qilsin ko‘za, olay suv, chayqay tumshuq, yeyman semiz, a’lo qo‘zi, — debdi.\nToshvoy aka:\n— Sigirimning qorni och, dalaga borgani yo‘q. Sen daladan bir ko‘tarim quroq olib kelib ber, sigir yeb sutga kirsin, undan keyin olib ketasan, — debdi.\nQarg‘a bir quroqzor ko‘lga boribdi.\n— Bering quroq, yesin sigir, bersin sut, ichsin tozi, quvlasin kiyik, tashlasin shox, qaziy tuproq, qilsin ko‘za, olay suv, chayqay tumshuq, yeyman semiz, a’lo qo‘zi, — debdi.\nQuroq aytibdi:\n— Yulib olsang, qo‘lingni qiyib ketaman, shaharning chekkasida o‘roq qiladigan usta So‘kildi degan bor. Bitta yaxshi o‘roq qilib bersin, meni o‘rib olib ketgin, — debdi. Qarg‘a uchib usta So‘kildining oldiga boribdi:\n— Usta, usta, — deb chaqiribdi. Usta:\n— Labbay, — deb qarganing oldiga chiqibdi. Qarg‘a:\n— Bering o‘roq, o‘ray quroq, yesin sigir, bersin sut, ichsin tozi, quvsin kiyik, tashlasin shox, qaziy tuproq, qilsin ko‘za, olay suv, chayqab tumshuq, yeyman semiz, a’lo qo‘zi, — debdi.\nUsta So‘kildi:\n— Ko‘mirim tamom bo‘lib qolgan edi. Bir tog‘ning boshida besh-o‘n xonadon bor, ular ko‘mir kuydirayotgan emish, ko‘miridan olib kelib ber, senga pashshaning qanotidek olmosdan o‘roq qilib beray.\nQarg‘a bu yerdan ham uchib o‘shal ko‘mirchilarning oldiga borib:\n— Ko‘mirchi aka, ko‘mirchi aka, bering ko‘mir, qilsin o‘roq, o‘ray quroq, yesin sigir, bersin sut, ichsin tozi, quvsin kiyik, tashlasin shox, qaziy tuproq, qilsin ko‘za, olay suv, chayqay tumshuq, yeyman semiz, a’lo qo‘zi, — debdi.\nKo‘mirchilardan biri bir parcha ko‘mirni oldiga irg‘itib yuboribdi. Qarg‘a ko‘mirni olib, usta So‘kildining oldiga kelibdi:\n— Mana ko‘mirni topib keldim, — debdi. Usta: «Obbo, vaj qilsam ham bo‘lmadi-ya» deb bir pashshaning qanotidek olmosdan qilingan o‘roqni qarg‘aning qanotiga o‘tkazib qo‘yibdi. Qarg‘a bir qancha vaqt uchgandan keyin o‘roq qanotini shartta qirqib ketibdi, ikkinchi qanotiga o‘tazib olibdi. Yana bir qancha uchgandan keyin ikkinchi qanotini ham shartta qirqib ketibdi. Bechora qarg‘a endi o‘roqni bo‘yniga solibdi, ucha olmasdan hiqillab qancha yo‘l yuribdi. Bo‘ynini ham o‘roq shartta kesib ketibdi. Qarg‘a maqsadiga yetolmay, bir cho‘lda o‘lib qolibdi. Qo‘zi esa qutulib qolibdi.',
      'en': '',
      'ru': '',
    },
    '3pxq4tny': {
      'uz': '1K o\'qishlar',
      'en': '',
      'ru': '',
    },
  },
  // story4
  {
    'exaag3am': {
      'uz': 'Hikoya',
      'en': '',
      'ru': '',
    },
    'dvp3xy39': {
      'uz': 'Uch Og\'a-ini Botirlar',
      'en': '',
      'ru': '',
    },
    'yoc2nuwq': {
      'uz': 'Ziyo.uz',
      'en': '',
      'ru': '',
    },
    'n97gsrdi': {
      'uz': '24.10.2013 · 15 daqiqa o\'qish',
      'en': '',
      'ru': '',
    },
    'xbo9auov': {
      'uz':
          'Bor ekan, yo\'q ekan, bir zamonda bir kishi bo\'lgan ekan. Boy ham, kambag\'al ham emas ekan. Uning uchta o\'g\'li bor ekan, uchovi ham o\'qigan, oq-u qorani tanigan, yuzlari oyday, o\'zlari toyday, yomon bilan yurmagan, yomon joyda turmagan ekanlar. To\'ng\'ichi yigirma bir yoshda, o\'rtanchasi o\'n sakkiz yoshda, kenjasi o\'n olti yoshda ekan. Otasi bir kuni ularni oldiga chaqirib, har birining peshanasini silab: — O\'g\'illarim, men boy emasman, mendan qolgan davlat sizlarning maishatingiz uchun kifoya qilmaydi, mendan ortiq narsa umid qilib o\'tirmanglar, o\'zimdan keyin baxtsiz bo\'lib qolmanglar deb, sizlarni o\'qitdim. Yaxshi ot qo\'ydim. To\'y qildim, voyaga yetkazdim. Buning ustiga sizlarni yana uch narsa bilan tarbiya qildim. Birinchidan, sog\'lom vujudli qilib o\'stirdim — quvvatli bo\'ldingiz. Ikkinchidan, yarog\' bilan tanishtirdim - yarog\' ishlatishga usta bo\'ldingiz. Uchinchidan, qo\'rqitmay o\'stirdim — qo\'rqoq bo\'lmay botir bo\'ldingiz, yana uchta narsani aytaman, quloqlaringizga olib, eslaringizdan chiqarmangiar. To\'g\'ri bo\'ling — bexavotir bo’lasiz. Maqtanchoq bo\'lmang — xijolat tortmaysiz. Dangasalik qilmang - baxtsiz bo\'lmaysiz. Bundan boshqasini o\'zingiz biling. Qora toyni, saman toyni, ko\'k toyni asbob-anjomlari bilan tayyorlab qo\'ydim. Xurjunlaringizni bir haftalik ovqat bilan to\'lg\'izdim. Baxtingiz yoida, topib olmoq uchun dunyoni ko\'rgani yo\'lga chiqing, dunyoni tanimay dunyo kishisi bo\'lmaysiz. Baxt qushini ushlamoq uchun baxt oviga chiqing. Xayr o\'g\'illarim, — deb turib ketdi...\nUch og\'a-ini safarga otlandilar. Yo\'lda ular kechasi navbatma-navbat poyloqchilik qilib chiqishga kelishadilar. Birinchi kecha To\'ng\'ich botir o\'zlariga hujum qilmoqchi bo\'lgan sherni o\'ldiradi. Ikkinchi kecha O \'rtancha botir ajdarni yengadi. Uchinchi kecha Kenja botir podshoh xazinasiga tushmoqchi bo\'lgan o\'g\'rilarni qirib tashlaydi. Ertasi kuni botirlar shaharga kirib, bir joyga qo\'nadilar.\nJoy egasi bu botirlarni o\'rdaga borishga taklif qildi. Bular piyoda asta-sekin o\'rdaga bordilar. Podshoh bularning musofir ekanligini bilib, alohida bir ziynatlangan uyga kirgizib qo\'ydi. Boshqa musofir bo\'lmaganidan, ularga juda diqqat-e\'tibor biian qarab, sir olmoqni bir vazirga topshirdi. Vazir aytdi: «Bulardan to\'g\'ridan to\'g\'ri so\'rasak, ehtimol aytmaslar, o\'z hollariga qo\'yib, tashqaridan quloq solib turamiz, nima desalar so\'zlaridan sirini topamiz», dedi. Bu xonada bulardan boshqa hech kim yo\'q edi. Bir vaqt dasturxon yozildi, xilma-xil noz-ne\'matlar keltirib qo\'yildi. Ikkinchi bir xonaning teshigidan podshoh bilan vazir quloq solib jim o\'tirdilar. Birozdan keyin uch og\'a-ini botirlar o\'zaro suhbat qila boshladilar. To\'ng\'ich botir dasturxondagi ovqatni ko\'rsatib:\n— Shu go\'sht qo\'zi go\'shti ekan, biroq shu qo\'zi it emib katta bo\'lgan ekan, — dedi.\nO\'rtancha botir aytdi:\n— To\'g\'ri aytasiz, podshoh degani it go\'shtidan ham qaytmaydi. Saralab yemoq faqirning ishi, qo\'yni boqib qo\'yibdimi? Men ham bir narsaga hayron bo\'lib turibman, mana shu shinnidan ham odam isi keladi.\nKenja botir aytdi:\n— To\'g\'ri, podshohlik — qonxo\'rlik demakdir. Qon qo\'shilgan bo\'lsa, ehtimoldan uzoqmasdir. Lekin yomonning qoni bo\'lsa-ku, mayli, begunohning qoni qo\'shilgan bo\'lmasin. Men ham bir narsaga hayron bo\'ldim. Shu nonni taxlagan kishining otasi novvoy ekan, taxlovchi novvoyning o\'g\'li ekan.\n— To\'g\'ri bo\'lsa kerak, — debdi To\'ng\'ich botir. — Podshoh bizni bu yerga o\'rda voqeasi bilan chaqirgan. Albatta bizdan savol so\'rar, nima deymiz?\n— Albatta yolg\'on so\'zlamaymiz, — debdi O\'rtancha botir, — bu voqeaga aralashgan bo\'lsak, aytmoq lozimdir.\nKenja botir:\n— Uch kunlik yo\'lda qanday voqealarni ko\'rgan bo\'lsak, o\'rtaga tashlaydigan vaqt keldi, — dedi.\nTo\'ng\'ich botir birinchi kechada sher bilan olishganini aytib, belidagi tasmasini o\'rtaga olib qo\'ydi. O\'rtancha botir ikkinchi kechadagi voqeani aytib, nishona uchun tasmani o\'rtaga tashladi. Kenja botir uchinchi kechadagi voqeani aytib, olgan narsalarini o\'rtaga tashladi.\nPodshoh bilan vazir sirdan xabardor bo\'ldilar. Faqat go\'sht, shinni, non to\'g\'risidagi gaplarni tekshirib ko\'rmoqchi bo\'ldilar. Birinchi qo\'ychivonni chaqirtirishdi. Podshoh qo\'ychivondan so\'radi:\n— To\'g\'risini ayt, kecha so\'yilgan qo\'zining onasi itmidi?\n— Podshohim, bir qoshiq qonimdan kechsangiz aytaman.\n— O\'tdim, to\'g\'risini so\'yla!\n— Qishning o\'rtasida bir qo\'y tug\'ib, o\'zi o\'lib qoldi, shu vaqtda bir katta itim ham tug\'gan edi. Qo\'zichoqqa rahmim keldi. Yetim qo\'zini och qoldirgim kelmadi. Nochor o\'sha itga emizdirib, katta qilgan edim. Boshqa qo\'zi qolmagani uchun o\'shani yuborgandim, — dedi.\nPodshoh bog\'bonni chaqirib:\n— To\'g\'risini ayt, shinniga odam qoni qo\'shilganmi? — dedi.\n— Podshohim, bir qoshiq qonimdan o\'tsangiz, bir voqea bo\'lgan edi, aytardim, — dedi.\n— Ayt, o\'tdim, — dedi. Bog\'bon:\n— O\'tgan yozda, bog\'dagi uzumzorga har kecha bir odam o\'g\'irlikka tushib, sizga olib qo\'ygan eng yaxshi uzumdan o\'g\'irlab olib keta boshladi. Bir kuni agar qo\'limga tushsa, o\'ldirib, shu tokning tagiga ko\'mib qo\'yay, deb qasd qildim. Bir kecha poylab yotdim. Yana keldi. Shashvar to\'qmoq bilan boshiga urdim. Boshi pachoq-pachoq bo\'lib ketdi. Hech kim bilgani yo\'q. Shu tok tagiga chuqur kavlab ko\'mib qo\'ydim, kelasi yili tok kuchlanib, chunon hosil qildiki, bargidan ham uzumi ko\'p edi. Lekin mazasida ozgina o\'zgarish paydo bo\'ldi. Men uzumdan sizga yubormay, butunicha shinni qilgan edim, — dedi.\nNonni podshoh o\'zi taxlagan edi. Bu shohning otasi novvoy edi. Podshoh haqiqatlar bilinganidan keyin, bularning zakovatiga «ofarin» deb, botirlarning oldiga kirdi. Salom berib ko\'rishdi. Hech bir narsa so\'ramay:\n— Sizlarning hamma aytganlaringiz to\'g\'ri bo\'lib chiqdi, mening sizlarga muhabbatim ortdi. Botir mehmonlar, ijozat bersangiz, bir arzim bor edi, agar qabul qilsangiz aytar edim, — dedi.\nTo\'ng\'ich botir:\n— Aytganlaringiz to\'g\'ri kelsa qabul qilarmiz, aytingiz! — dedi. Podshoh:\n— Mening uchta qizim bor, o\'g\'lim yo\'qdir. Men ertaga butun shaharni to\'yga chaqirib, qirq kun osh berib, qizlarimni sizlarga nikohlab bersam, mening o\'g\'illarim bo\'lib, bunda qolsangiz, — dedi.\nTo\'ng\'ich botir:\n— Xo\'p yaxshi aytasiz, lekin bizning ham shartimiz bor. Bizlar podshoh bolasi emasmiz. Otamiz boy ham emas. Sizning davlatingiz podshohlik bilan topilgan, biz qo\'l kuchi bilan tarbiyat topganmiz. Elimiz bir bo\'lsa ham, tarbiyamiz boshqa. Qanday bo\'lar ekan? — dedi.\nPodshoh:\n— Men bir iqlimning podshohiman, sizni otangiz qo\'l kuchi bilan tarbiya qilib, sizday botirlarning otasi bo\'lgan ekan, mendan nima kamligi bor? Haqiqatda mendan ortiqdir. Tarbiyangiz orqasida jahon podshohlari yig\'lab oshiq bo\'lib yurgan qizlarning otasi sizga o\'z qizlarini yig\'lab tutadi, — dedi.\nBular qabul qildilar. Shaharda qirq kun to\'y-tomosha bo\'lib, botirlar podshoh qizlariga uylandilar. Qizlar yo\'qotgan tillalariga gavhar qo\'shib oldilar. Yaxshi tarbiya orqasida yigitlar baxt qushini qo\'lga kirgizdilar. Qizlar bilan botirlar ipakdek eshildilar.\nPodshoh hamma kuyovidan ham Kenja botirni ko\'proq yaxshi ko\'rardi. Kunlardan bir kun podshoh bir salqin joyda uxlab yotgan edi, yonidagi ariqdan bir ilon chiqib, podshohga zahar solmoqchi bo\'lib turganda, to\'satdan kelib qolgan Kenja botir uni ko\'rib, belidan qilichini sug\'urib, chopib, ikki bo\'lib tashladi. Yana qilichini qiniga solib turganida podshoh uyg\'onib qoldi. Dilida: «Qizimni berganimga qanoat qilmay, meni o\'ldirib, podshoh bo\'lmoq xayoli bor ekan», deb shubha qildi. Vazirga chiqib voqeani aytdi. Vazirning botirlarga hasad-adovati bo\'lib, qulay paytni kutib yurgan ekan, yaxshi bahona bo\'ldi.\nVazir podshohga:\n— Shunday bebaho qizlaringizni, mendan bir maslahat so\'ramay, yaxshi tarbiya ko\'rgan deb, musofirlarga berib qo\'ydingiz, endi mana bir uchini sizga ko\'rsatdi. Eng yaxshi deb sevgan kuyovingiz sizni o\'ldirmoqchi bo\'lgan ekan, yana bir kuni boshqacharoq hiyla bilan sizni o\'ldirib qo\'yar, — dedi.\nPodshoh vazirning so\'ziga ishonib:\n— Zindonga solinsin! — deb buyurdi.\nKenja botirni zindonga soldilar. Kenja botirning qallig\'i juda xafa bo\'ldi. U botirni nihoyatda yaxshi ko\'rardi. Yig\'lab-yig\'lab, kelinchakning yuzlari so\'liy boshladi.\nBir kuni qiz otasining oyog\'iga boshini qo\'yib, yig\'lab, qallig\'ini afv etishni so\'radi. Podshoh qizining yuzidan o\'tolmay, Kenja botirni zindondan oldirib keldi. Qallig\'i juda sog\'inganidan kuyovini quchoqlab, yuzlaridan o\'pib, qo\'lini yelkasiga tashlab yig\'lab turar ekan, podshoh Kenja botirga qarab:\n— Botir, siz shunday vafosizmisiz? Ko\'rmayapsizmi, mening qizim sizga qanday mehribon. Shu qizimni ham rioya qilmay, qay ko\'ngil bilan meni o\'ldirmoqchi bo\'ldingiz? — dedi. Kenja both podshohga qarab bir hikoya aytdi.\n\n\nHIKOYA\nBir zamonda bir poshdoh bor ekan, uning yaxshi ko\'rgan bir to\'tisi bor ekan. Podshoh to\'tisini shunday yaxshi ko\'rar ekanki, bir soat ko\'rmasa turolmas ekan. To\'ti ham podshohga juda mehribon bo\'lib, har turli shirin so\'zlar aytib, xursand qilar ekan. Bir kuni to\'ti podshohdan so\'rabdi:\n— Mening Hindiston degan yurtda ota-onam, aka-ukam, opa-singillarim bor, falakning gardishi bilan sizning dargohingizga kelib qolgan edim. Shukurlar bo\'lsin, aql-idrokim, yaxshi xulqim, shirin so\'zim orqasida sizday podshohga hamsuhbat bo\'ldim. Endi, iltimosim shuki, meni qafasdan bo\'shatib, yigirma kunga javob bersangiz, olti kun borishim, olti kim kelishimga ketsa, bir hafta — ota-onam, aka-ukalarimni ko\'rib diydoriga to\'ymog\'im uchun yetar.\nPodshoh:\n— Yo\'q, senga javob bersam, yana kelmay qolsang, men sog\'inaman, juda xafa bo\'laman, — debdi.\nTo\'ti:\n— Yo\'q, podshohim, sizning menga ko\'rsatgan iltifotingiz yomon yo\'lga boshlamaydi, qanday bo\'lsayam va\'da — ulug\', muqaddas narsa, uni buzish yaramaydi. Va\'dani buzmoq og\'ir gunoh. So\'z beraman — so\'zimda turaman, — debdi.\n— Xo\'p bo\'lmasa, agar tezda kelsang ikki haftaga ruxsat beraman, — debdi podshoh.\n— Xayr, endi qanday bo\'lsa ham chiqay, — deb to\'ti o\'n besh kunga ruxsat olibdi. Devorga qo\'nib turib, xayrlashibdi. Janub tomonga qarab uchib ketibdi. Podshoh orqasidan qarab qolibdi. Podshoh to\'tining qaytib kelishiga ishonmas ekan.\nTo\'ti olti kun deganda Hindiston degan mamlakatga borib, ota-onalarining oldiga yetibdi. Bechora to\'ti juda xursand bo\'lib, tog\'dan tog\'ga, bog\'dan bog\'ga, shoxdan shoxga sakrab, uchib, o\'ynab-kulib, ota-onasining diydoriga to\'ydi, qarindosh-urug\'iga mehmon bo\'lib, uch kunni qanday o\'tkazganini bilmay qoldi. Ertasi yana qafas tomonga, tutqunlikka uchmog\'i kerak ekan. Ota-onasi, aka-ukalaridan ajralmoq juda og\'ir bo\'libdi. Bir tarafda va\'da bor, va\'daga vafosizlik xavfi turadi. Bechora to\'tining quvonchi tugabdi. Shodligi g\'amga almashibdi. Qanotlari so\'libdi. Ikkinchi qaytib kelish yo bor, yo yo\'q. Qarindosh-urug\'lar bir joyga to\'planishibdi. Hammasining ko\'zi g\'amli to\'tida ekan. Qanday bo\'lsa ham qaytmaslikni maslahat berishibdi. To\'ti aytibdi:\n— Yo\'q, yana qaytmoq uchun va\'da berganman, va\'daga vafo qilmasa bo\'ladimi?\nBir to\'ti aytibdi:\n— Va\'da bergan podshohingda insof bo\'lsa, seni uch yil qamoqda saqlab, faqat ikki haftaga javob berarmidi? Seni sevar ekan, seviklisini qafasda tutmoq yarashadimi? Dunyoga qafasda turmoq uchun keldingmi? Bir kishining xushvaqtligi uchun erkinlikni qo\'ldan berma! Podshoh deganning marhamatidan qahri ortiqdir, podshoh bilan sherga yaqin bo\'lmoq hikmatdan emasdir.\nPodshohning to\'tisi aytibdi:\n— Menga bir yo\'l ko\'rsating, men ham erkinlikka chiqay, ham va\'da yolg\'on bo\'lmasin.\nOna to\'ti aytibdi:\n— Shunday bo\'lsa men ham bir maslahat beraman. Bizning joyda bir daraxtning mevasi bor, har kim bir donasini yesa, qari chol bo\'lsa yigitlik holiga qaytur. Kampir yesa qiz kabi yoshlik holiga kelur. Podshohga shundan uch donasini olib borgin, bu bebaho mevani berib, o\'zingning butunlay ozod etilishingni so\'ra, shoyad insofga kelib, butunlay ozod etsa, — debdi.\nBu gap ma\'qul tushibdi. Shu chog\'da uch dona meva olib kelibdilar. To\'ti uni changalida mahkam ushlab, xayrlashib shimol tomonga qarab uchibdi. Qarindoshlari zo\'r umid bilan orqasidan qarab qolishibdi.\nTo\'ti olti kun deganda podshohning saroyiga yetib kelibdi. Podshoh bilan ko\'rishib, olib kelgan tortiqni unga beribdi, xosiyatlarini bir-bir aytibdi. Podshoh juda xursand bo\'libdi. Ozod qilmoqqa va\'da beribdi. Bir donasini xotiniga berib, ikki donasini vazirga ko\'rsatmoq uchun bir piyolaga solib qo\'yibdi. Ertasiga vazirga ko\'rsatib, xosiyatlarini aytibdi. Vazirning bunga hasadi kelibdi. Ichida xafa bo\'libdi. Ishni boshqacha yo\'lga burmoqni ixtiyor qilibdi:\n— Siz bu parrandaning olib kelgan narsasini yemay turing, oldin bir tajriba qilib ko\'raylik, durust bo\'lsa yemoq qochmaydi, — debdi.\nBu gap podshohga ma\'qul tushibdi. Vazir vaqtini topib, piyoladagi ikki dona yoshartiruv mevasiga zahar aralashtirib qo\'yibdi. Bir kundan keyin vazir aytibdi:\n— Endi yoshartiruv mevasini bir tajriba qilaylik.\nBuning uchun qamoqxonadan ikki nafar odamni olib chiqib yediribdilar. Ikkalasi shu chog\'dayoq o\'libdi. Vazir aytibdi:\n— Agar siz yesangiz nima bo\'lardingiz?\n— Men ham o\'lardim, — debdi podshoh.\nBechora to\'tini qafasdan sudrab olib chiqib, kallasini tanasidan uzib tashlabdilar.\nBir kuni podshoh bir odamni g\'azab bilan o\'ldirmoqchi bo\'libdi. Bu kishi keksa ekan. Qolgan bir dona mevani yemoqqa buyuribdi. Haligi odam mevani yegan ekan, oqargan sochlari tushib ketibdi, tishlari butun bo\'lib, ko\'zlarining nuri ortib, yigirma yashar yigit holiga kelib qolibdi. Podshoh vazirdan shubhalanib, piyolani olib kelib qaragan ekan, zahar qo\'shilganligini bilibdi. Podshoh vazirni ham o\'ldirib yuboribdi. Bechora to\'tining begunoh o\'lganiga qayg\'uribdi, lekin ish o\'tgan ekan. To\'ti podshohga yaqin bo\'lganining «mukofoti»nigina ko\'ribdi.\n— Endi men o\'zimning qilgan yaxshiligimni aytay, — debdi Kenja botir va ariqdan chiqqan ilon voqeasini aytibdi. O\'sha joyda ikki bo\'linib yotgan ilon tanasini olib kelib ko\'rsatibdi. Podshoh qilgan ishiga pushaymon bo\'libdi. Kenja botirdan uzr so\'rabdi.\nKenja botir aytdi:\n— Taqsir, endi ruxsat bersangiz, bizlar o\'z yurtimizga qaytsak. Podshoh yalinib-yolvorib, qolishlarini so\'radi. Qabul qilmadilar.\n— Biz saroy kishisi bo\'lolmaymiz. Biz mehnat bilan, kasb-hunar bilan yashaymiz, — dedilar.\nPodshoh:\n— Bo\'lmasa qizlarim qolsinlar, — degan edi, qizlari rozi bo\'lishmadi. Ular:\n— Biz kuyovlarimizdan ajralmaymiz, ruxsat bersangiz, biz ham kuyovlarimiz bilan birga ketsak, sizni ko\'rgani har yili kelib turamiz, — deyishibdi.\nPodshoh hayron bo\'lib, nochor ruxsat berdi. Butun narsalarini yig\'ishtirib, safarga chiqdilar. Botir yigitlar o\'z xotinlari bilan ikki yil deganda, otalarining oldiga olti kishi bo\'lib keldilar. Botirlar otalari bilan quchoqlashib ko\'rishib, xotinlarini tanishtirdilar. Otasi ham, bularning kelishini eshitib, uch bo\'lak hovlibog\' tayyorlab qo\'ygan edi. Har birlari tayinlangan joyga ko\'chib kirdilar. Qizlar kuyovlari bilan rohat-farog\'atda yashab, murod-maqsadlariga yetdilar.',
      'en': '',
      'ru': '',
    },
    'leoo5l9t': {
      'uz': '1K o\'qishlar',
      'en': '',
      'ru': '',
    },
  },
  // food1
  {
    'obypvbvo': {
      'uz': 'Olma Pyuresi',
      'en': '',
      'ru': '',
    },
    '9e36hzwv': {
      'uz': 'Olma Pyuresi',
      'en': '',
      'ru': '',
    },
    '03f1ouyv': {
      'uz': 'Bolalar uchun • 20 daqiqa • Oson',
      'en': '',
      'ru': '',
    },
    '1yn0lez1': {
      'uz': '4.8',
      'en': '',
      'ru': '',
    },
    'xg6rag42': {
      'uz': '20 daqiqa',
      'en': '',
      'ru': '',
    },
    'oepx77r8': {
      'uz': '2-3 porsiya',
      'en': '',
      'ru': '',
    },
    'i5gic4e6': {
      'uz': '90 kaloriya',
      'en': '',
      'ru': '',
    },
    '3j4dgd7k': {
      'uz': 'Masalliqlar',
      'en': '',
      'ru': '',
    },
    'ab0lc4cd': {
      'uz': '2 ta o‘rta kattalikdagi olma (qizil yoki yashil)',
      'en': '',
      'ru': '',
    },
    'mumafo2l': {
      'uz': '1/4 stakan suv (yoki ona suti/formula, ixtiyoriy)',
      'en': '',
      'ru': '',
    },
    '2425ff55': {
      'uz': '1 choy qoshiq limon sharbati (ixtiyoriy, rangini saqlash uchun)',
      'en': '',
      'ru': '',
    },
    '2d9foixv': {
      'uz': 'Tayyorlanishi',
      'en': '',
      'ru': '',
    },
    '2btk1emb': {
      'uz': '1',
      'en': '',
      'ru': '',
    },
    'ox1u7j1q': {
      'uz':
          'Olmalarni yuvib, tozalang va urug‘ qismlarini olib tashlab, bo‘laklarga bo‘ling',
      'en': '',
      'ru': '',
    },
    'qd8flosd': {
      'uz': '2',
      'en': '',
      'ru': '',
    },
    'sx0x3bmv': {
      'uz':
          'Kichikroq qozonda olma bo‘laklarini suv bilan 10-15 daqiqa davomida yumshaguncha pishiring.',
      'en': '',
      'ru': '',
    },
    'hqxasgjr': {
      'uz': '3',
      'en': '',
      'ru': '',
    },
    'vukw5onj': {
      'uz':
          'Sovib ketgach, blender yoki pyure tayyorlash moslamasida silliq holga keltiring.',
      'en': '',
      'ru': '',
    },
    'ul6zvd9m': {
      'uz': '4',
      'en': '',
      'ru': '',
    },
    'g779e5fr': {
      'uz':
          'Zarurat bo‘lsa, silliqligini sozlash uchun ozroq suv yoki ona suti/formula qo‘shing.',
      'en': '',
      'ru': '',
    },
    'ajr96zgl': {
      'uz': '5',
      'en': '',
      'ru': '',
    },
    'mlueqt55': {
      'uz': 'Issiq yoki sovutilgan holda saqlang.',
      'en': '',
      'ru': '',
    },
    'ybtitbm1': {
      'uz': 'Oziqaviy Ma\'lumot',
      'en': '',
      'ru': '',
    },
    'zloymphw': {
      'uz': '90',
      'en': '',
      'ru': '',
    },
    'qs79ftto': {
      'uz': 'Kaloriya',
      'en': '',
      'ru': '',
    },
    'zw2lhmst': {
      'uz': '0.3g',
      'en': '',
      'ru': '',
    },
    '2q7q911m': {
      'uz': 'Oqsil',
      'en': '',
      'ru': '',
    },
    '0m0qo80o': {
      'uz': '0.2g\t',
      'en': '',
      'ru': '',
    },
    'mw4m9g8e': {
      'uz': 'Yog‘',
      'en': '',
      'ru': '',
    },
    'zl91imbh': {
      'uz': '24g',
      'en': '',
      'ru': '',
    },
    '92cp80t2': {
      'uz': 'Uglevod',
      'en': '',
      'ru': '',
    },
    'i961wb7c': {
      'uz': 'Maslahatlar va Izohlar\n',
      'en': '',
      'ru': '',
    },
    'lkbgc2cj': {
      'uz':
          'Olmalarni bug‘da pishirish ham mumkin – bu usulda ko‘proq foydali moddalar saqlanadi.',
      'en': '',
      'ru': '',
    },
    'ocf58dtk': {
      'uz': 'Tayyor pyureni kichik porsiyalarda muzlatib qo‘yish mumkin.',
      'en': '',
      'ru': '',
    },
    'ov2h1and': {
      'uz':
          'Yangi tatib ko‘rishga kirishayotgan bolalarga allergiyani kuzatish uchun har bir yangi meva bilan oraliq qiling.',
      'en': '',
      'ru': '',
    },
    'vmzy4zg4': {
      'uz': 'Retseptni saqlash',
      'en': '',
      'ru': '',
    },
  },
  // food2
  {
    'mp2fszmq': {
      'uz': 'Banana Mix',
      'en': '',
      'ru': '',
    },
    't54hr72q': {
      'uz': 'Banana Mix',
      'en': '',
      'ru': '',
    },
    '294attf4': {
      'uz': 'Bolalar uchun • 10 daqiqa • Oson',
      'en': '',
      'ru': '',
    },
    '23605dnw': {
      'uz': '4.5',
      'en': '',
      'ru': '',
    },
    'lknvf8sa': {
      'uz': '10 daqiqa',
      'en': '',
      'ru': '',
    },
    't8amb2gu': {
      'uz': '2-3 porsiya',
      'en': '',
      'ru': '',
    },
    '5t98t3tl': {
      'uz': '100 kaloriya',
      'en': '',
      'ru': '',
    },
    '2doarcxt': {
      'uz': 'Masalliqlar',
      'en': '',
      'ru': '',
    },
    'm4kemfm8': {
      'uz': '1 ta pishgan banan',
      'en': '',
      'ru': '',
    },
    'gdk5p7zo': {
      'uz': '1/4 stakan ona suti yoki formula (yoki oddiy suv)',
      'en': '',
      'ru': '',
    },
    'rtlgatla': {
      'uz': '1 choy qoshiq suli bo‘tqasi (ixtiyoriy, mustahkamlik uchun)',
      'en': '',
      'ru': '',
    },
    'jmdo2336': {
      'uz': '1/4 olma pyuresi (ixtiyoriy, ta\'mni boyitish uchun)',
      'en': '',
      'ru': '',
    },
    'd0645iud': {
      'uz': 'Tayyorlanishi',
      'en': '',
      'ru': '',
    },
    'h72r6ylu': {
      'uz': '1',
      'en': '',
      'ru': '',
    },
    '86p4ec7z': {
      'uz': 'Bananni tozalang va kichik bo‘laklarga bo‘ling.',
      'en': '',
      'ru': '',
    },
    '7g8mc57r': {
      'uz': '2',
      'en': '',
      'ru': '',
    },
    '4xyrtlje': {
      'uz':
          'Blender yoki vilka yordamida banan va boshqa masalliqlarni silliq holga keltiring.',
      'en': '',
      'ru': '',
    },
    'z4rym9yq': {
      'uz': '3',
      'en': '',
      'ru': '',
    },
    'x669lyp0': {
      'uz': 'Konsistensiyani sozlash uchun ona suti yoki suvdan foydalaning.',
      'en': '',
      'ru': '',
    },
    '872myvod': {
      'uz': '4',
      'en': '',
      'ru': '',
    },
    'xu7l85xg': {
      'uz': 'Darhol tanavvul qiling yoki muzlatgichda 24 soatgacha saqlang.',
      'en': '',
      'ru': '',
    },
    '497knsj0': {
      'uz': 'Oziqaviy Ma\'lumot',
      'en': '',
      'ru': '',
    },
    '6riyrf24': {
      'uz': '100',
      'en': '',
      'ru': '',
    },
    '9einx1ik': {
      'uz': 'Kaloriya',
      'en': '',
      'ru': '',
    },
    'u2z70msy': {
      'uz': '1g',
      'en': '',
      'ru': '',
    },
    '7umdipig': {
      'uz': 'Oqsil',
      'en': '',
      'ru': '',
    },
    'v2abzm01': {
      'uz': '0.3g',
      'en': '',
      'ru': '',
    },
    'y5f0s81q': {
      'uz': 'Yog‘',
      'en': '',
      'ru': '',
    },
    'rtuurqnv': {
      'uz': '26g',
      'en': '',
      'ru': '',
    },
    'wu0mxvcs': {
      'uz': 'Uglevod',
      'en': '',
      'ru': '',
    },
    'rwv7crhv': {
      'uz': 'Maslahatlar va Izohlar',
      'en': '',
      'ru': '',
    },
    'b6ljpk7b': {
      'uz': 'Juda pishgan banan eng yaxshi natija beradi – shirin va silliq.',
      'en': '',
      'ru': '',
    },
    'olu7tsow': {
      'uz':
          'Muzlatilgan banan bo‘laklaridan foydalanish salqinroq pyure tayyorlashga yordam beradi.',
      'en': '',
      'ru': '',
    },
    'o5s2sj8h': {
      'uz': 'Retseptni saqlash',
      'en': '',
      'ru': '',
    },
  },
  // food3
  {
    '9fp1x3d7': {
      'uz': 'Shirin kartoshka',
      'en': '',
      'ru': '',
    },
    'mpamxm7q': {
      'uz': 'Shirin kartoshka',
      'en': '',
      'ru': '',
    },
    'gmmlm17a': {
      'uz': 'Bolalar uchun • 25 daqiqa • Oson',
      'en': '',
      'ru': '',
    },
    '3e3qvjww': {
      'uz': '4.5',
      'en': '',
      'ru': '',
    },
    'xsa8d3tp': {
      'uz': '25 daqiqa',
      'en': '',
      'ru': '',
    },
    'kte7lmax': {
      'uz': '2-3 porsiya',
      'en': '',
      'ru': '',
    },
    '8polxyzq': {
      'uz': '90 kaloriya',
      'en': '',
      'ru': '',
    },
    'vf0doqf0': {
      'uz': 'Masalliqlar',
      'en': '',
      'ru': '',
    },
    'v23sdsyt': {
      'uz': '1 dona o‘rta kattalikdagi shirin kartoshka (batat)',
      'en': '',
      'ru': '',
    },
    'zf6of4ng': {
      'uz': '1/4 stakan suv, ona suti yoki formula (ixtiyoriy)',
      'en': '',
      'ru': '',
    },
    'ykm4rvwl': {
      'uz': 'Tayyorlanishi',
      'en': '',
      'ru': '',
    },
    'p0vft83m': {
      'uz': '1',
      'en': '',
      'ru': '',
    },
    '4h9fets1': {
      'uz': 'Shirin kartoshkani yuving, tozalang va bo‘laklarga bo‘ling.',
      'en': '',
      'ru': '',
    },
    'nrj6oo10': {
      'uz': '2',
      'en': '',
      'ru': '',
    },
    '4ikwiakn': {
      'uz': 'Qozonda suvda yoki bug‘da 15–20 daqiqa yumshaguncha pishiring.',
      'en': '',
      'ru': '',
    },
    'no4g9wzx': {
      'uz': '3',
      'en': '',
      'ru': '',
    },
    '360y07oa': {
      'uz':
          'Soviganidan so‘ng blender yoki vilkada silliq pyure holatiga keltiring.',
      'en': '',
      'ru': '',
    },
    'k9wpd9lb': {
      'uz': '4',
      'en': '',
      'ru': '',
    },
    '20qyeso2': {
      'uz':
          'Konsistensiyani kerakli holga keltirish uchun ozroq suv yoki ona suti qo‘shing.',
      'en': '',
      'ru': '',
    },
    'kpgg1niz': {
      'uz': '5',
      'en': '',
      'ru': '',
    },
    'ysntg75j': {
      'uz': 'Issiq yoki xona haroratida bolaga bering.',
      'en': '',
      'ru': '',
    },
    '7nuemf47': {
      'uz': 'Oziqaviy Ma\'lumot',
      'en': '',
      'ru': '',
    },
    'xatilsmx': {
      'uz': '90',
      'en': '',
      'ru': '',
    },
    'ela3h4by': {
      'uz': 'Kaloriya',
      'en': '',
      'ru': '',
    },
    'fc64h0zo': {
      'uz': '2g',
      'en': '',
      'ru': '',
    },
    'xw10t3yu': {
      'uz': 'Oqsil',
      'en': '',
      'ru': '',
    },
    '6u6zq7j8': {
      'uz': '\t0.1g',
      'en': '',
      'ru': '',
    },
    '34gix5re': {
      'uz': 'Yog‘',
      'en': '',
      'ru': '',
    },
    'tuvd5r8n': {
      'uz': '21g',
      'en': '',
      'ru': '',
    },
    'vbiugr9q': {
      'uz': 'Uglevod',
      'en': '',
      'ru': '',
    },
    '0wb0hyq5': {
      'uz': 'Maslahatlar va Izohlar',
      'en': '',
      'ru': '',
    },
    '6gy1vu44': {
      'uz':
          'Shirin kartoshka temir va A vitamini bilan boy – bu uni mukammal tanlovga aylantiradi.',
      'en': '',
      'ru': '',
    },
    'bjepyku7': {
      'uz':
          ' Tayyor pyureni kichik konteynerlarga bo‘lib, muzlatib qo‘yish mumkin.',
      'en': '',
      'ru': '',
    },
    'rpnq8ve2': {
      'uz':
          'Kartoshkani bug‘da pishirish foydali moddalarni saqlab qolishga yordam beradi.',
      'en': '',
      'ru': '',
    },
    '7qietdec': {
      'uz': 'Retseptni saqlash',
      'en': '',
      'ru': '',
    },
  },
  // food4
  {
    'dx71n81j': {
      'uz': 'Asalli Grek Yogurt',
      'en': '',
      'ru': '',
    },
    'ki2ak04g': {
      'uz': 'Asalli Grek Yogurt',
      'en': '',
      'ru': '',
    },
    '6tbqj4a3': {
      'uz': 'Onalar uchun • 5 daqiqa • Oson',
      'en': '',
      'ru': '',
    },
    'dkjv48ss': {
      'uz': '4.5',
      'en': '',
      'ru': '',
    },
    'esbf5b2x': {
      'uz': '5 daqiqa',
      'en': '',
      'ru': '',
    },
    '05cpcvj0': {
      'uz': '2 porsiya',
      'en': '',
      'ru': '',
    },
    'gc5i66he': {
      'uz': '110 kaloriya',
      'en': '',
      'ru': '',
    },
    'uhffnl93': {
      'uz': 'Masalliqlar',
      'en': '',
      'ru': '',
    },
    '2aszmr5w': {
      'uz': '1/2 stakan oddiy (shakarsiz) Grek yogurti',
      'en': '',
      'ru': '',
    },
    'b2but1ds': {
      'uz': '1 choy qoshiq tabiiy asal (faqat 1 yoshdan katta bolalar uchun!)',
      'en': '',
      'ru': '',
    },
    '8iyfx8ny': {
      'uz': '1/4 banan yoki 2 qoshiq meva pyuresi (ixtiyoriy)',
      'en': '',
      'ru': '',
    },
    'kryvx6kr': {
      'uz': 'Tayyorlanishi',
      'en': '',
      'ru': '',
    },
    'sgbd261c': {
      'uz': '1',
      'en': '',
      'ru': '',
    },
    'x5yyjq36': {
      'uz': 'Grek yogurtini kichik idishga soling.',
      'en': '',
      'ru': '',
    },
    '64kqfl83': {
      'uz': '2',
      'en': '',
      'ru': '',
    },
    'vqf1abva': {
      'uz': 'Asal va mevali pyure yoki bo‘lakchalarni qo‘shing.',
      'en': '',
      'ru': '',
    },
    'w9j0mnkr': {
      'uz': '3',
      'en': '',
      'ru': '',
    },
    'x9uqv08q': {
      'uz': 'Yaxshilab aralashtiring va darhol bolaga tanavvul qiling.',
      'en': '',
      'ru': '',
    },
    '5r7ezjp6': {
      'uz': '4',
      'en': '',
      'ru': '',
    },
    '53uw8zvw': {
      'uz': 'Sovuq holatda iste’mol qilish yaxshiroq.',
      'en': '',
      'ru': '',
    },
    'qp11445d': {
      'uz': 'Oziqaviy Ma\'lumot',
      'en': '',
      'ru': '',
    },
    '88swiywn': {
      'uz': '110',
      'en': '',
      'ru': '',
    },
    'mclcu3kt': {
      'uz': 'Kaloriya',
      'en': '',
      'ru': '',
    },
    'nqw6rrrh': {
      'uz': '\t5g',
      'en': '',
      'ru': '',
    },
    'm43rhx1h': {
      'uz': 'Oqsil',
      'en': '',
      'ru': '',
    },
    'wcqk7509': {
      'uz': '2g',
      'en': '',
      'ru': '',
    },
    'oenlxtun': {
      'uz': 'Yog‘',
      'en': '',
      'ru': '',
    },
    's8akq0ic': {
      'uz': '18g',
      'en': '',
      'ru': '',
    },
    'yfs1r5p7': {
      'uz': 'Uglevod',
      'en': '',
      'ru': '',
    },
    '1gfx0of5': {
      'uz': 'Maslahatlar va Izohlar',
      'en': '',
      'ru': '',
    },
    '2653klr8': {
      'uz':
          ' Bu retsept tez tayyorlanadigan, foydali va probiotik boy nonushta yoki gazak sifatida juda qulay.',
      'en': '',
      'ru': '',
    },
    'sdynkxpy': {
      'uz': 'Retseptni saqlash',
      'en': '',
      'ru': '',
    },
  },
  // food5
  {
    'sk1fynd1': {
      'uz': 'Laktasmuzi',
      'en': '',
      'ru': '',
    },
    's9qw5aly': {
      'uz': 'Laktasmuzi',
      'en': '',
      'ru': '',
    },
    'fqs7rzvj': {
      'uz': 'Onalar uchun • 7 daqiqa • Oson',
      'en': '',
      'ru': '',
    },
    'ckt0m1z1': {
      'uz': '4.5',
      'en': '',
      'ru': '',
    },
    'efz22kce': {
      'uz': '7 daqiqa',
      'en': '',
      'ru': '',
    },
    'v4et9vl5': {
      'uz': '1 porsiya',
      'en': '',
      'ru': '',
    },
    '8qcegil1': {
      'uz': '250 kaloriya',
      'en': '',
      'ru': '',
    },
    'd3s9ex2i': {
      'uz': 'Masalliqlar',
      'en': '',
      'ru': '',
    },
    'g2cm82do': {
      'uz': '1 dona pishgan banan',
      'en': '',
      'ru': '',
    },
    '7w5434on': {
      'uz': '1 stakan sut (yoki bodom, jo‘xori, hindiston yong‘og‘i suti)',
      'en': '',
      'ru': '',
    },
    'y390bwz2': {
      'uz': '2 osh qoshiq suli (ovsyanka)',
      'en': '',
      'ru': '',
    },
    'lyepf6md': {
      'uz': '1 choy qoshiq zig‘ir urug‘i (yaxshi maydalanib)',
      'en': '',
      'ru': '',
    },
    '55r2fhkt': {
      'uz': '1 choy qoshiq asal (ixtiyoriy)',
      'en': '',
      'ru': '',
    },
    '2im5e3xr': {
      'uz': 'Bir nechta muz bo‘lagi (ixtiyoriy)',
      'en': '',
      'ru': '',
    },
    '7ip3ntux': {
      'uz': 'Tayyorlanishi',
      'en': '',
      'ru': '',
    },
    'g7o0c8bf': {
      'uz': '1',
      'en': '',
      'ru': '',
    },
    'olbzjui4': {
      'uz': 'Barcha masalliqlarni blenderga soling.',
      'en': '',
      'ru': '',
    },
    'aero6m9e': {
      'uz': '2',
      'en': '',
      'ru': '',
    },
    '7kpityde': {
      'uz': 'Silliq holga kelguncha 1-2 daqiqa aralashtiring.',
      'en': '',
      'ru': '',
    },
    'exyyzaoa': {
      'uz': '3',
      'en': '',
      'ru': '',
    },
    'xyk8mbph': {
      'uz': 'Darhol iching yoki muzlatkichda 15 daqiqa sovuting.',
      'en': '',
      'ru': '',
    },
    'qaif62be': {
      'uz': '4',
      'en': '',
      'ru': '',
    },
    '4bm0y8ts': {
      'uz':
          'Kun davomida laktatsiyani rag‘batlantirish uchun ertalab yoki tushlikdan oldin iste’mol qiling.',
      'en': '',
      'ru': '',
    },
    '0i16a5q7': {
      'uz': 'Oziqaviy Ma\'lumot',
      'en': '',
      'ru': '',
    },
    'zr7fuean': {
      'uz': '250',
      'en': '',
      'ru': '',
    },
    'gazx7z2u': {
      'uz': 'Kaloriya',
      'en': '',
      'ru': '',
    },
    'q2seilya': {
      'uz': '6g',
      'en': '',
      'ru': '',
    },
    'w5iimh0y': {
      'uz': 'Oqsil',
      'en': '',
      'ru': '',
    },
    'myyv606m': {
      'uz': '5g',
      'en': '',
      'ru': '',
    },
    'k3x17ta4': {
      'uz': 'Yog‘',
      'en': '',
      'ru': '',
    },
    '3upoh1qc': {
      'uz': '42g',
      'en': '',
      'ru': '',
    },
    'nr181pws': {
      'uz': 'Uglevod',
      'en': '',
      'ru': '',
    },
    'u4hhzij4': {
      'uz': 'Maslahatlar va Izohlar',
      'en': '',
      'ru': '',
    },
    'wr5veqxm': {
      'uz':
          'Zig‘ir urug‘i omega-3 bilan boy va sut ishlab chiqarishni qo‘llab-quvvatlaydi.',
      'en': '',
      'ru': '',
    },
    'wo0h72r0': {
      'uz':
          'Sut o‘rniga bodom yoki o‘simlik asosidagi sutsimon ichimliklar ham ishlatilishi mumkin.',
      'en': '',
      'ru': '',
    },
    'jdaotk58': {
      'uz':
          'Suli sut bezlarining faoliyatini yaxshilaydi va ko‘p energiya beradi.',
      'en': '',
      'ru': '',
    },
    '0h0leple': {
      'uz': 'Retseptni saqlash',
      'en': '',
      'ru': '',
    },
  },
  // food6
  {
    'ldh3luts': {
      'uz': 'Blinchik',
      'en': '',
      'ru': '',
    },
    'fu7zee58': {
      'uz': 'Blinchik',
      'en': '',
      'ru': '',
    },
    'jimgq8sm': {
      'uz': 'Onalar uchun • 30 daqiqa • Oson',
      'en': '',
      'ru': '',
    },
    '86najgc3': {
      'uz': '4.5',
      'en': '',
      'ru': '',
    },
    'wbsjg2gx': {
      'uz': '30 daqiqa',
      'en': '',
      'ru': '',
    },
    'yt0xl8bi': {
      'uz': '6-8 dona',
      'en': '',
      'ru': '',
    },
    'jrrwe479': {
      'uz': '140 kaloriya',
      'en': '',
      'ru': '',
    },
    '1u72c22y': {
      'uz': 'Masalliqlar',
      'en': '',
      'ru': '',
    },
    'zdcs83jz': {
      'uz': '2 dona tuxum',
      'en': '',
      'ru': '',
    },
    'iehagg4q': {
      'uz': '1,5 stakan sut (yoki o‘simlik suti)',
      'en': '',
      'ru': '',
    },
    't6viuxyh': {
      'uz': '1 stakan un (bug‘doy yoki grechka uni)',
      'en': '',
      'ru': '',
    },
    'yuk8g4me': {
      'uz': '1 osh qoshiq eritilgan sariyog‘',
      'en': '',
      'ru': '',
    },
    '0hhb1zys': {
      'uz': '1 choy qoshiq asal yoki shakar (ixtiyoriy)',
      'en': '',
      'ru': '',
    },
    '9y2kjer8': {
      'uz': '1 chimdim tuz',
      'en': '',
      'ru': '',
    },
    '5x8q202v': {
      'uz': 'Yog‘ (qovurish uchun, minimal miqdorda)',
      'en': '',
      'ru': '',
    },
    'vdmjgp48': {
      'uz': 'Tayyorlanishi',
      'en': '',
      'ru': '',
    },
    'ucqqljfk': {
      'uz': '1',
      'en': '',
      'ru': '',
    },
    'qywnay3h': {
      'uz': 'Tuxum va sutni aralashtiring.',
      'en': '',
      'ru': '',
    },
    'aw10qt5w': {
      'uz': '2',
      'en': '',
      'ru': '',
    },
    'nt338jae': {
      'uz':
          'Un, tuz, asal yoki shakar qo‘shib, bir xil massa hosil bo‘lguncha aralashtiring.',
      'en': '',
      'ru': '',
    },
    'lgycmhch': {
      'uz': '3',
      'en': '',
      'ru': '',
    },
    'v6ollf2z': {
      'uz': 'Eritilgan sariyog‘ni qo‘shing va 5 daqiqa dam oldiring.',
      'en': '',
      'ru': '',
    },
    'wax2qsby': {
      'uz': '4',
      'en': '',
      'ru': '',
    },
    'egfewccv': {
      'uz': 'Qizigan tovada har bir tomoni 1-2 daqiqa pishiring.',
      'en': '',
      'ru': '',
    },
    'lv3p6a6v': {
      'uz': '5',
      'en': '',
      'ru': '',
    },
    'ngoo2np3': {
      'uz': 'Asal, tvorog yoki meva bilan xizmat qiling.',
      'en': '',
      'ru': '',
    },
    'gc3czywe': {
      'uz': 'Oziqaviy Ma\'lumot',
      'en': '',
      'ru': '',
    },
    '6lgl5e8m': {
      'uz': '140',
      'en': '',
      'ru': '',
    },
    'zzhx74mu': {
      'uz': 'Kaloriya',
      'en': '',
      'ru': '',
    },
    '0uqj6i8x': {
      'uz': '4g',
      'en': '',
      'ru': '',
    },
    '2pj1v0pw': {
      'uz': 'Oqsil',
      'en': '',
      'ru': '',
    },
    '6y5dtelj': {
      'uz': '5g',
      'en': '',
      'ru': '',
    },
    'fb7lvdp6': {
      'uz': 'Yog‘',
      'en': '',
      'ru': '',
    },
    '2nw0xyry': {
      'uz': '18g',
      'en': '',
      'ru': '',
    },
    'pvj1ap60': {
      'uz': 'Uglevod',
      'en': '',
      'ru': '',
    },
    '11azk9m5': {
      'uz': 'Maslahatlar va Izohlar',
      'en': '',
      'ru': '',
    },
    '5jfazt17': {
      'uz':
          'Grechka uni hazm qilishga yengil va allergik emas — emizikli onalar uchun yaxshi tanlov.',
      'en': '',
      'ru': '',
    },
    '6mexki4u': {
      'uz':
          'To‘yimli nonushta yoki charchoqni bartaraf etuvchi gazak sifatida juda mos keladi.',
      'en': '',
      'ru': '',
    },
    'tj67moqc': {
      'uz': 'Bolakay uyg‘onib qolsa ham, bir qo‘lda ushlab yeyish qulay!',
      'en': '',
      'ru': '',
    },
    '39fvocht': {
      'uz': 'Retseptni saqlash',
      'en': '',
      'ru': '',
    },
  },
  // Inprogress
  {
    'zdbqh5o7': {
      'uz': 'OZIQLANISH',
      'en': '',
      'ru': '',
    },
    't8g3pegi': {
      'uz': 'Bu sahifa ishlab chiqilmoqda',
      'en': '',
      'ru': '',
    },
  },
  // Inprogress2
  {
    'tyanwd9c': {
      'uz': 'O\'YINLAR',
      'en': '',
      'ru': '',
    },
    '4zd4p6cs': {
      'uz': 'Bu sahifa ishlab chiqilmoqda',
      'en': '',
      'ru': '',
    },
  },
  // Inprogress3
  {
    'ob85jnw0': {
      'uz': 'TA\'LIM',
      'en': '',
      'ru': '',
    },
    'df0libxa': {
      'uz': 'Bu sahifa ishlab chiqilmoqda',
      'en': '',
      'ru': '',
    },
  },
  // bigchat
  {
    '1ekyxyjo': {
      'uz': 'MULOQOT',
      'en': '',
      'ru': '',
    },
    'lcrjg881': {
      'uz': 'CHATBOT',
      'en': '',
      'ru': '',
    },
    'oa6bfdcf': {
      'uz': 'UMUMIY CHAT',
      'en': '',
      'ru': '',
    },
    '141xljpz': {
      'uz': 'ALOQA',
      'en': '',
      'ru': '',
    },
    'wbl14v5x': {
      'uz': 'Salom, qanday yordam bera olaman?',
      'en': '',
      'ru': '',
    },
    '0w2hotg6': {
      'uz': 'Men haqida ma\'lumot kerak edi',
      'en': '',
      'ru': '',
    },
    'uffsxs3n': {
      'uz': 'Albatta, qanday ma\'lumot kerak?',
      'en': '',
      'ru': '',
    },
    'aenxxqp4': {
      'uz': 'hujjat.pdf',
      'en': '',
      'ru': '',
    },
    'sl5ypj05': {
      'uz': 'Mana bu rasmni ko\'ring',
      'en': '',
      'ru': '',
    },
    '1o0ao3g6': {
      'uz': 'Manzara.jpg',
      'en': '',
      'ru': '',
    },
    'xjf8ak4b': {
      'uz': 'Juda chiroyli manzara! Qayerda olingan?',
      'en': '',
      'ru': '',
    },
    '6kpjl9cu': {
      'uz': 'Bu Samarqandda olingan. Sizga yana qanday yordam bera olaman?',
      'en': '',
      'ru': '',
    },
    'igl07rxd': {
      'uz':
          'Samarqand haqida qiziqarli ma\'lumotlar bilan tanishishni xohlaysizmi?',
      'en': '',
      'ru': '',
    },
    'wppo6mbf': {
      'uz': 'samarqand_info.docx',
      'en': '',
      'ru': '',
    },
    '2z6s6qm4': {
      'uz': 'Matn kiriting',
      'en': '',
      'ru': '',
    },
  },
  // calldoctor
  {
    'avg3fdvg': {
      'uz': 'MULOQOT',
      'en': '',
      'ru': '',
    },
    'vs5nelyh': {
      'uz': 'CHATBOT',
      'en': '',
      'ru': '',
    },
    'uswkpl9c': {
      'uz': 'UMUMIY CHAT',
      'en': '',
      'ru': '',
    },
    'zn6uwc5m': {
      'uz': 'ALOQA',
      'en': '',
      'ru': '',
    },
    'nxej5u7x': {
      'uz': 'Doktor A',
      'en': '',
      'ru': '',
    },
    '0fhydu4f': {
      'uz': 'Kardiolog',
      'en': '',
      'ru': '',
    },
    'np1l7wcu': {
      'uz': 'Doktor B',
      'en': '',
      'ru': '',
    },
    'prx1krgh': {
      'uz': 'Nevropatolog',
      'en': '',
      'ru': '',
    },
    '4yznf4dq': {
      'uz': 'Doktor C',
      'en': '',
      'ru': '',
    },
    'hnryfwb0': {
      'uz': 'Pediatr',
      'en': '',
      'ru': '',
    },
    '0q39juin': {
      'uz': 'Doktor D',
      'en': '',
      'ru': '',
    },
    'pazgxfkf': {
      'uz': 'Terapevt',
      'en': '',
      'ru': '',
    },
  },
  // Miscellaneous
  {
    'z15qqgd5': {
      'uz': 'OZIQLANISH',
      'en': '',
      'ru': '',
    },
    's7qkt7dl': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'ws88t63s': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'uenh7s8n': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'r2858yh5': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'hy5n3dho': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'eqiq0xd1': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'vs5zz8b1': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'x1tjozlt': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'kj34xfz5': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'v1772b9j': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'zhmt41d3': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    '8y2mgg9n': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    '1vfex7ya': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'm9hia5km': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'h3l8osn6': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'uwg0rlcn': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'y6chaizs': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'aqa4jzfh': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    '70ez6zv9': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'ttvhuh8j': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'igvdz90f': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'lw4z3bdv': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    '5clx3jbd': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    '683hyfh3': {
      'uz': '',
      'en': '',
      'ru': '',
    },
    'c4fo6msr': {
      'uz': '',
      'en': '',
      'ru': '',
    },
  },
].reduce((a, b) => a..addAll(b));
