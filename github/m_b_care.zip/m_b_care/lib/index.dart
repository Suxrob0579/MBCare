// Export pages
export '/register/register/register_widget.dart' show RegisterWidget;
export '/home/home/home_widget.dart' show HomeWidget;
export '/home/home_b_m_icalculator/home_b_m_icalculator_widget.dart'
    show HomeBMIcalculatorWidget;
export '/register/farzandingizhaqidaamalumotbering/farzandingizhaqidaamalumotbering_widget.dart'
    show FarzandingizhaqidaamalumotberingWidget;
export '/register/userinfo/userinfo_widget.dart' show UserinfoWidget;
export '/register/intro/intro_widget.dart' show IntroWidget;
export '/home/b_m_ishow/b_m_ishow_widget.dart' show BMIshowWidget;
export '/profile/profile/profile_widget.dart' show ProfileWidget;
export '/profile/kundalik/kundalik_widget.dart' show KundalikWidget;
export '/profile/yangikiritma/yangikiritma_widget.dart' show YangikiritmaWidget;
export '/drugs/medicaldrugs/medicaldrugs_widget.dart' show MedicaldrugsWidget;
export '/recommendations/recommendations/recommendations_widget.dart'
    show RecommendationsWidget;
export '/aloqa/comunication_chat_a_i/comunication_chat_a_i_widget.dart'
    show ComunicationChatAIWidget;
export '/profile/lahzalar/lahzalar_widget.dart' show LahzalarWidget;
export '/profile/yangi_lahza/yangi_lahza_widget.dart' show YangiLahzaWidget;
export '/profile/yangitaklif/yangitaklif_widget.dart' show YangitaklifWidget;
export '/recommendations/ertaklar/ertaklar_widget.dart' show ErtaklarWidget;
export '/recommendations/chaqaloquchun/chaqaloquchun_widget.dart'
    show ChaqaloquchunWidget;
export '/recommendations/onauchun/onauchun_widget.dart' show OnauchunWidget;
export '/recommendations/oyinlar/oyinlar_widget.dart' show OyinlarWidget;
export '/home/darslar/darslar_widget.dart' show DarslarWidget;
export '/recommendations/ruhiyat/ruhiyat_widget.dart' show RuhiyatWidget;
export '/recommendations/talim/talim_widget.dart' show TalimWidget;
export '/recommendations/sogliq/sogliq_widget.dart' show SogliqWidget;
export '/home/maqolalar/maqolalar_widget.dart' show MaqolalarWidget;
export '/home/calculator_section3/calculator_section3_widget.dart'
    show CalculatorSection3Widget;
export '/drugs/drugsforbaby/drugsforbaby_widget.dart' show DrugsforbabyWidget;
export '/drugs/drugsformom/drugsformom_widget.dart' show DrugsformomWidget;
export '/drugs/vaksinalar/vaksinalar_widget.dart' show VaksinalarWidget;
export '/drugs/closelocation/closelocation_widget.dart'
    show CloselocationWidget;
export '/home/notifications/notifications_widget.dart' show NotificationsWidget;
export '/home/lessons/sectionvideo1/sectionvideo1_widget.dart'
    show Sectionvideo1Widget;
export '/home/articles/article1/article1_widget.dart' show Article1Widget;
export '/home/articles/article2/article2_widget.dart' show Article2Widget;
export '/drugs/drugsforbaby/drugbaby1/drugbaby1_widget.dart'
    show Drugbaby1Widget;
export '/drugs/drugsforbaby/drugbaby2/drugbaby2_widget.dart'
    show Drugbaby2Widget;
export '/drugs/drugsforbaby/drugbaby3/drugbaby3_widget.dart'
    show Drugbaby3Widget;
export '/drugs/drugsforbaby/drugbaby4/drugbaby4_widget.dart'
    show Drugbaby4Widget;
export '/drugs/drugsformom/drugmom1/drugmom1_widget.dart' show Drugmom1Widget;
export '/drugs/drugsformom/drugmom2/drugmom2_widget.dart' show Drugmom2Widget;
export '/drugs/drugsformom/drugmom3/drugmom3_widget.dart' show Drugmom3Widget;
export '/drugs/drugsformom/drugmom4/drugmom4_widget.dart' show Drugmom4Widget;
export '/recommendations/stories/story1/story1_widget.dart' show Story1Widget;
export '/recommendations/stories/story2/story2_widget.dart' show Story2Widget;
export '/recommendations/stories/story3/story3_widget.dart' show Story3Widget;
export '/recommendations/stories/story4/story4_widget.dart' show Story4Widget;
export '/recommendations/foodforbaby/food1/food1_widget.dart' show Food1Widget;
export '/recommendations/foodforbaby/food2/food2_widget.dart' show Food2Widget;
export '/recommendations/foodforbaby/food3/food3_widget.dart' show Food3Widget;
export '/recommendations/foodformom/food4/food4_widget.dart' show Food4Widget;
export '/recommendations/foodformom/food5/food5_widget.dart' show Food5Widget;
export '/recommendations/foodformom/food6/food6_widget.dart' show Food6Widget;
export '/inprogress/inprogress/inprogress_widget.dart' show InprogressWidget;
export '/inprogress/inprogress2/inprogress2_widget.dart' show Inprogress2Widget;
export '/inprogress/inprogress3/inprogress3_widget.dart' show Inprogress3Widget;
export '/aloqa/bigchat/bigchat_widget.dart' show BigchatWidget;
export '/aloqa/calldoctor/calldoctor_widget.dart' show CalldoctorWidget;
